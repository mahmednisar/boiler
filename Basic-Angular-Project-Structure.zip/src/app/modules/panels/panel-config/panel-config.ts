export class PanelConfig<panel = any> {
	data?: panel;
}