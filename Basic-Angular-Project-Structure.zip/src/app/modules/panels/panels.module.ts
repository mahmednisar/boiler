import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PanelWrapperComponent } from './panel-wrapper/panel-wrapper.component';
import { InsertionDirective } from './panel-config/insertion.directive';



@NgModule({
	declarations: [
		PanelWrapperComponent, 
		InsertionDirective
	],
	imports: [
		CommonModule
	],
	entryComponents : [
		PanelWrapperComponent,
	]
})
export class PanelsModule { }
