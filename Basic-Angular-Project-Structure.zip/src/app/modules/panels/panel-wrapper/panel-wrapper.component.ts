import { Component, OnInit, ComponentRef, AfterViewInit, OnDestroy, ViewChild, Type, ComponentFactoryResolver, ChangeDetectorRef, HostListener } from '@angular/core';
import { InsertionDirective } from '../panel-config/insertion.directive';
import { Subject } from 'rxjs';
import { PanelRef } from '../panel-config/panel-ref';

@Component({
	selector: 'app-panel-wrapper',
	templateUrl: './panel-wrapper.component.html',
	styleUrls: ['./panel-wrapper.component.scss']
})
export class PanelWrapperComponent implements AfterViewInit, OnDestroy {
	componentRef: ComponentRef<any>;

	@HostListener('click', ['$event'])
	onClick() 
	{
		this.onOverlayClicked();
	}

	@ViewChild(InsertionDirective, { static: false }) insertionPoint: InsertionDirective;

	private readonly _onClose = new Subject<any>();
	public onClose = this._onClose.asObservable();

	childComponentType: Type<any>;

	constructor(private componentFactoryResolver: ComponentFactoryResolver, private cd: ChangeDetectorRef, private dialogRef: PanelRef) { }

	ngAfterViewInit() {
		this.loadChildComponent(this.childComponentType);
		this.cd.detectChanges();
	}

	onOverlayClicked(evt?: MouseEvent) {
		this.dialogRef.close();
	}

	onDialogClicked(evt: MouseEvent) {
		evt.stopPropagation();
	}

	loadChildComponent(componentType: Type<any>) {
		let componentFactory = this.componentFactoryResolver.resolveComponentFactory(componentType);

		let viewContainerRef = this.insertionPoint.viewContainerRef;
		viewContainerRef.clear();

		this.componentRef = viewContainerRef.createComponent(componentFactory);
	}

	ngOnDestroy() {
		if (this.componentRef) {
			this.componentRef.destroy();
		}
	}

	close() {
		this._onClose.next();
	}
}
