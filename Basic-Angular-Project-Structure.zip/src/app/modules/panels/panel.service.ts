import { Injectable, ComponentRef, ComponentFactoryResolver, ApplicationRef, Injector, Type, EmbeddedViewRef } from '@angular/core';
import { PanelConfig } from './panel-config/panel-config';
import { PanelRef } from './panel-config/panel-ref';
import { PanelInjector } from './panel-config/panel-injector';
import { PanelWrapperComponent } from './panel-wrapper/panel-wrapper.component';
import { PanelsModule } from './panels.module';

@Injectable({
	providedIn : PanelsModule
})
export class PanelService {
	dialogComponentRef : ComponentRef<PanelWrapperComponent>;

	constructor(private componentFactoryResolver: ComponentFactoryResolver, private appRef: ApplicationRef, private injector: Injector) { }

	public open(componentType: Type<any>, config: PanelConfig) {
		const dialogRef = this.appendDialogComponentToBody(config);

		this.dialogComponentRef.instance.childComponentType = componentType;

		return dialogRef;
	}

	private appendDialogComponentToBody(config: PanelConfig) {
		const map = new WeakMap();
		map.set(PanelConfig, config);

		const dialogRef = new PanelRef();
		map.set(PanelRef, dialogRef);

		const sub = dialogRef.afterClosed.subscribe(() => {
			this.removeDialogComponentFromBody();
			sub.unsubscribe();
		});

		const componentFactory = this.componentFactoryResolver.resolveComponentFactory(PanelWrapperComponent);
		const componentRef     = componentFactory.create(new PanelInjector(this.injector, map));

		this.appRef.attachView(componentRef.hostView);

		const domElem = (componentRef.hostView as EmbeddedViewRef<any>).rootNodes[0] as HTMLElement;
		document.body.appendChild(domElem);

		this.dialogComponentRef = componentRef;

		this.dialogComponentRef.instance.onClose.subscribe(() => {
			this.removeDialogComponentFromBody();
		});

		return dialogRef;
	}

	private removeDialogComponentFromBody() {
		this.appRef.detachView(this.dialogComponentRef.hostView);
		this.dialogComponentRef.destroy();
	}

	close() {
		this.removeDialogComponentFromBody();
	}
}
