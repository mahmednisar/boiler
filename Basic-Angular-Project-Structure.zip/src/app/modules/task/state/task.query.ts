import { Injectable } from '@angular/core';
import { Query, QueryEntity } from '@datorama/akita';
import { TaskState, TaskStore } from './task.store';

@Injectable({
	providedIn: 'root'
})
export class TaskQuery extends QueryEntity<TaskState>
{
	getSelectedTask     = this.select(state => state.selectedTask);
	getSelectedTemplate = this.select(state => state.selectedTemplated);
	getSelectedSubtask  = this.select(state => state.selectedSubtask);
	getSelectedAudit    = this.select(state => state.selectedAudit);
	getSelectedEscalate = this.select(state => state.selectedEscalate);
	getPreviousTaskId   = this.select(state => state.previousTaskId);
	getPreviousState    = this.select(state => state.previousState);

	constructor(protected store: TaskStore) {
		super(store);
	}
}