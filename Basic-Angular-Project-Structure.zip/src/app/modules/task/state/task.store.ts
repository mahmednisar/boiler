import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { MasterTemplate } from 'src/app/models/MasterTemplate.model';
import { Task } from '../../../models/Task.model';

export interface TaskState extends EntityState<any> {
	selectedTask      : Task;
	selectedTemplated : MasterTemplate;
	selectedSubtask   : Task;
	selectedAudit     : boolean;
	selectedEscalate  : boolean;
	previousTaskId    : number;
	previousState     : string;
}

const initialState = {
	selectedTask      : null,
	selectedTemplated : null,
	selectedSubtask   : null,
	selectedAudit     : true,
	selectedEscalate  : true,
	previousTaskId    : null,
	previousState     : null,
}

@Injectable({
	providedIn: 'root'
})
@StoreConfig({ name: 'task' })
export class TaskStore extends EntityStore<TaskState> {
	constructor() {
		super(initialState);
	}
}