import { Injectable } from '@angular/core';
import { MasterTemplate } from 'src/app/models/MasterTemplate.model';
import { Task } from '../../../models/Task.model';
import { TaskStore } from './task.store';

@Injectable({
	providedIn: 'root'
})
export class TaskSessionService
{
	constructor(private taskStore: TaskStore) { }

	updateTask(task: Task) : void
	{
		this.taskStore.update({ selectedTask: task });
	}

	updateTemplate(template : MasterTemplate) : void
	{
		this.taskStore.update({ selectedTemplated: template });
	}

	updateSubtask(subtask : Task) : void
	{
		this.taskStore.update({ selectedSubtask : subtask });
	}

	removeTask() : void
	{
		this.taskStore.remove({ selectedTask : null });
	}

	removeTemplate() : void
	{
		this.taskStore.remove({ selectedTemplated : null });
	}

	removeSubtask() : void
	{
		this.taskStore.update({ selectedSubtask : null });
	}

	// PREVIOUS TASKID & STATE
	updatePreviousTaskId(taskId : number) : void
	{
		this.taskStore.update({ previousTaskId : taskId });
	}

	updatePreviousState(state : string) : void
	{
		this.taskStore.update({ previousState : state });
	}

	removePreviousTaskId() : void
	{
		this.taskStore.remove({ previousTaskId : null });
	}

	removePreviousState() : void
	{
		this.taskStore.remove({ previousState : null });
	}

	// SHOW or HIDE AUDIT & ESCALATE RESULT:
	updateAudit() : void
	{
		this.taskStore.update({selectedAudit : false});
	}

	updateEscalate() : void
	{
		this.taskStore.update({selectedEscalate : false});
	}

	removeAudit() : void
	{
		this.taskStore.update({selectedAudit : true});
	}

	removeEscalate() : void
	{
		this.taskStore.update({selectedEscalate : true});
	}
}