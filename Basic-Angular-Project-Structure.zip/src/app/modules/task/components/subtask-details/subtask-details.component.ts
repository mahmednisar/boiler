import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { forkJoin } from 'rxjs';
import { debounceTime, filter, map } from 'rxjs/operators';
import { ActiveUser } from 'src/app/models/active-user.model';
import { CustomField } from 'src/app/models/MasterTemplateProperties.model';
import { Task } from 'src/app/models/Task.model';
import { ActiveUserService } from 'src/app/services/active-user.service';
import { FormGeneratorService } from 'src/app/services/form-generator.service';
import { TaskService } from 'src/app/services/task.service';
import { TemplateService } from 'src/app/services/template.service';
import { CommonTaskService } from '../common-task.service';

import { IconDefinition, faTimes, faEye, faStop, faPlay } from '@fortawesome/pro-regular-svg-icons';
import { faScrubber, faClock, faCheckCircle, faMinusCircle, faTimesCircle, faPauseCircle } from '@fortawesome/pro-duotone-svg-icons';
import { TaskStatusIcons } from '../../constants/task-status.enum';
import { TaskQuery } from '../../state/task.query';
import { TaskSessionService } from '../../state/task-session.service';
import { DateTimeFormatterService } from 'src/app/services/date-time-formatter.service';


@Component({
	selector    : 'subtask-details',
	templateUrl : './subtask-details.component.html',
	styleUrls   : ['./subtask-details.component.scss'],
})
export class SubtaskDetailsComponent implements OnInit
{
	@Output() onUpdate = new EventEmitter();

	template          : any;
	subtask           : Task;
	task              : Task;
	user              : ActiveUser;
	subtaskForm       : FormGroup;
	fa                : Record<string, IconDefinition>;
	icons             : typeof TaskStatusIcons;
	props             : any;
	config            : any;
	previousSubtaskId : number;
	displayFormat     : string;
	isPatchEvent      : boolean;

	constructor(
		private templateService      : TemplateService,
		private activeUser           : ActiveUserService,
		private formGeneratorService : FormGeneratorService,
		private commonTaskService    : CommonTaskService,
		private taskService          : TaskService,
		private taskQuery            : TaskQuery,
		private taskSessionService   : TaskSessionService
	)
	{
		this.fa            = { faTimes, faScrubber, faClock, faCheckCircle, faMinusCircle, faTimesCircle, faPauseCircle, faEye, faStop, faPlay };
		this.icons         = TaskStatusIcons;
		this.displayFormat = DateTimeFormatterService.DateTime;
	}

	ngOnInit() : void
	{
		this.user = this.activeUser.getUser();

		// Accessing the State for Selected Task & Selected Template.
		this.taskQuery.getSelectedTask.subscribe(selectedTask => this.task = selectedTask);
		this.taskQuery.getSelectedTemplate.subscribe(selectedTemplate => this.template = selectedTemplate);
		this.taskQuery.getSelectedSubtask.subscribe(onSubtaskChange.bind(this));

		function onSubtaskChange(this : SubtaskDetailsComponent, selectedSubtask) : void
		{
			this.previousSubtaskId = this.subtask ? this.subtask.taskId : null;
			this.subtask           = selectedSubtask;

			if(!this.subtask) return;

			forkJoin({ // Task Details Form Populating and also getting the configs for selected templates
				props  : this.templateService.getTemplateDetails(selectedSubtask.templateId),
				config : this.templateService.getTemplateConfig(selectedSubtask.templateId)
			})
			.pipe(filter(subtaskChanged.bind(this)), map(generateFormAndValidations.bind(this)))
			.subscribe(onSuccess.bind(this));
	
			function subtaskChanged(this : SubtaskDetailsComponent) : boolean
			{
				return this.subtask ? this.subtask.taskId != this.previousSubtaskId : false;
			}

			function generateFormAndValidations(this : SubtaskDetailsComponent, data : any) : any  // Form & Validations
			{
				data.props.customFields.forEach(field => {
					field.isMandatory = field.validations.some(validation => validation.validationType == 'mandatory');
					field.isReadonly  = field.validations.some(validation => validation.validationType == 'readonly');
				});
	
				this.subtaskForm = this.formGeneratorService.generateForm(data.props.customFields);
				this.commonTaskService.patchData(this.subtask, this.subtask.templateId, this.subtaskForm, data.props.customFields, true);
				this.isPatchEvent = true;
				return data;
			}
	
			function onSuccess(this : SubtaskDetailsComponent, data : any) : any
			{
				Object.assign(this, data);
				this.checkIfFormEnabled();
			}
		}
	}

	updateTask() : void
	{
		if (this.subtaskForm.invalid) return;

		let field : CustomField[] = this.props.customFields;
		for (let property of field) this.taskService.setPropertyValue(property, this.subtaskForm.value);
		this.taskService.updateTask(this.template.templateId, this.subtask, field).subscribe(response => {
			this.updateSelectedSubtask(response.data);
			this.onUpdate.emit(this.subtask);
		});
	}

	startTask() : void
	{
		this.taskService.startTask(this.template.templateId, this.subtask.taskId).subscribe(response => this.updateSelectedSubtask(response.data));
	}

	closeView() : void
	{
		this.taskSessionService.removeSubtask();
	}

	// Updating The Selected Task state
	private updateSelectedSubtask(updatedTask : Task) : void
	{
		let updatedSubtask = updatedTask.subTaskList.find(task => task.taskId == this.subtask.taskId);
		this.taskSessionService.updateTask(updatedTask);
		this.taskSessionService.updateSubtask(updatedSubtask);
		this.checkIfFormEnabled();
	}

	// Function for Restricting the user and auto Start if config available
	private checkIfFormEnabled() : void
	{
		if ((this.user.userId == this.subtask.assignedTo) && this.config.tskautostart)
		{
			this.subtaskForm.statusChanges.pipe(debounceTime(250)).subscribe(statusChanged.bind(this));
			function statusChanged(this : SubtaskDetailsComponent) : void
			{
				if(this.isPatchEvent)
				{
					this.isPatchEvent = false;
					return;
				}
				if (this.subtask.state == 'new') this.startTask();
			}
		}
		if ((this.user.userId == this.subtask.assignedTo) && !this.subtask.isEditable) this.subtaskForm.disable({emitEvent : false});
	}
}
