import { Component, Input, HostBinding } from '@angular/core';

import { ActiveUserService } from 'src/app/services/active-user.service';

import { ActiveUser } from 'src/app/models/active-user.model';
import { TemplateCounts } from 'src/app/models/TemplateCounts.model';
import { MasterTemplate } from 'src/app/models/MasterTemplate.model';

import { IconDefinition, faQuestionCircle, faScrubber, faClock, faCheckCircle, faMinusCircle, faTimesCircle, faPauseCircle, faUpload } from '@fortawesome/pro-duotone-svg-icons';

@Component({
	selector    : 'status-card',
	templateUrl : './status-card.component.html',
	styleUrls   : ['./status-card.component.scss']
})
export class StatusCardComponent
{
	@HostBinding('class') class = 'd-flex align-items-center';

	@Input()  template    : MasterTemplate;
	@Input()  counts      : TemplateCounts;

	user : ActiveUser;
	fa   : Record<string, IconDefinition>;

	constructor(private activeUserService : ActiveUserService)
	{
		this.fa          = { faQuestionCircle, faScrubber, faClock, faCheckCircle, faMinusCircle, faTimesCircle, faPauseCircle, faUpload };
		this.user        = this.activeUserService.getUser();
		this.counts      = {} as TemplateCounts;
	}
}