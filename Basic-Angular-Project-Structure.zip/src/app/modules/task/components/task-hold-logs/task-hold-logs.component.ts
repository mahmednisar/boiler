import { Component, Input, OnInit } from '@angular/core';
import { HoldLogs } from 'src/app/models/task-administration.model';
import { DateTimeFormatterService } from 'src/app/services/date-time-formatter.service';

@Component({
	selector    : 'task-hold-logs',
	templateUrl : './task-hold-logs.component.html',
	styleUrls   : ['./task-hold-logs.component.scss']
})
export class TaskHoldLogsComponent
{
	@Input() holdLogs : HoldLogs[];
	dateTimeFormat    = DateTimeFormatterService.DateTime;
}
