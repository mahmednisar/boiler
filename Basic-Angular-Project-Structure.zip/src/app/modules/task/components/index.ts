import { StatusCardComponent } from './status-card/status-card.component';
import { CreateTaskComponent } from './create-task/create-task.component';
import { TaskListComponent } from './task-list/task-list.component';
import { BulkUploadComponent } from './bulk-upload/bulk-upload.component';
import { CopyTaskComponent } from './copy-task/copy-task.component';
import { TaskDetailsComponent } from './task-details/task-details.component';
import { TaskBasicsComponent } from './task-basics/task-basics.component';
import { DeadlineCounterComponent } from './deadline-counter/deadline-counter.component';
import { SubtaskListComponent } from './subtask-list/subtask-list.component';
import { TitleEditComponent } from './inline-edit-components/title-edit/title-edit.component';
import { SubtitleEditComponent } from './inline-edit-components/subtitle-edit/subtitle-edit.component';
import { SubtaskDetailsComponent } from './subtask-details/subtask-details.component';
import { TaskAuditComponent } from './task-audit/task-audit.component';
import { TaskHoldLogsComponent } from './task-hold-logs/task-hold-logs.component';
import { Subtitle2EditComponent } from './inline-edit-components/subtitle2-edit/subtitle2-edit.component';

export let components =
[
	StatusCardComponent,
	CreateTaskComponent,
	TaskDetailsComponent,
	TaskListComponent,
	BulkUploadComponent,
	CopyTaskComponent,
	TaskBasicsComponent,
	DeadlineCounterComponent,
	TaskAuditComponent,
	SubtaskListComponent,
	SubtaskDetailsComponent,
	// Inline Edit Components
	TitleEditComponent,
	SubtitleEditComponent,
	Subtitle2EditComponent,
	TaskHoldLogsComponent,
];