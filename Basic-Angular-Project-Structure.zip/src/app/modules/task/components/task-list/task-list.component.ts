/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators, FormArray } from '@angular/forms';
import { SelectionModel } from '@angular/cdk/collections';
import { Router, ActivatedRoute } from '@angular/router';

import { Observable, forkJoin, of, Subscription, interval } from 'rxjs';
import { map, switchMap, filter, debounceTime, catchError } from 'rxjs/operators';

import { IconDefinition, faPencil, faSearch, faCaretLeft, faCaretRight, faAngleDoubleDown, faAngleDoubleUp, faAngleUp, faSort, faSortUp, faSortDown, faInfoCircle, faPlus } from '@fortawesome/pro-solid-svg-icons';
import { faEye, faPlay, faStop, faCopy, faFileUpload, faFilter, faPause, faFastForward } from '@fortawesome/pro-regular-svg-icons';
import { faPencilAlt, faTimes } from '@fortawesome/pro-light-svg-icons';
import { faScrubber, faClock, faCheckCircle, faMinusCircle, faTimesCircle, faPauseCircle } from '@fortawesome/pro-duotone-svg-icons';

import { TaskService } from 'src/app/services/task.service';
import { ActiveUserService } from 'src/app/services/active-user.service';
import { UserService } from 'src/app/services/user.service';
import { TemplateService } from 'src/app/services/template.service';
import { TableStorageService } from 'src/app/services/table-storage.service';
import { BsModalService } from 'ngx-bootstrap/modal';

import { TaskStatusIcons } from '../../constants/task-status.enum';
import { TaskPriorityIcons } from '../../constants/task-priority.enum';

import { Task } from 'src/app/models/Task.model';
import { TaskSearchParams } from 'src/app/models/TaskSearchParams.model';
import { ActiveUser } from 'src/app/models/active-user.model';
import { User } from 'src/app/models/User.model';
import { TasksList } from 'src/app/models/TasksList.model';
import { MasterTemplate } from 'src/app/models/MasterTemplate.model';
import { TaskStatus } from 'src/app/models/TaskStatus.model';
import { TemplateCounts } from 'src/app/models/TemplateCounts.model';
import { MasterTemplateProperties } from 'src/app/models/MasterTemplateProperties.model';
import { Lookups } from 'src/app/models/lookup.model';

import { CopyTaskComponent } from '../copy-task/copy-task.component';
import { DateTimeFormatterService } from 'src/app/services/date-time-formatter.service';
import { TaskDetailsComponent } from '../task-details/task-details.component';

import { TaskSessionService } from '../../state/task-session.service';
import { TaskQuery } from '../../state/task.query';
import { MetricService } from 'src/app/services/metric.service';
import { MetricsConfiguration } from 'src/app/models/MetricsConfiguration.model';
import { isEqual } from 'lodash';
import { AccountService } from 'src/app/services/account.service';
import { AccountDetails } from 'src/app/models/acount-details.model';
import { AuthorizationService } from 'src/app/services/authorization.service';
import { CommonTaskService } from '../common-task.service';

@Component({
	templateUrl : './task-list.component.html',
	styleUrls   : ['./task-list.component.scss'],
	providers   : [CommonTaskService]
})
export class TaskListComponent implements OnInit, OnDestroy
{
	@ViewChild('taskDetails') TaskDetailsComponent : TaskDetailsComponent;

	user                   : ActiveUser;
	users                  : User[];
	assignUsers            : User[];
	statuses               : TaskStatus[];
	templates              : MasterTemplate[];
	selectedTemplate       : MasterTemplate;
	displayedColumns       : string[];
	filterColumns          : string[];
	taskFilters            : TaskSearchParams;
	taskFiltersForm        : FormGroup;
	customFieldsForm       : FormGroup;
	fa                     : Record<string, IconDefinition>;
	tasks                  : Task[];
	selectedTask           : Task;
	totalTasks             : number;
	tasksSelection         : SelectionModel<Task>;
	pageSize               : number;
	templateControl        : FormControl;
	searchTitleControl     : FormControl;
	searchSubTitleControl  : FormControl;
	searchSubTitle2Control : FormControl;
	assignedEditControl    : FormControl;
	priorityEditControl    : FormControl;
	titleEditControl       : FormControl;
	subTitleEditControl    : FormControl;
	statusEditControl      : FormControl;
	selectedTaskControl    : FormControl;
	accountControl         : FormControl;
	currentFilters         : TaskSearchParams;
	counts                 : TemplateCounts;
	config                 : any;
	props                  : MasterTemplateProperties;
	icons                  : typeof TaskStatusIcons;
	priorityIcons          : typeof TaskPriorityIcons;
	firstPaneVisible       : boolean;
	reloadSame             : boolean;
	multiAssignForm        : FormGroup;
	taskMappings           : FormArray;
	copyTaskForm           : FormGroup;
	collapse               : boolean;
	priority               : Lookups[];
	columnName             : string;
	sortOrder              : boolean;
	currentTimezone        : string;
	dateTimeFormat         : string;
	metrics                : MetricsConfiguration[];
	qualityMetric          : MetricsConfiguration;
	qualityConfig          : Record<string, any>;
	escalateMetric         : MetricsConfiguration;
	escalateConfig         : Record<string, any>;
	accounts               : AccountDetails[];
	selectedAccount        : AccountDetails;
	codes                  : any;
	showUnassignedTasks    : boolean;
	canProcessTasks        : boolean;
	canEditTasks           : boolean;

	private refreshInterval : Subscription;
	
	constructor(
		private taskService          : TaskService,
		private commonTaskService    : CommonTaskService,
		private activeUserService    : ActiveUserService,
		private userService          : UserService,
		private formBuilder          : FormBuilder,
		private templateService      : TemplateService,
		private azureTables          : TableStorageService,
		private modalService         : BsModalService,
		private router               : Router,
		private route                : ActivatedRoute,
		private taskSessionService   : TaskSessionService,
		private taskQuery            : TaskQuery,
		private metricService        : MetricService,
		private accountService       : AccountService,
		private authorization        : AuthorizationService,
	)
	{
		this.user                   = this.activeUserService.getUser();
		this.tasks                  = [];
		this.pageSize               = 50;
		this.accountControl         = new FormControl();
		this.templateControl        = new FormControl();
		this.searchTitleControl     = new FormControl();
		this.searchSubTitleControl  = new FormControl();
		this.searchSubTitle2Control = new FormControl();
		this.assignedEditControl    = new FormControl();
		this.priorityEditControl    = new FormControl();
		this.titleEditControl       = new FormControl();
		this.subTitleEditControl    = new FormControl();
		this.statusEditControl      = new FormControl();
		this.selectedTaskControl    = new FormControl();
		this.taskFiltersForm        = this.formBuilder.group({
			templateId         : null,
			statusId           : null,
			status             : null,
			title              : null,
			subtitle           : null,
			subtitle2          : null,
			createdOn          : null,
			assignedOn         : null,
			actualStartDate    : null,
			actualEndDate      : null,
			userId             : null,
			assignedTo         : null,
			numberOfRecords    : this.pageSize,
			showUnassigned     : false,
			showTasksToDiscard : false,
			pageNumber         : 1,
			sortByColumn       : null,
			isDescending       : null,
			priority           : null,
		});

		this.currentFilters   = {};
		this.firstPaneVisible = true;
		this.dateTimeFormat   = DateTimeFormatterService.DateTime;
		this.multiAssignForm  = this.formBuilder.group({assignedTo : [null, Validators.required]});

		this.fa = { faPencil, faSearch, faCaretLeft, faCaretRight, faScrubber, faClock, faCheckCircle, faMinusCircle, faTimesCircle, faPauseCircle, faEye, faPlay, faStop, faCopy, faPencilAlt, faFileUpload, faPlus, faFilter, faAngleDoubleDown, faAngleDoubleUp, faAngleUp, faSort, faSortUp, faSortDown, faInfoCircle, faPause, faFastForward, faTimes };

		this.icons          = TaskStatusIcons;
		this.priorityIcons  = TaskPriorityIcons;
		this.tasksSelection = new SelectionModel(true, []);
	}

	ngOnInit() : void
	{
		this.displayedColumns    = this.commonTaskService.getColumnConfig('default');
		this.filterColumns       = this.commonTaskService.getFilterConfig('default');
		this.accountService.getAccountDetails(this.user.userId).subscribe(response => {
			this.accounts = response;
			if (!this.route.snapshot.queryParams.accountId) this.accountControl.setValue(this.accounts[0]);
			else
			{
				let queryAccount = this.accounts.find(account => account.accountId == this.route.snapshot.queryParams.accountId);
				this.accountControl.setValue(queryAccount);
			}
		});

		this.onAccountChanges();
		this.onTemplateChanges();

		this.onUnassignedFilterChanges();
		this.onDiscardFilterChanges();

		this.onTaskFilterChanges();
		this.searchTitleControl.valueChanges.pipe(debounceTime(500)).subscribe(value => this.taskFiltersForm.controls.title.setValue(value));
		this.searchSubTitleControl.valueChanges.pipe(debounceTime(500)).subscribe(value => this.taskFiltersForm.controls.subtitle.setValue(value));
		this.searchSubTitle2Control.valueChanges.pipe(debounceTime(500)).subscribe(value => this.taskFiltersForm.controls.subtitle2.setValue(value));
	}

	ngOnDestroy() : void
	{
		if(this.refreshInterval) this.refreshInterval.unsubscribe();
	}

	onAccountChanges() : void
	{
		this.accountControl.valueChanges.subscribe(onAccountValueChanges.bind(this));
		function onAccountValueChanges(this : TaskListComponent, account : AccountDetails) : void
		{
			this.selectedAccount = account;
			forkJoin({
				templates : this.templateService.getAccountTemplates(account.accountId),
				codes     : this.authorization.getNavigations(this.user.roleId)
			}).subscribe(response => {
				Object.assign(this, response);
				this.showUnassignedTasks = response.codes.actions.some(action => action.code == 'show_unassigned_task');
				this.canProcessTasks     = response.codes.functions.some(funct => funct.code == 'canprocesstask');
				this.canEditTasks		 = response.codes.functions.some(funct => funct.code == 'canedittask');

				this.clearTaskSelection();

				if(!this.route.snapshot.queryParams.templateId) this.templateControl.setValue(this.templates[0]);
				else
				{
					let queryTemplate = this.templates.find(template => template.templateId == this.route.snapshot.queryParams.templateId);
					queryTemplate ? this.templateControl.setValue(queryTemplate) : this.templateControl.setValue(this.templates[0]);
				}
			});
		}
	}

	private onTemplateChanges() : void
	{
		this.templateControl.valueChanges
			.pipe(
				map(selectTemplate.bind(this)),
				switchMap(getData.bind(this))
			).subscribe(onDataGet.bind(this));

		function selectTemplate(this : TaskListComponent, template : MasterTemplate) : MasterTemplate
		{
			if (this.refreshInterval) {
				this.refreshInterval.unsubscribe();
				this.getTemplateCounts(template);
			}
			else this.getTemplateCounts(template);
			this.clearTaskSelection();
			this.taskSessionService.updateTemplate(template);
			this.taskFiltersForm.controls.templateId.setValue(template.templateId);

			this.selectedTemplate = template;
			this.currentTimezone  = template.timeZones.find(zone => zone.isDefault).timeZone || 'UTC';
			this.refreshInterval  = interval(120000).subscribe(() => this.getTemplateCounts(template));

			return template;
		}

		function getData(this : TaskListComponent, template : MasterTemplate) : any
		{
			return forkJoin({
				users       : this.userService.getUsers({ accountId: template.primaryEntity, subAccountId: template.secondaryEntity, functionCode: "canprocesstask" }),
				statuses    : this.templateService.getTemplateStatus(template.templateId),
				config      : this.templateService.getTemplateConfig(template.templateId),
				props       : this.templateService.getTemplateDetails(template.templateId),
				priority    : this.taskService.getTaskPriorities(),
				metrics     : this.metricService.getMetricsConfiguration(template.templateId),
				assignUsers : this.userService.getAssignUsers({ accountId: template.primaryEntity, subAccountId: template.secondaryEntity })
			});
		}

		function onDataGet(this : TaskListComponent, data : any) : void
		{
			Object.assign(this, data);
			this.qualityMetric  = this.metrics.find(item => item.metricName == 'Quality');
			this.qualityConfig  = this.qualityMetric ? this.qualityMetric.configurations : null;
			!!this.selectedTask ? this.viewData(this.selectedTask.taskId) : this.clearTaskSelection();
			this.getColumnsOnClear();
		}
	}

	private getTemplateCounts(template): Observable<any>
	{
		let PartitionKey = this.showUnassignedTasks ? template.templateId : this.user.userId;
		let RowKey       = template.templateId;
		return this.azureTables.queryEntities('todaystask', {PartitionKey, RowKey}).pipe(catchError(() => of({}))).subscribe(data => this.counts = data);
	}

	selectionMasterToggle(event) : void
	{
		event.target.checked ? this.tasks.forEach(task => this.tasksSelection.select(task)) : this.tasksSelection.clear();
	}

	sortTable(column : string)
	{
		(this.columnName != column) ? (this.columnName = column, this.sortOrder = true) : ((this.sortOrder) ? this.sortOrder = false : this.sortOrder = true)
		this.taskFiltersForm.controls.sortByColumn.setValue(this.columnName, {emitEvent : false});
		this.taskFiltersForm.controls.isDescending.setValue(this.sortOrder);
	}

	startTask(task : Task) : void
	{
		this.taskService.startTask(this.selectedTemplate.templateId, task.taskId).subscribe(response => this.autoRefreshfunction(task, response.data));
	}

	closeTask(task : Task) : void
	{
		this.taskService.closeTask(this.selectedTemplate.templateId, task.taskId).subscribe(response => this.autoRefreshfunction(task, response.data));
	}

	holdTask(task : Task) : void
	{
		this.taskService.holdTask(this.selectedTemplate.templateId, task.taskId).subscribe(response => this.autoRefreshfunction(task, response.data));
	}

	resumeTask(task : Task) : void
	{
		this.taskService.resumeTask(this.selectedTemplate.templateId, task.taskId).subscribe(response => this.autoRefreshfunction(task, response.data));
	}

	autoRefreshfunction(task : Task, data) : void
	{
		Object.assign(task, data.task);
		this.taskSessionService.removeSubtask();

		if(this.config.allowhold) this.allowHoldConfig(data);
		
		if (this.selectedTask) {
			if(this.selectedTask.taskId == data.task.taskId) this.taskSessionService.updateTask(data.task);
		}
	}

	allowHoldConfig(response) : void
	{
		if(response.affectedTask.length > 0) {
			response.affectedTask.forEach(item => {
				findAllAndReplace(this.tasks, item, ele => ele.taskId == item.taskId);
				if(this.selectedTask) {
					if(this.selectedTask.taskId == item.taskId) this.taskSessionService.updateTask(item);
				}
			});
		}

		function findAllAndReplace(array, replacement, callback)
		{
			return array.forEach(element => callback(element) ? Object.assign(element, replacement) : element);
		}
	}

	editAssigned(row) : void
	{
		row.assignedEdit = !row.assignedEdit;
		this.assignedEditControl.setValue(row.assignedId);
	}

	saveAssigned(row : Task) : void
	{
		row.assignedEdit = !row.assignedEdit;
		let assignFn = row.assignedTo ? 'changeTaskAssignee' : 'assignTask';
		this.taskService[assignFn]({templateId : this.selectedTemplate.templateId, taskId: row.taskId, assignedTo : this.assignedEditControl.value}).subscribe(response => this.autoRefreshfunction(row, response.data));
	}

	editPriority(row : Task) : void
	{
		row.priorityEdit = !row.priorityEdit;
		this.priorityEditControl.setValue(row.priority);
	}

	savePriority(row : Task, newValue : string) : void
	{
		let oldTitle = row.priority;

		if (newValue != null) row.priority = newValue;
		row.priorityEdit = !row.priorityEdit;
		if (oldTitle != newValue) this.taskService.updateTask(this.selectedTemplate.templateId, row, null).subscribe(response => Object.assign(row, response.data));
	}

	viewData(taskId : number, property ?: string) : void
	{
		if(property == 'Audit') this.preProcessingTabs()
		
		this.taskService.getParticularTask(this.selectedTemplate.templateId, taskId).subscribe(onSuccess.bind(this));
		function onSuccess(this : TaskListComponent, task : Task) : void 
		{
			this.taskSessionService.updateTask(task);
			this.taskSessionService.removeSubtask();

			this.taskQuery.getSelectedTask.subscribe(updatedTask => {
				let org = this.tasks.find(task => task.taskId == updatedTask.taskId);
				Object.assign(org, updatedTask);
				this.selectedTask = updatedTask;
				this.collapse         = false;
				this.displayedColumns = this.commonTaskService.getColumnConfig('short');
				this.filterColumns    = this.commonTaskService.getFilterConfig('short');
			});
		}
	}

	private preProcessingTabs() : void
	{
		setTimeout(() => {
			let id = this.qualityConfig.subtasklevel ? 1 : 0;
			this.TaskDetailsComponent.staticTabs.tabs[id].active = true;
			if(!id) this.taskSessionService.updateAudit();
		}, 0);
	}

	clearTaskSelection() : void
	{
		this.taskSessionService.removeTask();
		this.taskSessionService.removeSubtask();
		this.selectedTask = null;
		this.selectedTaskControl.patchValue(null);
	}

	getColumnsOnClear() : void
	{
		this.taskFiltersForm.controls.showUnassigned.setValue(false);
		this.displayedColumns    = this.commonTaskService.getColumnConfig('default');
		this.filterColumns       = this.commonTaskService.getFilterConfig('default');
	}

	createTask() : void
	{
		this.router.navigate(['create-tasks'], {queryParams : {accountId : this.selectedAccount.accountId ,templateId : this.taskFiltersForm.controls.templateId.value}})
	}

	private onTaskFilterChanges() : void
	{
		this.taskFiltersForm.valueChanges
			.pipe(map(resetPaging.bind(this)), filter(checkIfChanged.bind(this)), switchMap(getTasks.bind(this)))
			.subscribe(data => {
				this.tasks = data.result;
				this.totalTasks = data.count;
				!!this.selectedTask ? this.viewData(this.selectedTask.taskId) : this.clearTaskSelection();
				this.tasksSelection.clear();
				this.reloadSame = false;
			});

		function resetPaging(this : TaskListComponent, filters : TaskSearchParams) : TaskSearchParams
		{
			if(filters.pageNumber == this.currentFilters.pageNumber && !this.reloadSame)
			{
				filters.pageNumber = 1;
				this.taskFiltersForm.controls.pageNumber.setValue(1, {emitEvent : false});
			}
			return filters;
		}

		function checkIfChanged(this : TaskListComponent, filters : TaskSearchParams) : boolean
		{
			return this.reloadSame || !isEqual(filters, this.currentFilters);
		}

		function getTasks(this : TaskListComponent, filters : TaskSearchParams) : Observable<TasksList>
		{
			this.currentFilters = filters;
			return this.taskService.getTasks(filters);
		}
	}

	private onUnassignedFilterChanges() : void
	{
		this.taskFiltersForm.controls.showUnassigned.valueChanges.subscribe(value => {
			this.displayedColumns = value ? this.commonTaskService.getColumnConfig('check') : this.commonTaskService.getColumnConfig('default');
			this.filterColumns    = value ? this.commonTaskService.getFilterConfig('check') : this.commonTaskService.getFilterConfig('default');
			this.taskFiltersForm.controls.showTasksToDiscard.setValue(false, {emitEvent: false});
			this.tasksSelection.clear();
		});
	}

	assignMultipleTasks(pop) : void
	{
		if (this.multiAssignForm.invalid) return;
		this.taskService.assignMultipleTask(this.selectedTemplate.templateId, this.multiAssignForm.controls.assignedTo.value, this.tasksSelection.selected.map(task => task.taskId)).subscribe(onSuccess.bind(this));
		function onSuccess(this : TaskListComponent, response) : void
		{
			this.tasksSelection.clear();
			pop.hide();
			this.reloadSame = true;
			this.taskFiltersForm.updateValueAndValidity();
		}
	}

	private onDiscardFilterChanges() : void
	{
		this.taskFiltersForm.controls.showTasksToDiscard.valueChanges.subscribe(value => {
			this.displayedColumns = value ? this.commonTaskService.getColumnConfig('check') : this.commonTaskService.getColumnConfig('default');
			this.filterColumns    = value ? this.commonTaskService.getFilterConfig('check') : this.commonTaskService.getFilterConfig('default');
			this.taskFiltersForm.controls.showUnassigned.setValue(false, {emitEvent: false});
			this.tasksSelection.clear();
		});
	}

	discardMultipleTask() : void
	{
		this.taskService.discardMultipleTask(this.selectedTemplate.templateId, this.tasksSelection.selected.map(task => task.taskId)).subscribe(onSuccess.bind(this));
		function onSuccess(this : TaskListComponent, response) : void
		{
			this.tasksSelection.clear();
			this.reloadSame = true;
			this.taskFiltersForm.updateValueAndValidity();
		}
	}

	initCopyTaskTM(task : Task) : void
	{
		var initialState = {
			templateId : this.selectedTemplate.templateId,
			task       : task,
			users      : this.users
		}
		let modalRef = this.modalService.show(CopyTaskComponent , { initialState } );
		modalRef.content.event.subscribe(res => this.postCopyTask(res.form) );
	}

	postCopyTask(form : FormGroup) : void
	{
		if (!form.valid) return;

		let data = { ...form.value };
		this.taskService.copyTask(data).subscribe(onSuccess.bind(this));
		function onSuccess(this: TaskListComponent) : void
		{
			this.reloadSame    = true;
			this.taskFiltersForm.updateValueAndValidity();
		}
	}

	customSearchBox(pop, status) : void
	{
		this.taskFiltersForm.controls.statusId.setValue(status.statusId);
		this.taskFiltersForm.controls.status.setValue(status.state);
		pop.hide();
	}
}