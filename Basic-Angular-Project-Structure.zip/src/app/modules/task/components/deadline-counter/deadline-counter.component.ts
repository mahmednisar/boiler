import { Component, Input, OnInit, OnDestroy } from '@angular/core';

import { Subscription, interval } from 'rxjs';
import { Task } from 'src/app/models/Task.model';
import { DateTimeFormatterService } from 'src/app/services/date-time-formatter.service';
import { TaskQuery } from '../../state/task.query';

@Component({
	selector    : 'deadline-counter',
	templateUrl : './deadline-counter.component.html',
})
export class DeadlineCounterComponent implements OnInit, OnDestroy
{
	@Input() deadline : {metricName : string; metricDeadline : string; isAchived : boolean; achievedDate ?: string};

	private refreshInterval : Subscription;

	task       : Task;
	counter    : any;
	todaysDate : Date;

	constructor(
		private dateTimeFormat : DateTimeFormatterService,
		private taskQuery      : TaskQuery
	) {}

	ngOnInit() : void
	{
		this.taskQuery.getSelectedTask.subscribe(selectedTask => this.task = selectedTask);

		let duration     = this.dateTimeFormat.getDuration(this.deadline.metricDeadline);
		    this.counter = Math.round(duration);

		this.refreshInterval = interval(1000).subscribe(countDown.bind(this));
		
		function countDown(this : DeadlineCounterComponent) : void
		{
			this.counter--;
		}
	}

	ngOnDestroy() : void
	{
		if(this.refreshInterval) this.refreshInterval.unsubscribe();
	}
}
