import { Component, Input, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';

import { TaskPriorityIcons } from '../../constants/task-priority.enum';
import { IconDefinition, faAngleDoubleDown, faAngleDoubleUp, faAngleUp } from '@fortawesome/pro-solid-svg-icons';

import { TaskService } from 'src/app/services/task.service';
import { DateTimeFormatterService } from 'src/app/services/date-time-formatter.service';

import { Task } from 'src/app/models/Task.model';
import { User } from 'src/app/models/User.model';
import { Lookups } from 'src/app/models/lookup.model';
import { TzDatePipe } from 'src/app/modules/shared/pipes/tz-date.pipe';
import { MasterTemplate } from 'src/app/models/MasterTemplate.model';
import { TaskQuery } from '../../state/task.query';
import { TaskSessionService } from '../../state/task-session.service';
import { ActiveUserService } from 'src/app/services/active-user.service';
import { AuthorizationService } from 'src/app/services/authorization.service';
import { ActiveUser } from 'src/app/models/active-user.model';

@Component({
	selector    : 'task-basics',
	templateUrl : './task-basics.component.html',
	styleUrls   : ['./task-basics.component.scss'],
	providers   : [ TzDatePipe ]
})
export class TaskBasicsComponent
{
	@ViewChild('recievedOn_DT') OwlDateTime : any; 
	@Input() users    : User[];
	@Input() priority : Lookups[];

	assignedEditControl : FormControl;
	priorityEditControl : FormControl;
	recievedEditControl : FormControl;
	fa                  : Record<string, IconDefinition>;
	priorityIcons       : typeof TaskPriorityIcons;
	template            : MasterTemplate;
	task                : Task;
	user                : ActiveUser;
	displayFormat       : string;
	currentDateTime     : Date;
	canEditTasks        : boolean;


	constructor(
		private taskService        : TaskService,
		private dateTimeFormat     : DateTimeFormatterService,
		private tzDate             : TzDatePipe,
		private taskQuery          : TaskQuery,
		private taskSessionService : TaskSessionService,
		private activeUser         : ActiveUserService,
		private authorization      : AuthorizationService
	)
	{
		this.user                = this.activeUser.getUser();
		this.assignedEditControl = new FormControl();
		this.priorityEditControl = new FormControl();
		this.recievedEditControl = new FormControl();
		
		this.priorityIcons = TaskPriorityIcons;
		this.fa            = { faAngleDoubleDown, faAngleDoubleUp, faAngleUp };
		this.displayFormat = DateTimeFormatterService.DateTime;
	}

	ngOnInit() : void
	{
		// Accessing the State for Selected Task & Selected Template.
		this.taskQuery.getSelectedTask.subscribe(selectedTask => this.task = selectedTask);
		this.taskQuery.getSelectedTemplate.subscribe(selectedTemplate => this.template = selectedTemplate);
		this.authorization.getNavigations(this.user.roleId).subscribe((actions) => {this.canEditTasks =  actions.functions.some(funct => funct.code == 'canedittask');})
	}

	
	calculateMaxDate() : void
	{
		this.currentDateTime = this.dateTimeFormat.getTodaysDate((this.template.timeZones.find(tz => tz.isDefault).utcOffset));
	}

	// Functions For Inline Edit
	editAssigned(row) : void
	{
		row.assignedEdit = !row.assignedEdit;
		this.assignedEditControl.setValue(row.assignedId);
	}

	editPriority(row : Task) : void
	{
		row.priorityEdit = !row.priorityEdit;
		this.priorityEditControl.setValue(row.priority);
	}

	editRecievedOn(row : Task) : void
	{
		setTimeout(() => {
			if(row.receivedOnEdit) this.OwlDateTime.open();
		}, 0);
		row.receivedOnEdit = !row.receivedOnEdit;
		let previousValue  = row.receivedOn ? new Date(this.tzDate.transform(row.receivedOn, this.displayFormat)) : new Date();
		this.recievedEditControl.setValue(previousValue);
	}

	// Functions For Inline Save
	saveAssigned(row : Task) : void
	{
		row.assignedEdit = !row.assignedEdit;
		let assignFn     = row.assignedTo ? 'changeTaskAssignee' : 'assignTask';
		this.taskService[assignFn]({templateId : this.template.templateId, taskId: row.taskId, assignedTo : this.assignedEditControl.value}).subscribe(() => this.refreshTask(row));
	}

	savePriority(row : Task, newValue : string) : void
	{
		let oldTitle = row.priority;

		if (newValue != null) row.priority = newValue;
		row.priorityEdit = !row.priorityEdit;
		if (oldTitle != newValue) this.taskService.updateTask(this.template.templateId, row, null).subscribe(response => this.updateSelectedTask(response.data));
	}

	saveRecievedOn(row : Task, newValue : any) : void
	{
		let data : any = {};

		data.taskId        = row.taskId;
		data.templateId    = row.templateId;

		data.recievedOn    = this.dateTimeFormat.toISO(newValue);
		row.receivedOnEdit = !row.receivedOnEdit;
		this.taskService.updateRecievedOn(data).subscribe(response => this.updateSelectedTask(response.data));
	}

	// Function To Refresh the task as some API Doesn't provide the updated task b back in response
	private refreshTask(task : Task) : void
	{
		this.taskService.getTasks({taskId : task.taskId, templateId : this.task.templateId }).subscribe(data => this.updateSelectedTask(data.result[0]));
	}

	// Updating The Selected Task state
	private updateSelectedTask(updatedTask : Task) : void
	{
		this.taskSessionService.updateTask(updatedTask);
	}

}
