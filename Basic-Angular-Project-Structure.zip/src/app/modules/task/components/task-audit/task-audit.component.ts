import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

import { TaskQuery } from '../../state/task.query';
import { TaskService } from 'src/app/services/task.service';
import { TaskSessionService } from '../../state/task-session.service';
import { PanelService } from 'src/app/modules/panels/panel.service';
import { DateTimeFormatterService } from 'src/app/services/date-time-formatter.service';
import { CommonTaskService } from '../common-task.service';
import { FormGeneratorService } from 'src/app/services/form-generator.service';
import { MetricService } from 'src/app/services/metric.service';
import { ActiveUserService } from 'src/app/services/active-user.service';
import { AuthorizationService } from 'src/app/services/authorization.service';

import { Task } from 'src/app/models/Task.model';
import { CustomFormProperties } from 'src/app/models/CustomFormProperties';
import { map } from 'rxjs/operators';
import { IconDefinition, faExclamationTriangle, faTimes } from '@fortawesome/pro-regular-svg-icons';
import { forkJoin, Subscription } from 'rxjs';
import { MasterTemplate } from 'src/app/models/MasterTemplate.model';
import { MasterTemplateProperties } from 'src/app/models/MasterTemplateProperties.model';
import { MetricsConfiguration } from 'src/app/models/MetricsConfiguration.model';
import { ActiveUser } from 'src/app/models/active-user.model';
import { TemplateService } from 'src/app/services/template.service';

@Component({
	selector    : 'task-audit',
	templateUrl : './task-audit.component.html',
	styleUrls   : ['./task-audit.component.scss'],
	providers   : [CommonTaskService]
})
export class TaskAuditComponent implements OnInit
{
	template             : MasterTemplate;
	selectedTask         : Task;
	subtaskList          : Task[];
	props                : MasterTemplateProperties;
	auditFormProperties  : CustomFormProperties[];
	metrics              : MetricsConfiguration[];
	user                 : ActiveUser;
	
	auditBasicForm       : FormGroup;
	auditCustomForm      : FormGroup;
	subtaskListControl   : FormControl;

	fa                   : Record<string, IconDefinition>;
	actions              : Record<string, any>;
	canAudit             : boolean;
	canEditTasks         : boolean;
	dateTimeFormat       : string;
	restrictDate         : string;


	templateSubscription : Subscription;
	taskSubscription     : Subscription;

	constructor
	(
		private taskQuery            : TaskQuery,
		private taskSessionService   : TaskSessionService,
		private taskService          : TaskService,
		private formGeneratorService : FormGeneratorService,
		private panelService         : PanelService,
		private commonTaskService    : CommonTaskService,
		private metricService        : MetricService,
		private activeUserService    : ActiveUserService,
		private authorization        : AuthorizationService,
		private templateService      : TemplateService
	)
	{
		this.user               = this.activeUserService.getUser();
		this.fa                 = { faExclamationTriangle, faTimes };
		this.subtaskListControl = new FormControl();
		this.selectedTask       = null;
		this.auditBasicForm     = new FormGroup({});
		this.auditCustomForm    = new FormGroup({});
		this.dateTimeFormat     = DateTimeFormatterService.DateTime;
	}

	ngOnInit() : void
	{
		this.templateSubscription = this.taskQuery.getSelectedTemplate.subscribe(selectedTemplate => this.template = selectedTemplate);
		this.taskSubscription     = this.taskQuery.getSelectedTask.subscribe(task => this.onTaskChanged(task));
	}

	ngOnDestroy() : void
	{
		this.taskSubscription.unsubscribe();
		this.templateSubscription.unsubscribe();
	}

	private onTaskChanged(task : Task) : void
	{
		// if(this.selectedTask.taskId == task.taskId) return;

		this.selectedTask = task;

		forkJoin({
			metrics : this.metricService.getMetricsConfiguration(this.template.templateId),
			props   : this.templateService.getCustomFormProperties(this.template.templateId, false, this.selectedTask.createdOn),
			actions : this.authorization.getNavigations(this.user.roleId)
		})
		.pipe(map(generateFormAndValidations.bind(this)))
		.subscribe(onSuccess.bind(this));

		function generateFormAndValidations(this : TaskAuditComponent, data : any) : any // Form & Validations
		{
			delete data.props['templateId'];
			delete data.props['taskId'];

			Object.keys(data.props).forEach(key => {
				data.props[key].forEach(field => {
					field.isMandatory = field.validations.some(validation => validation.validationType == 'mandatory');
					field.isReadonly  = field.validations.some(validation => validation.validationType == 'readonly');
				});
			})
			this.auditBasicForm  = this.formGeneratorService.generateForm(data.props.basicFields);
			this.auditCustomForm = this.formGeneratorService.generateForm(data.props.customFields);

			this.commonTaskService.patchData(this.selectedTask, this.template.templateId, this.auditBasicForm, data.props.basicFields, true, true);
			this.commonTaskService.patchData(this.selectedTask, this.template.templateId, this.auditCustomForm, data.props.customFields, true, true);

			return data;
		}

		function onSuccess(this : TaskAuditComponent, data : any) : void
		{
			Object.assign(this, data);
			this.canAudit      = this.actions.actions.some(item => item.code == 'task_audit');
			this.canEditTasks  = this.actions.functions.some(funct => funct.code == 'canedittask');
			let qualityMetric  = this.metrics.find(item => item.metricName == 'Quality');
			this.restrictDate  = qualityMetric.auditRestrictionDate;
			this.checkFormEnabled();
		}
	}

	changeStatus(status : string) : void
	{
		this.taskService.changeTaskAuditStatus(this.template.templateId, this.selectedTask.taskId, status).subscribe(onSuccess.bind(this));
		function onSuccess(this : TaskAuditComponent, response) : void
		{
			this.taskSessionService.updateTask(response.data);
			this.checkFormEnabled();
		}
	}

	auditTask() : void
	{
		if(this.auditBasicForm.invalid && this.auditCustomForm.invalid) return;

		let basicFields = this.props.basicFields;
		for (let property of basicFields) this.taskService.setPropertyValue(property, this.auditBasicForm.value);

		let customFields = this.props.customFields;
		for (let property of customFields) this.taskService.setPropertyValue(property, this.auditCustomForm.value);

		let data = {
			taskId       : this.selectedTask.taskId,
			templateId   : this.template.templateId,
			basicFields  : [...basicFields],
			customFields : [...customFields]
		}

		this.taskService.auditTask(data).subscribe(onSuccess.bind(this));
		function onSuccess(this: TaskAuditComponent, response : any) : void
		{
			this.taskSessionService.updateTask(response.data);
			this.checkFormEnabled();
		}
	}

	checkFormEnabled() : void
	{
		if(!this.selectedTask.quality.isEditable || !this.canAudit) {
			this.auditBasicForm.disable();
			this.auditCustomForm.disable();
		}
	}

	closePanel() : void
	{
		this.panelService.close();
	}
}
