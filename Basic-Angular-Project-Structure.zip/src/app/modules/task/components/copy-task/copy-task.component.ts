import { Component, OnInit, EventEmitter } from '@angular/core';
import { FormControl, FormBuilder, FormArray, FormGroup, Validators } from '@angular/forms';

import { IconDefinition, faTimes } from '@fortawesome/pro-solid-svg-icons';

import { ActiveUserService } from 'src/app/services/active-user.service';
import { UserService } from 'src/app/services/user.service';
import { BsModalRef } from 'ngx-bootstrap/modal';

import { Task } from 'src/app/models/Task.model';
import { ActiveUser } from 'src/app/models/active-user.model';
import { User } from 'src/app/models/User.model';

@Component({
	selector    : 'copy-task',
	templateUrl : './copy-task.component.html',
	styleUrls   : ['./copy-task.component.scss']
})
export class CopyTaskComponent implements OnInit {

	public event = new EventEmitter();

	templateId        : number;
	task              : Task;
	users             : User[];

	fa                : Record<string, IconDefinition>;
	activeuser        : ActiveUser;
	copyTaskForm      : FormGroup;
	userSelectControl : FormControl;
	taskMappings      : FormArray;
	
	constructor(
		public  activeModal       : BsModalRef,
		private activeUserService : ActiveUserService,
		private userService       : UserService,
		private formBuilder       : FormBuilder,
	)
	{
		this.fa = { faTimes };
	}

	ngOnInit() : void
	{
		this.activeuser        = this.activeUserService.getUser();
		this.userSelectControl = new FormControl(null, Validators.required);
		this.taskMappings      = this.formBuilder.array([]);
		
		this.copyTaskForm = this.formBuilder.group({
			templateId   : this.templateId,
			taskId       : this.task.taskId,
			taskMappings : this.taskMappings
		});
		
		if (this.users.length == 1)
		{
			this.userSelectControl.setValue(this.users);
			this.onUserSelect(this.users);
		}
	}

	onUserSelect(users : User[]) : void
	{
		users.forEach((user : User, index : number) => {
			this.taskMappings.setControl(index, this.generateMappingControl(user.userId));
		});
	}

	removeMappingControl(index : number) : void
	{
		let temp = (this.userSelectControl.value as User[]);
		temp.splice(index, 1);
		this.userSelectControl.setValue(temp);
		this.taskMappings.removeAt(index);
	}

	userInstance(i) : any { return this.taskMappings.controls[i]; }

	private generateMappingControl(userId : string = null) : FormGroup
	{
		return this.formBuilder.group({
			instance   : [null, [Validators.required, Validators.max(200)]],
			assignedTo : [userId, Validators.required]
		});
	}

	copyTask() : void
	{
		if(this.copyTaskForm.valid && this.userSelectControl.valid) {
			this.event.emit({form : this.copyTaskForm});
			this.activeModal.hide()
		}
		else return;
	}

}
