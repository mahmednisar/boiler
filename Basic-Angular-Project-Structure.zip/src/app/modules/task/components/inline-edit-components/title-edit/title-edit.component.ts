import { Component, Input, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';

import { TaskService } from 'src/app/services/task.service';

import { IconDefinition, faTimes, faCheck } from '@fortawesome/pro-solid-svg-icons';

import { Task } from 'src/app/models/Task.model';
import { TaskQuery } from '../../../state/task.query';
import { TaskSessionService } from '../../../state/task-session.service';
import { MasterTemplate } from 'src/app/models/MasterTemplate.model';

@Component({
	selector    : 'title-edit',
	templateUrl : './title-edit.component.html'
})
export class TitleEditComponent implements OnInit
{
	@Input() task        : Task;
	@Input() basicFields : any;
	@Input() isDetails   : boolean;
	@Input() config      : boolean;
	@Input() canEdit     : boolean;

	template         : MasterTemplate;
	selectedTask     : Task;
	titleEditControl : FormControl;
	fa               : Record<string, IconDefinition>;
	editing          : boolean;

	constructor(
		private taskService        : TaskService,
		private taskQuery          : TaskQuery,
		private taskSessionService : TaskSessionService
	)
	{
		this.fa               = { faTimes, faCheck };
		this.titleEditControl = new FormControl();
	}

	ngOnInit() : void
	{
		this.taskQuery.getSelectedTemplate.subscribe(template => this.template = template);
		this.taskQuery.getSelectedTask.subscribe(task => this.selectedTask = task);
	}

	editTitle() : void
	{
		if(this.config)
		{
			this.editing = !this.editing;
			this.titleEditControl.setValue(this.task.title);
		}
	}

	saveTitle()
	{
		let oldTitle = this.task.title;
		let newValue = this.titleEditControl.value;

		if (newValue != null) this.task.title = newValue;

		this.editing = !this.editing;
		if (oldTitle != newValue) this.taskService.updateTask(this.template.templateId, this.task as Task, null).subscribe(response => this.autoRefreshFunction(response.data));
	}

	private autoRefreshFunction(updatedTask) : void
	{
		Object.assign(this.task, updatedTask);
		if(this.task.taskId == this.selectedTask.taskId) this.taskSessionService.updateTask(updatedTask);
	}
}
