import { Component, Input, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';

import { IconDefinition, faTimes, faCheck } from '@fortawesome/pro-solid-svg-icons';

import { TaskService } from 'src/app/services/task.service';
import { TaskSessionService } from '../../../state/task-session.service';
import { TaskQuery } from '../../../state/task.query';

import { MasterTemplate } from 'src/app/models/MasterTemplate.model';
import { Task } from 'src/app/models/Task.model';

@Component({
	selector    : 'subtitle2-edit',
	templateUrl : './subtitle2-edit.component.html'
})
export class Subtitle2EditComponent implements OnInit 
{
	@Input() task        : Task;
	@Input() basicFields : any;
	@Input() isDetails   : boolean;
	@Input() config      : boolean;
	@Input() canEdit     : boolean;

	template             : MasterTemplate;
	selectedTask         : Task;
	subtitle2EditControl : FormControl;
	fa                   : Record<string, IconDefinition>;
	editing              : boolean;

	constructor(
		private taskService        : TaskService,
		private taskQuery          : TaskQuery,
		private taskSessionService : TaskSessionService
	)
	{
		this.fa                  = { faTimes, faCheck };
		this.subtitle2EditControl = new FormControl();
	}

	ngOnInit() : void
	{
		this.taskQuery.getSelectedTemplate.subscribe(template => this.template = template);
		this.taskQuery.getSelectedTask.subscribe(task => this.selectedTask = task);
	}

	editSubTitle2()
	{
		if(this.config)
		{
			this.editing = !this.editing;
			this.subtitle2EditControl.setValue(this.task.subTitle2);
		}
	}

	saveSubTitle2()
	{
		let oldTitle = this.task.subTitle2;
		let newValue = this.subtitle2EditControl.value;

		if (newValue != null) this.task.subTitle2 = newValue;

		this.editing = !this.editing;
		if (oldTitle != newValue) this.taskService.updateTask(this.template.templateId, this.task as Task, null).subscribe(response => this.autoRefreshFunction(response.data));
	}

	private autoRefreshFunction(updatedTask) : void
	{
		Object.assign(this.task, updatedTask);
		if(this.task.taskId == this.selectedTask.taskId) this.taskSessionService.updateTask(updatedTask);
	}
}