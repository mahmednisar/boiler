import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

import { IconDefinition, faTimes, faEye, faStop, faPlay, faExclamationTriangle } from '@fortawesome/pro-regular-svg-icons';
import { faScrubber, faClock, faCheckCircle, faMinusCircle, faTimesCircle, faPauseCircle } from '@fortawesome/pro-duotone-svg-icons';
import { TaskStatusIcons } from '../../constants/task-status.enum';

import { TaskService } from 'src/app/services/task.service';
import { CommonTaskService } from '../common-task.service';
import { TaskQuery } from '../../state/task.query';
import { TaskSessionService } from '../../state/task-session.service';
import { ActiveUserService } from 'src/app/services/active-user.service';

import { Task } from 'src/app/models/Task.model';
import { MasterTemplate } from 'src/app/models/MasterTemplate.model';
import { ActiveUser } from 'src/app/models/active-user.model';

@Component({
	selector    : 'subtask-list',
	templateUrl : './subtask-list.component.html',
	providers   : [CommonTaskService]
})
export class SubtaskListComponent implements OnInit
{
	@Input() config        : any;
	task                   : Task;
	template               : MasterTemplate;
	subtaskForm            : FormGroup;
	selectedSubtaskControl : FormControl;
	selectedSubtask        : Task;
	selectedSubtaskIndex   : number;
	fa                     : Record<string, IconDefinition>;
	icons                  : typeof TaskStatusIcons;
	subtask                : any;
	subtaskConfig          : any;
	user                   : ActiveUser;

	constructor(
		private taskService        : TaskService,
		private taskQuery          : TaskQuery,
		private taskSessionService : TaskSessionService,
		private activeUserService  : ActiveUserService
	)
	{
		this.fa                     = { faTimes, faScrubber, faClock, faCheckCircle, faMinusCircle, faTimesCircle, faPauseCircle, faEye, faStop, faPlay, faExclamationTriangle };
		this.icons                  = TaskStatusIcons;
		this.user                   = this.activeUserService.getUser();
		this.selectedSubtaskControl = new FormControl();
	}

	ngOnInit() : void
	{
		this.taskQuery.getSelectedTask.subscribe(selectedTask => this.task = selectedTask);
		this.taskQuery.getSelectedTemplate.subscribe(selectedTemplate => this.template = selectedTemplate);
		this.taskQuery.getSelectedSubtask.subscribe(subtask => this.selectedSubtask = subtask);
	}

	viewSubTask(subtask : Task, prop ?: string) : void
	{
		this.taskSessionService.removeAudit();
		this.taskSessionService.removeEscalate();
		if(prop) {
			prop == 'audit' ? this.taskSessionService.updateAudit() : this.taskSessionService.updateEscalate();
		}
		this.taskSessionService.updateSubtask(subtask);
	}

	startTask(task : Task) : void
	{
		this.taskService.startTask(this.template.templateId ,task.taskId).subscribe(response => this.updateSelectedTask(response.data));
	}

	closeTask(task : Task) : void
	{
		this.taskService.closeTask(this.template.templateId, task.taskId).subscribe(response => this.updateSelectedTask(response.data));
	}

	viewNextSubtask(updatedTask) : void
	{
		if(!this.config.subtaskneedstart)
		{
			let currentIndex = this.task.subTaskList.findIndex(subtask => subtask.taskId == updatedTask.taskId);
			let nextIndex    = currentIndex + 1;
			if(this.task.subTaskList[nextIndex]) this.viewSubTask(this.task.subTaskList[nextIndex]);
			else this.taskSessionService.removeSubtask();
		}
	}

	private updateSelectedTask(updatedTask : Task) : void
	{
		let updatedSubtask = updatedTask.subTaskList.find(task => task.taskId == this.selectedSubtask.taskId);
		this.taskSessionService.updateTask(updatedTask);
		this.taskSessionService.updateSubtask(updatedSubtask);
	}
}
