import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import { of, forkJoin } from 'rxjs';

import { TaskService } from 'src/app/services/task.service';
import { ActiveUserService } from 'src/app/services/active-user.service';
import { UserService } from 'src/app/services/user.service';
import { TemplateService } from 'src/app/services/template.service';
import { FormGeneratorService } from 'src/app/services/form-generator.service';
import { DateTimeFormatterService } from 'src/app/services/date-time-formatter.service';

import { MasterTemplate } from 'src/app/models/MasterTemplate.model';
import { User } from 'src/app/models/User.model';
import { MasterTemplateProperties } from 'src/app/models/MasterTemplateProperties.model';
import { ActiveUser } from 'src/app/models/active-user.model';

import { faCaretDown, faCaretRight, faExclamationTriangle, faExclamationCircle, IconDefinition } from '@fortawesome/pro-solid-svg-icons';
import { AccordionPanelComponent } from 'ngx-bootstrap/accordion';
import { AccountDetails } from 'src/app/models/acount-details.model';
import { AccountService } from 'src/app/services/account.service';
import { map } from 'rxjs/operators';

@Component({
	templateUrl : './create-task.component.html',
	styleUrls   : ['./create-task.component.scss']
})
export class CreateTaskComponent implements OnInit
{
	@ViewChild('basic', {static : false}) accordionBasic : AccordionPanelComponent
	@ViewChild('user', {static : false}) accordionUser   : AccordionPanelComponent

	user                    : ActiveUser;
	users                   : User[];
	accounts                : AccountDetails[];
	templates               : MasterTemplate[];
	selectedAccount         : AccountDetails;
	selectedTemplate        : MasterTemplate;
	addTaskForm             : FormGroup;
	customFieldsForm        : FormGroup;
	basicDetailsForm        : FormGroup;
	subtaskInstanceMappings : FormArray;
	subtaskControl          : FormControl;
	taskMappings            : FormArray;
	userSelectControl       : FormControl;
	taskTitleControl        : FormControl;
	receivedOnControl       : FormControl;
	accountControl          : FormControl;
	properties              : MasterTemplateProperties;
	submitting              : boolean;
	fa                      : Record<string, IconDefinition>;
	config                  : any;
	currentDateTime         : Date;
	submitted               : boolean;

	constructor(
		private taskService          : TaskService,
		private activeUserService    : ActiveUserService,
		private userService          : UserService,
		private formBuilder          : FormBuilder,
		private router               : Router,
		private route                : ActivatedRoute,
		private templateService      : TemplateService,
		private formGeneratorService : FormGeneratorService,
		private accountService       : AccountService,
		private dateTimeFormat       : DateTimeFormatterService
	)
	{
		this.user                    = this.activeUserService.getUser();
		this.subtaskControl          = new FormControl();
		this.userSelectControl       = new FormControl();
		this.taskTitleControl        = new FormControl();
		this.receivedOnControl       = new FormControl();
		this.accountControl          = new FormControl();
		this.subtaskInstanceMappings = this.formBuilder.array([]);
		this.taskMappings            = this.formBuilder.array([]);
		this.submitted               = false;

		this.addTaskForm = this.formBuilder.group({
			taskDetails             : null,
			taskMappings            : this.taskMappings,
			subtaskInstanceMappings : this.subtaskInstanceMappings
		});

		this.fa = { faCaretDown, faCaretRight, faExclamationTriangle, faExclamationCircle };
	}

	ngOnInit() : void
	{
		this.accountService.getAccountDetails(this.user.userId).subscribe(onSuccess.bind(this));
		function onSuccess(this : CreateTaskComponent, response : AccountDetails[]) : void
		{
			this.accounts = response;

			let queryAccountId = this.route.snapshot.queryParams.accountId;
			if(queryAccountId)
			{
				let queryAccount = this.accounts.find(account => account.accountId == queryAccountId);
				this.accountControl.setValue(queryAccount);
			}
			else this.accountControl.setValue(this.accounts[0]);
		}
		this.onAccountSelect();
	}

	subInstance(i) : any { return this.subtaskInstanceMappings.controls[i]; }
	userInstance(i) : any { return this.taskMappings.controls[i]; }

	onAccountSelect() : void
	{
		this.accountControl.valueChanges.pipe(map(clearPerviousData.bind(this))).subscribe(onValueChange.bind(this));
		function clearPerviousData(this : CreateTaskComponent, value : AccountDetails) : AccountDetails
		{
			if(!!this.selectedAccount && this.selectedAccount.accountId != value.accountId)
			{
				this.selectedTemplate = this.config = this.properties = null;
				this.addTaskForm.reset();
			}
			return value;
		}

		function onValueChange(this : CreateTaskComponent, value : AccountDetails) : void
		{
			this.selectedAccount = value;
			this.templateService.getAccountTemplates(value.accountId).subscribe(data => {
				this.templates = data;

				let id = this.route.snapshot.queryParams.templateId;

				if (id)
				{
					let template = this.templates.find(template => template.templateId == id);
					this.addTaskForm.controls.taskDetails.setValue(template);
					this.onTemplateSelect(template);
				}
			});
		}
	}

	onTemplateSelect(template : MasterTemplate) : void
	{
		this.preTemplateSelect(template);

		forkJoin({
			config     : this.templateService.getTemplateConfig(template.templateId),
			properties : this.templateService.getTemplateDetails(template.templateId),
			users      : this.userService.getUsers({ accountId : this.selectedAccount.accountId, subAccountId : template.secondaryEntity, functionCode : "canprocesstask"})
		}).subscribe(data => {
			Object.assign(this, data);

			this.addTaskForm.addControl('taskPropList', new FormControl(this.properties.customFields));
			this.customFieldsForm = this.formGeneratorService.generateForm(this.properties.customFields);
			this.basicDetailsForm = this.formGeneratorService.generateForm(this.properties.basicFields);

			for (let property of this.properties.customFields)
			{
				if (property.type == 'checkbox')
					this.customFieldsForm.controls[property.propertyName].patchValue(property.childs.map(child => !!property.value ? property.value.includes(child.propertyName) : null));

				else if (property.type == 'multiselect' || property.type == 'multiselectcheck')
					this.customFieldsForm.controls[property.propertyName].patchValue(property.value ? (property.value || '').split(',') : null);

				else if (!property.value) this.customFieldsForm.controls[property.propertyName].patchValue(undefined);
			}

			if(this.config.createunassignedtsk && this.user.accessLevel != 'useraccess') {
				this.users.push({ fullName : 'Unassigned', userId : " "} as User)
			}

			if (this.users.length == 1)
			{
				this.userSelectControl.setValue(this.users);
				this.onUserSelect(this.users);
			}
		});
	}

	onSubtaskSelect(subtask : MasterTemplate[]) : void
	{
		subtask.forEach((task, index) => {
			this.subtaskInstanceMappings.setControl(index, this.generateSubtaskMappingControl(task.templateId));
		});
	}

	removeSubtaskMappingControl(index : number) : void
	{
		let temp = (this.subtaskControl.value as MasterTemplate[]);
		temp.splice(index, 1);
		this.subtaskControl.setValue(temp);
		this.subtaskInstanceMappings.removeAt(index);
	}

	onUserSelect(users : User[]) : void
	{
		users.forEach((user, index) => {
			this.taskMappings.setControl(index, this.generateMappingControl(user.userId));
		});
	}

	removeMappingControl(index : number) : void
	{
		let temp = (this.userSelectControl.value as User[]);
		temp.splice(index, 1);
		this.userSelectControl.setValue(temp);
		this.taskMappings.removeAt(index);
	}

	createTask() : void
	{
		this.submitted              = true;

		if (this.submitted && this.subtaskInstanceMappings.invalid) this.accordionBasic.isOpen = true;
		else if (this.submitted && (this.userSelectControl.invalid || this.taskMappings.invalid)) this.accordionUser.isOpen = true;

		if (this.addTaskForm.invalid || this.customFieldsForm.invalid || this.userSelectControl.invalid) return;

		let data                    = { ...this.addTaskForm.value };
		data.taskDetails.title      = this.basicDetailsForm.value.title;
		data.taskDetails.subtitle   = this.basicDetailsForm.value.subtitle;
		data.taskDetails.subtitle2  = this.basicDetailsForm.value.subtitle2;
		data.taskDetails.receivedOn = this.receivedOnControl.value ? this.dateTimeFormat.toISO(this.receivedOnControl.value) : null;
		data.templateId             = this.selectedTemplate.templateId;
		for (let property of data.taskPropList) this.taskService.setPropertyValue(property, this.customFieldsForm.value);

		this.taskService.createMultipleTask(data).subscribe(() => {
			this.submitted = false;
			this.router.navigate(['tasks'], {queryParams : {accountId : this.selectedAccount.accountId ,templateId : this.selectedTemplate.templateId}})
		});
	}

	private generateMappingControl(userId : string = null) : FormGroup
	{
		return this.formBuilder.group({
			instance   : [null, [Validators.required, Validators.max(200)]],
			assignedTo : [userId, Validators.required]
		});
	}

	private generateSubtaskMappingControl(templateId : number = null) : FormGroup
	{
		return this.formBuilder.group({
			instance   : [null, [Validators.required, Validators.max(200)]],
			templateId : [templateId, Validators.required]
		});
	}

	private preTemplateSelect(template : MasterTemplate) : void
	{
		this.selectedTemplate = template;
		// this.currentDateTime = this.dateTimeFormat.getTodaysDate((template.timeZones.find(tz => tz.isDefault).utcOffset));
		this.receivedOnControl.reset();
		this.subtaskControl.reset();
		if(this.addTaskForm.get('taskPropList')) this.addTaskForm.removeControl('taskPropList');
		while (this.subtaskInstanceMappings.length !== 0)
		{
			this.subtaskInstanceMappings.removeAt(0);
		}

		if (template.subtaskTemplates.length == 1)
		{
			this.subtaskControl.setValue(template.subtaskTemplates);
			this.onSubtaskSelect(template.subtaskTemplates)
		}
	}

	calculateMaxDate() : void
	{
		this.currentDateTime = this.dateTimeFormat.getTodaysDate((this.selectedTemplate.timeZones.find(tz => tz.isDefault).utcOffset));
	}
}