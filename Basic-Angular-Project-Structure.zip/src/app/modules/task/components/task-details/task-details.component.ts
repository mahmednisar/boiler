import { Component, Input, EventEmitter, Output, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { forkJoin, Subscription } from 'rxjs';
import { debounceTime, filter, map } from 'rxjs/operators';

import { IconDefinition, faTimes, faEye, faInfoCircle, faExclamationTriangle } from '@fortawesome/pro-regular-svg-icons';
import { faCaretDown, faCaretRight } from '@fortawesome/pro-solid-svg-icons';
import { faScrubber, faClock, faCheckCircle, faMinusCircle, faTimesCircle, faPauseCircle } from '@fortawesome/pro-duotone-svg-icons';
import { TaskStatusIcons } from '../../constants/task-status.enum';

import { TaskService } from 'src/app/services/task.service';
import { TemplateService } from 'src/app/services/template.service';
import { FormGeneratorService } from 'src/app/services/form-generator.service';
import { CommonTaskService } from '../common-task.service';
import { TaskQuery } from '../../state/task.query';
import { TaskSessionService } from '../../state/task-session.service';
import { ActiveUserService } from 'src/app/services/active-user.service';

import { Task } from 'src/app/models/Task.model';
import { CustomField, MasterTemplateProperties } from 'src/app/models/MasterTemplateProperties.model';
import { User } from 'src/app/models/User.model';
import { TaskStatus } from 'src/app/models/TaskStatus.model';
import { Lookups } from 'src/app/models/lookup.model';
import { MasterTemplate } from 'src/app/models/MasterTemplate.model';
import { ActiveUser } from 'src/app/models/active-user.model';
import { MetricsConfiguration } from 'src/app/models/MetricsConfiguration.model';
import { DateTimeFormatterService } from 'src/app/services/date-time-formatter.service';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { isEqual } from 'lodash';
import { HoldLogs } from 'src/app/models/task-administration.model';
import { PanelService } from 'src/app/modules/panels/panel.service';
import { TaskAuditComponent } from '../task-audit/task-audit.component';
import { AuthorizationService } from 'src/app/services/authorization.service';


@Component({
	selector    : 'task-details',
	templateUrl : './task-details.component.html',
	styleUrls   : ['./task-details.component.scss'],
	providers   : [CommonTaskService]
})
export class TaskDetailsComponent implements OnInit, OnDestroy {

	@ViewChild('staticTabs', { static: false }) staticTabs: TabsetComponent;
	
	@Input() users           : User[];
	@Input() priority        : Lookups[];
	@Input() metrics         : MetricsConfiguration[];
	@Input() status          : TaskStatus[];
	@Input() config          : any;
	@Input() canProcessTasks : boolean;

	@Output() closeWindow   = new EventEmitter();
	@Output() statusChanged = new EventEmitter();

	fa                   : Record<string, IconDefinition>;
	icons                : typeof TaskStatusIcons;
	templateSubscription : Subscription
	taskSubscription     : Subscription;
	stateSubscription    : Subscription;
	taskIdSubscription   : Subscription;

	customFieldsForm     : FormGroup;
	titleEditControl     : FormControl;
	subTitleEditControl  : FormControl;
	assignedEditControl  : FormControl;
	recievedEditControl  : FormControl;
	
	template             : MasterTemplate;
	props                : MasterTemplateProperties;
	selectedSubtask      : Task;
	user                 : ActiveUser;
	qualityMetric        : MetricsConfiguration;
	escalateMetric       : MetricsConfiguration;
	holdLogs             : HoldLogs[];
	task                 : Task;
	actions              : Record<string, any>
	
	selectedSubtaskIndex : number;
	selectedTab          : string;
	previousTaskId       : number;
	previousState        : string;
	qualityConfig        : any;
	escalateConfig       : any;
	displayFormat        : string;
	isPatchEvent         : boolean;
	canEditTasks         : boolean;

	constructor(
		private activeUser           : ActiveUserService,
		private taskService          : TaskService,
		private templateService      : TemplateService,
		private formGeneratorService : FormGeneratorService,
		private commonTaskService    : CommonTaskService,
		private taskQuery            : TaskQuery,
		private taskSessionService   : TaskSessionService,
		private panelService         : PanelService,
		private authorization        : AuthorizationService
	) {
		this.user                = this.activeUser.getUser();
		this.fa                  = { faTimes, faScrubber, faClock, faCheckCircle, faMinusCircle, faTimesCircle, faPauseCircle, faEye, faInfoCircle, faCaretDown, faCaretRight, faExclamationTriangle };
		this.icons               = TaskStatusIcons;
		this.titleEditControl    = new FormControl();
		this.subTitleEditControl = new FormControl();
		this.assignedEditControl = new FormControl();
		this.recievedEditControl = new FormControl();
		this.customFieldsForm    = new FormGroup({});
		this.displayFormat       = DateTimeFormatterService.DateTime;
	}

	ngOnInit() : void
	{
		this.templateSubscription = this.taskQuery.getSelectedTemplate.subscribe(selectedTemplate => this.template = selectedTemplate);
		this.taskIdSubscription   = this.taskQuery.getPreviousTaskId.subscribe(id => this.previousTaskId = id);
		this.stateSubscription    = this.taskQuery.getPreviousState.subscribe(state => this.previousState = state);
		this.taskSubscription     = this.taskQuery.getSelectedTask.subscribe(task => this.onTaskChange(task));
	}

	ngOnDestroy() : void
	{
		this.templateSubscription.unsubscribe();
		this.taskIdSubscription.unsubscribe();
		this.stateSubscription.unsubscribe();
		this.taskSubscription.unsubscribe();
	}

	private onTaskChange(this: TaskDetailsComponent, selectedTask : Task) : void
	{
		this.task = selectedTask;
		forkJoin({
			props    : this.templateService.getTemplateDetails(this.template.templateId, false, this.task.createdOn),
			holdLogs : this.taskService.getHoldLogs(this.template.templateId, this.task.taskId),
			actions  : this.authorization.getNavigations(this.user.roleId)
		})
		.pipe(filter(taskIfChanged.bind(this)), map(generateFormAndValidations.bind(this)))
		.subscribe(onSuccess.bind(this));

		function taskIfChanged(this : TaskDetailsComponent, data : any) : boolean
		{
			return !this.config.tskautostart || !isEqual(this.task.state, this.previousState) || !isEqual(this.task.taskId, this.previousTaskId);
		}

		function generateFormAndValidations(this : TaskDetailsComponent, data : any) : any // Form & Validations
		{
			data.props.customFields.forEach(field => {
				field.isMandatory = field.validations.some(validation => validation.validationType == 'mandatory');
				field.isReadonly  = field.validations.some(validation => validation.validationType == 'readonly');
			});
			this.customFieldsForm = this.formGeneratorService.generateForm(data.props.customFields);
			this.commonTaskService.patchData(this.task, this.template.templateId, this.customFieldsForm, data.props.customFields, true);
			this.isPatchEvent = true;
			return data;
		}

		function onSuccess(this : TaskDetailsComponent, data : any) : any
		{
			Object.assign(this, data);

			this.taskSessionService.updatePreviousTaskId(this.task.taskId);
			this.taskSessionService.updatePreviousState(this.task.state);

			this.qualityMetric  = this.metrics.find(item => item.metricName == 'Quality');
			this.qualityConfig  = this.qualityMetric ? this.qualityMetric.configurations : null;
			this.canEditTasks   = this.actions.functions.some(funct => funct.code == 'canedittask');
			this.checkIfFormEnabled();
		}
	}

	updateTask() : void
	{
		if (this.customFieldsForm.invalid) return;

		let field = this.props.customFields;
		for (let property of field) this.taskService.setPropertyValue(property, this.customFieldsForm.value);
		this.taskService.updateTask(this.template.templateId, this.task, field).subscribe(response => this.updateSelectedTask(response.data))
	}

	startTask() : void
	{
		this.taskService.startTask(this.template.templateId, this.task.taskId).subscribe(response => this.updateSelectedTask(response.data));
	}

	changeTaskStatus(statusId : number) : void
	{
		this.taskService.changeTaskStatus(this.template.templateId, this.task.taskId, statusId).subscribe(response => this.updateSelectedTask(response.data));
	}

	auditTask(task : Task) : void
	{
		this.panelService.open(TaskAuditComponent, null);
	}

	private updateSelectedTask(updatedTask) : void
	{
		this.statusChanged.emit(updatedTask);
		this.checkIfFormEnabled();
	}

	private checkIfFormEnabled() : void
	{
		if ((this.user.userId == this.task.assignedTo) && this.config.tskautostart)
		{
			this.customFieldsForm.statusChanges.pipe(debounceTime(250)).subscribe(statusChanged.bind(this));
			function statusChanged(this : TaskDetailsComponent) : void
			{
				if(this.isPatchEvent)
				{
					this.isPatchEvent = false;
					return;
				}
				if (this.task.state == 'new') this.startTask();
			}
		}

		if (((this.user.userId == this.task.assignedTo) && !this.task.isEditable) || !this.canEditTasks) this.customFieldsForm.disable();
	}
}
