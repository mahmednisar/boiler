import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';

import { TemplateService } from 'src/app/services/template.service';
import { ActiveUserService } from 'src/app/services/active-user.service';
import { TaskService } from 'src/app/services/task.service';
import { AccountService } from 'src/app/services/account.service';
import { CommonService } from 'src/app/services/common.service';

import { faCloudUploadAlt, faCloudDownloadAlt, IconDefinition } from '@fortawesome/pro-solid-svg-icons';
import { faFileCheck, faFileTimes } from '@fortawesome/pro-duotone-svg-icons';

import { MasterTemplate } from 'src/app/models/MasterTemplate.model';
import { BulkLogs } from 'src/app/models/bulk-logs.model';
import { ActiveUser } from 'src/app/models/active-user.model';
import { AccountDetails } from 'src/app/models/acount-details.model';
import { map, switchMap } from 'rxjs/operators';

@Component({
	selector    : 'bulk-upload',
	templateUrl : './bulk-upload.component.html',
	styleUrls   : ['./bulk-upload.component.scss']
})
export class BulkUploadComponent implements OnInit {

	user             : ActiveUser;
	fa               : Record<string, IconDefinition>;
	templates        : MasterTemplate[];
	accounts         : AccountDetails[];
	templateSelect   : FormControl;
	accountSelect    : FormControl;
	selectedTemplate : MasterTemplate;
	selectedAccount  : AccountDetails;
	logs             : BulkLogs[];
	totalLogs        : number;
	pageSize         : number;
	currentTimezone  : string;
	config           : any;
	
	displayedColumns = ['Uploaded Date', 'Uploaded By', '# Success', '# Failure', 'Files'];

	constructor(
		private templateService   : TemplateService,
		private activeUserService : ActiveUserService,
		private taskService       : TaskService,
		private accountService    : AccountService,
		private commonService     : CommonService,
	) {
		this.fa             = { faFileCheck, faFileTimes, faCloudUploadAlt, faCloudDownloadAlt }
		this.user           = this.activeUserService.getUser();
		this.templateSelect = new FormControl();
		this.accountSelect  = new FormControl();
		this.pageSize       = 20;
	}

	ngOnInit() : void
	{
		this.accountService.getAccountDetails(this.user.userId).subscribe(onSuccess.bind(this));
		function onSuccess(this : BulkUploadComponent, response : AccountDetails[]) : void
		{
			this.accounts = response;
			this.accountSelect.setValue(this.accounts[0]);
		}

		this.onAccountChange();
		this.onTemplateChange();
	}

	onAccountChange() : void
	{
		this.accountSelect.valueChanges
			.pipe(
				map(clearPreviousData.bind(this)),
				map(getTemplates.bind(this))
			).subscribe((value: AccountDetails) => {
				this.selectedAccount = value;
			});

		function clearPreviousData(this: BulkUploadComponent, account: AccountDetails) : AccountDetails
		{
			this.templates        = null;
			this.selectedTemplate = null;
			this.currentTimezone  = null;
			this.templateSelect.setValue(null);

			return account;
		}

		function getTemplates(this: BulkUploadComponent, account: AccountDetails) : AccountDetails
		{
			this.templateService.getAccountTemplates(account.accountId).subscribe((template : MasterTemplate[]) => {
				this.templates = template;
				this.templateSelect.setValue(this.templates[0]);
			});
			return account;
		}
	}

	onTemplateChange() : void
	{
		this.templateSelect.valueChanges.subscribe(onTemplateSelected.bind(this));

		function onTemplateSelected(this: BulkUploadComponent, template : MasterTemplate) : void
		{
			if(!template) return;

			this.selectedTemplate = template;
			this.currentTimezone  = template.timeZones.find(zone => zone.isDefault).timeZone;
			this.getTemplateConfig(template.templateId);
			this.getLogs(template.templateId, 1);
		}
	}

	getTemplateConfig(templateId : number) : void
	{
		this.templateService.getTemplateConfig(templateId).subscribe(response => this.config = response);
	}
 
	getLogs(templateId : number, pageNo : number) : void
	{
		let params = 
		{
			TemplateId         : templateId,
			PageNo             : pageNo,
			NoOfRecordsPerPage : this.pageSize
		}
		this.taskService.GetTaskBulkUploadLogs(params).subscribe(onSuccess.bind(this));

		function onSuccess(this : BulkUploadComponent, data : any) : void
		{
			this.logs      = data.data;
			this.totalLogs = data.count;
		}
	}

	uploadExcel(event) : void
	{
		let element = event.target as HTMLInputElement;
		this.taskService.uploadExcel(this.selectedTemplate.templateId, element.files[0]).subscribe(onSuccess.bind(this));
		element.value = null;

		function onSuccess(this : BulkUploadComponent) : void
		{
			this.getLogs(this.selectedTemplate.templateId, 1);
		}
	}

	downloadTemplate(selectedTemplate : MasterTemplate) : void 
	{
		this.taskService.downloadBulkUploadExcel(selectedTemplate.templateId).subscribe(onSuccess.bind(this));

		function onSuccess(this : BulkUploadComponent, response : any) : void
		{
			let fileName = `${this.selectedTemplate.templateName}-Template.xlsx`;
			this.commonService.downloadBlob(response, fileName);
		}
	}
}