import { Injectable } from '@angular/core';
import { TaskService } from 'src/app/services/task.service';
import { Task } from 'src/app/models/Task.model';
import { FormGroup } from '@angular/forms';
import { CustomField } from 'src/app/models/MasterTemplateProperties.model';
import { map } from 'rxjs/operators';
import { DateTimeFormatterService } from 'src/app/services/date-time-formatter.service';
import { DateTime } from 'luxon';
import { clone, cloneDeep, property } from 'lodash';

@Injectable()
export class CommonTaskService
{
	constructor(private taskService : TaskService, private dateTimeFormat : DateTimeFormatterService){}

	patchData(task : Task, templateId : number, form : FormGroup, field : CustomField[], eventEmit ?: boolean, isAudit ?: boolean) : void
	{
		this.taskService
			.getTaskCustomFieldValues(task, templateId, !!isAudit)
			.pipe(map(generateData.bind(this)))
			.subscribe(data => {
				let backup        = cloneDeep(data);
				let cascadingKeys = [];
				for (let property of field)
				{
					if(property.validations.some(validation => validation.validationType == 'cascadingDropdown'))
					{
						delete data[property.propertyName];
						cascadingKeys.push(property.propertyName);
					}
				}
				cascadingKeys.forEach(key => Object.defineProperty(data, key, { value : backup[key], enumerable : true }));
				form.patchValue(data, {emitEvent : eventEmit || false});

			});

		function generateData(this : CommonTaskService , data : any) : any
		{
			for (let property of field)
			{
				if (property.type == 'checkbox')
					data[property.propertyName] = property.childs.map(child => (data[property.propertyName] || '').split(',').includes(child.propertyName));

				else if (property.type == 'multiselect' || property.type == 'multiselectcheck')
					data[property.propertyName] = data[property.propertyName] ? (data[property.propertyName] || '').split(',') : null;

				else if (!data[property.propertyName]) data[property.propertyName] = undefined;

				else if (property.type == 'date' && data[property.propertyName])
					data[property.propertyName] = DateTime.fromISO((data[property.propertyName].split('T')[0]), {zone : 'local'}).toString();

				else if (property.type == 'datetime' && data[property.propertyName])
					data[property.propertyName] = DateTime.fromISO((data[property.propertyName]).slice(0, -1), {zone : 'local'}).toString();

			}
			return data;
		}
	}

	getColumnConfig(type: string): string[] 
	{
		switch (type)
		{
			case 'default' : return ['status', 'title', 'subtitle', 'subtitle2', 'assignedToName', 'createdOn', 'assignedOn', 'startedOn', 'endedOn', 'completionTime', 'badges', 'actions'];
			case 'short'   : return ['status', 'title', 'subtitle', 'subtitle2', 'actions'];
			case 'check'   : return ['checkbox', 'status', 'title', 'subtitle', 'subtitle2', 'assignedToName', 'createdOn', 'assignedOn', 'startedOn', 'endedOn', 'completionTime', 'badges', 'actions'];
		}
	}

	getFilterConfig(type : string) : string[]
	{
		switch (type)
		{
			case 'default' : return ['fil-status', 'fil-title', 'fil-subtitle', 'fil-subtitle2', 'fil-assignedToName', 'fil-createdOn', 'fil-assignedOn', 'fil-startedOn', 'fil-endedOn', 'fil-completionTime', 'fil-badges', 'fil-actions']
			case 'short'   : return ['fil-status', 'fil-title', 'fil-subtitle', 'fil-subtitle2', 'fil-actions']
			case 'check'   : return ['fil-checkbox', 'fil-status', 'fil-title', 'fil-subtitle', 'fil-subtitle2', 'fil-assignedToName', 'fil-createdOn', 'fil-assignedOn', 'fil-startedOn', 'fil-endedOn', 'fil-completionTime', 'fil-badges', 'fil-actions']
		}
	}
}