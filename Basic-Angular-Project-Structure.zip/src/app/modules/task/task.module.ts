import { NgModule } from '@angular/core';

import { CommonModule } from '@angular/common';
import { TaskRoutingModule } from './task-routing.module';
import { ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { SharedModule } from '../shared/shared.module';
import { CustomFieldsModule } from '../custom-fields/custom-fields.module';
import { HighchartsChartModule } from 'highcharts-angular';
import { CdkTableModule } from '@angular/cdk/table';

import { PaginationModule } from 'ngx-bootstrap/pagination';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { ModalModule } from 'ngx-bootstrap/modal';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from '@danielmoncada/angular-datetime-picker';
import { PanelsModule } from '../panels/panels.module';

import {components} from './components';
import { CopyTaskComponent } from './components/copy-task/copy-task.component';

@NgModule({
	declarations : [...components],
	entryComponents : [ CopyTaskComponent ],
	imports :
	[
		TaskRoutingModule,
		CommonModule,
		ReactiveFormsModule,
		NgSelectModule,
		FontAwesomeModule,
		SharedModule,
		CustomFieldsModule,
		HighchartsChartModule,
		CdkTableModule,
		PanelsModule,
		
		PaginationModule.forRoot(),
		TabsModule.forRoot(),
		AccordionModule.forRoot(),
		PopoverModule.forRoot(),
		TooltipModule.forRoot(),
		ModalModule.forRoot(),
		CollapseModule.forRoot(),
		OwlDateTimeModule,
		OwlNativeDateTimeModule,
	]
})
export class TaskModule {}