import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService } from 'src/app/services/auth-guard.service';

import { AppLayoutComponent } from '../shared/components/app-layout/app-layout.component';
import { CreateTaskComponent } from './components/create-task/create-task.component';
import { TaskListComponent } from './components/task-list/task-list.component';
import { BulkUploadComponent } from './components/bulk-upload/bulk-upload.component';

let routes : Routes =
[
	{
		path             : '',
		component        : AppLayoutComponent,
		canActivateChild : [AuthGuardService],
		children         :
		[
			{
				path        : 'tasks',
				component   : TaskListComponent,
				data        : {title: 'Task', pageId : 'task_list'}
			},
			{
				path        : 'create-tasks',
				component   : CreateTaskComponent,
				data        : {title: 'Create Task', pageId : 'create_task'}
			},
			{
				path        : 'bulk-upload',
				component   : BulkUploadComponent,
				data        : {title : 'Bulk Upload', pageId : 'bulk_upload'}
			}
		]
	}
];

@NgModule({
	imports : [RouterModule.forChild(routes)],
	exports : [RouterModule]
})
export class TaskRoutingModule {}