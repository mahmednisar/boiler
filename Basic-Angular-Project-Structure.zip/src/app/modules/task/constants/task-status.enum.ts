export enum TaskStatus {
	New       = "new",
	InProg    = "inprogress",
	Closed    = "closed",
	Rejected  = "rejected",
	Discarded = "discarded",
	Hold      = "hold"
}

export enum TaskStatusText {
	new        = "New",
	inprogress = "In Progress",
	closed     = "Closed",
	hold       = "Hold"
}

export enum TaskStatusIcons {
	new        = "faScrubber",
	inprogress = "faClock",
	closed     = "faCheckCircle",
	rejected   = "faTimesCircle",
	discarded  = "faMinusCircle",
	hold       = "faPauseCircle"
}