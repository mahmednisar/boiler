export enum TaskPriorityIcons {
	low    = "faAngleDoubleDown",
	medium = "faAngleUp",
	high   = "faAngleDoubleUp",
}