import { AccountsModule } from './accounts/accounts.module';
import { ConfigModule } from './config/config.module';
import { CustomFieldsModule } from './custom-fields/custom-fields.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { EmployeeModule } from './employee/employee.module';
import { TargetsModule } from './targets/targets.module';
import { TaskModule } from './task/task.module';
import { PanelsModule } from './panels/panels.module';
import { UserModule } from './user/user.module';

export let modules = [
	AccountsModule,
	ConfigModule,
	CustomFieldsModule,
	DashboardModule,
	EmployeeModule,
	TargetsModule,
	TaskModule,
	PanelsModule,
	UserModule
];