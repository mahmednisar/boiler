import { Directive, OnInit, ElementRef, Input } from '@angular/core';

import { ActiveUserService } from 'src/app/services/active-user.service';
import { AuthorizationService } from 'src/app/services/authorization.service';

@Directive({ selector: '[restrictAction]'})
export class RestrictActionDirective implements OnInit {

	constructor(
		private element       : ElementRef,
		private userService   : ActiveUserService,
		private authorization : AuthorizationService
	) {}

	@Input('restrictAction') allowedActions : string;

	ngOnInit() : void
	{
		let activeUser = this.userService.getUser();
		this.authorization.getNavigations(activeUser.roleId).subscribe(onSuccess.bind(this));

		function onSuccess(this : RestrictActionDirective, response : any) : void
		{
			var temp : boolean = response.actions.some(action => action.code == this.allowedActions);
			if(!temp) (this.element.nativeElement as HTMLElement).remove();
		}
	}

}
