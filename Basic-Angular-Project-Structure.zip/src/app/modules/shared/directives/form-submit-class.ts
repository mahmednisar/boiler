import { Directive, HostBinding } from '@angular/core';
import { FormGroupDirective } from '@angular/forms';

@Directive({ selector: 'form[formGroup]' })
export class FormSubmitClassDirective {
	constructor(private ngForm : FormGroupDirective) {}

	@HostBinding ('class.ng-submitted') get isSubmitted() : boolean {
		return this.ngForm.submitted;
	}
}