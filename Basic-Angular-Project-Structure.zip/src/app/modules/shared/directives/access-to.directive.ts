import { Directive, ElementRef, Input, OnInit } from '@angular/core';
import { ActiveUserService } from 'src/app/services/active-user.service';

@Directive({ selector: '[accessTo]' })
export class AccessToDirective implements OnInit
{
	constructor(private element : ElementRef, private userService : ActiveUserService) {}

	@Input('accessTo') allowedRoles : string;

	ngOnInit() : void
	{
		let role = this.userService.getUser().role;
		if (!this.allowedRoles.includes(role)) (this.element.nativeElement as HTMLElement).remove();
	}
}