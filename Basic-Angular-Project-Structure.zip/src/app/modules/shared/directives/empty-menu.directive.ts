import { Directive, OnInit, ElementRef } from '@angular/core';

@Directive({ selector: '[emptyMenu]' })
export class EmptyMenuDirective implements OnInit {

	constructor(private element: ElementRef) { }

	ngOnInit() : void
	{
		setTimeout(() => {
			var childCount = (this.element.nativeElement as HTMLElement).querySelector('.submenu').childElementCount;
			if (childCount == 0) (this.element.nativeElement as HTMLElement).remove();
		}, 1000);
	}

}
// This Directive is used to check if submenu is empty or not and if empty remove the parent menu of the submenu class