import { Directive, OnInit, ElementRef, Input } from '@angular/core';

import { ActiveUserService } from 'src/app/services/active-user.service';
import { AuthorizationService } from 'src/app/services/authorization.service';

import { ScreenCodes } from 'src/app/models/ScreenCodes.model';

@Directive({ selector: '[controlMenu]'})
export class ControlMenuDirective implements OnInit {

	constructor(
		private element       : ElementRef,
		private userService   : ActiveUserService,
		private authorization : AuthorizationService
	) {}

	@Input('controlMenu') allowedMenu : string;

	ngOnInit() : void
	{
		let activeUser = this.userService.getUser();
		this.authorization.getNavigations(activeUser.roleId).subscribe(onSuccess.bind(this));

		function onSuccess(this : ControlMenuDirective, response : any) : void
		{
			var temp : boolean = response.screens.some(screen => screen.code == this.allowedMenu);
			if(!temp) (this.element.nativeElement as HTMLElement).remove();
		}
	}

}
