import { Directive, ElementRef, AfterViewInit } from '@angular/core';

@Directive({
	selector : '[focus-on-view]'
})
export class FocusOnViewDirective implements AfterViewInit
{
	constructor(private element : ElementRef) {}

	ngAfterViewInit() : void
	{
		setTimeout(() => {
			this.element.nativeElement.focus();
		}, 300);
	}
}