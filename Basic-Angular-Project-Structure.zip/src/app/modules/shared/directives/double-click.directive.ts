import { Directive, EventEmitter, HostListener, Output } from '@angular/core';

@Directive({
	selector : '[doubleClick]'
})

export class DoubleClickDirective
{
	@Output() eventTriggered = new EventEmitter();

	isSingleClick : Boolean;

	constructor() {
		this.isSingleClick = true;
	}

	@HostListener("dblclick") onDoubleClicked() {
		this.isSingleClick = false;
		this.eventTriggered.emit(false);
	}

	@HostListener("click") onClicked() {
		this.isSingleClick = true;
		setTimeout(() => {
			if (this.isSingleClick) {
				this.eventTriggered.emit(true);
			}
		}, 250);
	}
}
