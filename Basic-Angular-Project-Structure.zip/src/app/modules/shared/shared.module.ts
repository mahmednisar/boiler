import { NgModule } from '@angular/core';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { TooltipModule } from 'ngx-bootstrap/tooltip';

import { AppMenuComponent } from './components/app-menu/app-menu.component';
import { AppLayoutComponent } from './components/app-layout/app-layout.component';
import { LoaderComponent } from './components/loader/loader.component';
import { SubmitButtonComponent } from './components/submit-button/submit-button.component';
import { StatusIconComponent } from './components/status-icon/status-icon.component';
import { PasswordInstructionComponent } from './components/password-instruction/password-instruction.component';

import { AccessToDirective } from './directives/access-to.directive';
import { FormSubmitClassDirective } from './directives/form-submit-class';
import { FocusOnViewDirective } from './directives/focus-on-view.directive';
import { EmptyMenuDirective } from './directives/empty-menu.directive';
import { ControlMenuDirective } from './directives/control-menu.directive';
import { RestrictActionDirective } from './directives/restrict-action.directive';
import { DoubleClickDirective } from './directives/double-click.directive';
import { BackButtonDirective } from './directives/back-button.directive';

import { LabelControl } from './directives/label-control.directive';
import { TzDatePipe } from './pipes/tz-date.pipe';
import { DurationPipe } from './pipes/duration.pipe';
import { AccountNamePipe } from './pipes/account-name.pipe';
import { GroupByPipe } from './pipes/group-by.pipe';
import { GrantAccessComponent } from './components/grant-access/grant-access.component';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from '@danielmoncada/angular-datetime-picker';
import { ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { D3OrgChartComponent } from './components/d3-org-chart/d3-org-chart.component';

let components = [
	AppLayoutComponent,
	AppMenuComponent,
	SubmitButtonComponent,
	LoaderComponent,
	StatusIconComponent,
	PasswordInstructionComponent,
	GrantAccessComponent,
	D3OrgChartComponent,

	FocusOnViewDirective,
	AccessToDirective,
	EmptyMenuDirective,
	ControlMenuDirective,
	RestrictActionDirective,
	FormSubmitClassDirective,
	DoubleClickDirective,
	BackButtonDirective,

	LabelControl,
	TzDatePipe,
	DurationPipe,
	AccountNamePipe,
	GroupByPipe,

];

@NgModule({
	declarations : [...components],
	exports      : [...components],
	imports      : [
		CommonModule,
		FontAwesomeModule,
		RouterModule,
		TooltipModule.forRoot(),
		OwlDateTimeModule,
		OwlNativeDateTimeModule,
		ReactiveFormsModule,
		NgSelectModule
	]
})
export class SharedModule {}