import { Component, EventEmitter, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IconDefinition, faTimes, faUser, faCalendarAlt } from '@fortawesome/pro-solid-svg-icons';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { ActiveUser } from 'src/app/models/active-user.model';
import { Employee } from 'src/app/models/employee.model';
import { AccessUsers } from 'src/app/models/external-access.model';
import { ActiveUserService } from 'src/app/services/active-user.service';
import { DateTimeFormatterService } from 'src/app/services/date-time-formatter.service';
import { ExternalAccessService } from 'src/app/services/external-access.service';

@Component({
	selector: 'grant-access',
	templateUrl: './grant-access.component.html',
	styleUrls: ['./grant-access.component.scss']
})
export class GrantAccessComponent implements OnInit
{
	public event = new EventEmitter();

	employee        : Employee;
	fa              : Record<string, IconDefinition>;
	users           : AccessUsers[];
	usersBuffer     : AccessUsers[];
	activeUser      : ActiveUser;
	grantAccessForm : FormGroup;
	today           : Date;
	endValidation   : Date;
	bufferSize      : number;
	fetchingMore    : number;

	constructor(
		public  activeModal           : BsModalRef,
		private activeUserService     : ActiveUserService,
		private externalAccessService : ExternalAccessService,
		private formBuilder           : FormBuilder,
		private dateTimeFormatter     : DateTimeFormatterService
	) {
		this.fa              = { faTimes, faUser, faCalendarAlt };
		this.bufferSize      = 50;
		this.fetchingMore    = 10;
		this.activeUser      = this.activeUserService.getUser();

		this.grantAccessForm = this.formBuilder.group({
			givenAccessUserId : this.activeUser.userId,
			isPermanentAccess : false,
			dateRange         : null,
			startDate         : null,
			endDate           : null,
			comment           : [null, Validators.required],
			userlist          : [null, Validators.required],
		});
	}

	ngOnInit(): void 
	{
		this.today = this.dateTimeFormatter.getTodayStartDate('-07:00:00');
		this.externalAccessService.getAccessUser().subscribe(onUsersGet.bind(this));
		function onUsersGet(this: GrantAccessComponent, response : AccessUsers[]) : void {
			this.users = response.filter(user => !user.isPermanentAccess && !user.hasAccess);
			this.usersBuffer = this.users.slice(0, this.bufferSize);
		};

		if(this.employee) {
			let userlist = [
			{
				userId   : this.employee.userId,
				fullName : `${this.employee.firstName} ${this.employee.lastName}`
			}
			];
			this.grantAccessForm.controls.userlist.setValue(userlist);
		}
	}

	onScroll({ end }) : void
	{
		if (this.users.length <= this.usersBuffer.length) return;
		if (end + this.fetchingMore >= this.usersBuffer.length) this.fetchMore()
	}

	onScrollToEnd() : void
	{
		this.fetchMore();
	}

	private fetchMore() : void
	{
		const more = this.users.slice(this.usersBuffer.length, this.bufferSize + this.usersBuffer.length);
		setTimeout(() => {
			this.usersBuffer = this.usersBuffer.concat(more);
		}, 200);
	}

	addTemporaryAccess() : void
	{
		if(this.grantAccessForm.invalid) return;

		let values       = {...this.grantAccessForm.value};
		values.startDate = values.isPermanentAccess ? this.dateTimeFormatter.toTimezoneISO(new Date(this.today.toString())) : this.dateTimeFormatter.toISO(values.dateRange[0]);
		values.endDate   = values.isPermanentAccess ? null : this.dateTimeFormatter.toTimezoneISO(new Date(values.dateRange[1]));
		values.userlist.forEach(item => delete item['isPermanentAccess']);

		this.externalAccessService.addTemporaryAccess(values).subscribe(onAccessGranted.bind(this));
		function onAccessGranted(this: GrantAccessComponent, response : any) : void
		{
			this.activeModal.hide();
			this.event.emit(true);
		}
	}

}
