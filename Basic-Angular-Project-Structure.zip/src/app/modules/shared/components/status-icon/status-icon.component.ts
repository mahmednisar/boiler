import { Component, Input, HostBinding, ChangeDetectionStrategy } from '@angular/core';
import { faScrubber, faClock, faCheckCircle, faQuestionCircle, faMinusCircle, faTimesCircle, IconDefinition, faPauseCircle } from '@fortawesome/pro-duotone-svg-icons';

@Component({
	selector        : 'status-icon',
	templateUrl     : './status-icon.component.html',
	styleUrls       : ['./status-icon.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush
})
export class StatusIconComponent {
	@Input() status : string;

	@HostBinding('class') class = 'd-contents';

	icon : IconDefinition;

	getIcon(status : string) : IconDefinition {
		switch(status) {
			case 'new'        : return faScrubber;
			case 'inprogress' : return faClock;
			case 'closed'     : return faCheckCircle;
			case 'unassigned' : return faQuestionCircle;
			case 'rejected'   : return faTimesCircle;
			case 'discarded'  : return faMinusCircle;
			case 'hold'       : return faPauseCircle;
		}
	}
}