import { Component, ElementRef, Input, OnChanges, OnInit, ViewChild } from '@angular/core';
import { OrgChart } from 'd3-org-chart';

@Component({
	selector    : 'd3-org-chart',
	templateUrl : './d3-org-chart.component.html',
	styleUrls   : ['./d3-org-chart.component.scss']
})
export class D3OrgChartComponent implements OnChanges
{
	@ViewChild('chartContainer') chartContainer : ElementRef;

	@Input() data    : any[];
	@Input() isUsers : boolean;

	chart : any;

	ngAfterViewInit() : void
	{
		if (!this.chart) this.chart = new OrgChart();
		this.updateChart();
	}

	ngOnChanges() : void
	{
		this.updateChart();
	}

	updateChart() : void
	{
		var vm = this;
		if (!vm.data || !vm.chart) return;
		var compact = 0;

		vm.chart
			.container(vm.chartContainer.nativeElement)
			.data(vm.data)
			.nodeWidth(d => 250)
			.nodeHeight(d => 150)
			.initialZoom(0.7)
			.childrenMargin(d => 40)
			.compactMarginBetween(d => 65)
			.compactMarginPair(d => 100)
			.buttonContent(({ node, state }) => {
				return `
				<div style="color: #716E7B; border-radius:5px; padding:4px 8px; font-size:14px; margin:auto; background-color:white; border: 1px solid #E4E2E9">
					<span>${node.data._directSubordinates}</span>
				</div>`;
			})
			.nodeContent(function (d, i, arr, state) {
				if(!vm.isUsers) {
				return `
					<div style="font-family: 'Roboto'; padding:16px; height: 100%; border: 2px solid ${d.data.color}; border-radius:5px; box-shadow:grey 4px 4px 8px 1px;">
						<p style="border-bottom : 20px solid white;border-right: 20px solid ${d.data.color};content:\'\';position:absolute;top:3px;right:3px;"> </p>
						<p style="padding-right:16px; word-wrap: break-word; border-bottom : 1px solid ${d.data.color}">
							<b style="font-size:20px; letter-spacing : 1px; font-weight:bold">${d.data.name}</b>
						</p>
						<p style="font-size:16px; font-weight:bold">Level: ${d.data.level}</p>
					</div>
					`
				}
				else {
					return `
					<div style="font-family: 'Roboto'; padding:16px; height: 100%; border: 2px solid ${d.data.bandColor}; border-radius:5px; box-shadow:grey 4px 4px 8px 1px;">
						<p style="border-bottom : 20px solid white;border-right: 20px solid ${d.data.bandColor};content:\'\';position:absolute;top:3px;right:3px;"> </p>
						<p style="padding-right:16px; word-wrap: break-word; border-bottom : 1px solid ${d.data.bandColor}">
							<b style="font-size:20px; letter-spacing : 1px; font-weight:bold">${d.data.userName}</b>
						</p>
						<p style="font-size:12px; font-weight:bold">Accounts : ${d.data.accountName}</p>
					</div>
					`
				}
			})
			.render();
			vm.chart.expandAll();
			vm.chart.compact(!!( compact ++%1)).render().fit()
	}
}
