import { Component } from '@angular/core';
import { ReplaySubject } from 'rxjs';
import { LoaderService } from 'src/app/services/loader.service';

@Component({
	selector    : 'app-loader',
	templateUrl : './loader.component.html',
	styleUrls   : ['./loader.component.scss']
})
export class LoaderComponent
{
	constructor(private loaderService : LoaderService) {}

	isLoading : ReplaySubject<boolean> = this.loaderService.isLoading;
}