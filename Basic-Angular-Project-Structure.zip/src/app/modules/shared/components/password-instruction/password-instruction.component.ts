import { Component, Input } from '@angular/core';

import { IconDefinition, faTimes, faCheck } from '@fortawesome/pro-solid-svg-icons';
import { FormControl } from '@angular/forms';

@Component({
	selector        : 'password-instruction',
	templateUrl     : './password-instruction.component.html',
})
export class PasswordInstructionComponent
{
	@Input() control : FormControl;
	icon : IconDefinition;

	getIcon(formControl : FormControl, validator: string): IconDefinition
	{
		if ( formControl.pristine || !!(formControl.errors && formControl.errors.required)) return faTimes;
		return (formControl.errors && formControl.errors[validator]) ? faTimes : faCheck;
	}

	getClass(formControl : FormControl, validator: string) : string
	{
		if ( formControl.pristine || !!(formControl.errors && formControl.errors.required)) return 'm-1 d-none';
		return (formControl.errors && formControl.errors[validator]) ? 'm-1 text-danger' : 'm-1 text-success';
	}

}
