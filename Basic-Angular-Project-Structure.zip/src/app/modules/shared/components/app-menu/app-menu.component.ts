import { Component, HostBinding } from '@angular/core';

import { ActiveUserService } from 'src/app/services/active-user.service';

import { ActiveUser } from 'src/app/models/active-user.model';

import { IconDefinition, faPlus, faHome, faPowerOff, faUserChart, faThList, faUserCircle, faFileUpload, faClipboardList, faAnalytics, faBullseyeArrow, faFileChartLine, faCube, faIdCard, faUserTag, faCog, faCogs, faUserUnlock, faSitemap, faCalendarDay } from '@fortawesome/pro-duotone-svg-icons';
import { faPlus as fasPlus, faHome as fasHome, faUserChart as fasUserChart, faThList as fasThList, faFileUpload as fasFileUpload, faClipboardList as fasClipboardList, faAnalytics as fasAnalytics, faBullseyeArrow as fasBullseyeArrow, faFileChartLine as fasFileChartLine, faCube as fasCube, faIdCard as fasIdCard, faCog as fasCog, faCogs as fasCogs, faUserUnlock as fasUserUnlock, faSitemap as fasSitemap, faCalendarDay as fasCalendarDay } from '@fortawesome/pro-solid-svg-icons';
import { Router } from '@angular/router';

@Component({
	selector    : 'app-menu',
	templateUrl : './app-menu.component.html',
	styleUrls   : ['./app-menu.component.scss']
})
export class AppMenuComponent
{
	@HostBinding('class') class = 'siteNav d-flex flex-column bg-dark';

	user : ActiveUser;
	fa   : Record<string, IconDefinition>;

	constructor(private activeUserService : ActiveUserService, private router : Router) {
		this.user  = this.activeUserService.getUser();
		this.fa    = { fasPlus, fasHome, fasUserChart, faPlus, faHome, faPowerOff, faUserChart, faThList, fasThList, faUserCircle, faFileUpload, fasFileUpload, faClipboardList, fasClipboardList, faAnalytics, fasAnalytics, faBullseyeArrow, fasBullseyeArrow, faFileChartLine, fasFileChartLine, faCube, fasCube, faIdCard, fasIdCard, faUserTag, faCog, fasCog, faCogs, fasCogs, faUserUnlock, fasUserUnlock, faSitemap, fasSitemap, faCalendarDay, fasCalendarDay };
	}

	logout() : void {
		this.activeUserService.removeUser();
	}

	changeRole() : void {
		this.router.navigateByUrl('role-selection');
	}

	userProfile() : void {
		this.router.navigate(['user-profile'], {queryParams : { userId : this.user.userId }})
	}
}