import { Component, Input, HostBinding } from '@angular/core';
import { IconDefinition, faSpinner } from '@fortawesome/pro-duotone-svg-icons';

@Component({
	selector        : 'submit-button',
	templateUrl     : './submit-button.component.html',
	styleUrls       : ['./submit-button.component.scss']
})
export class SubmitButtonComponent
{
	@HostBinding('class') class = 'buttonWrapper';

	@Input() submitting : boolean;

	@Input() defaultText = 'Save';
	@Input() submitText  = 'Saving';

	faSpinner : IconDefinition = faSpinner;
}