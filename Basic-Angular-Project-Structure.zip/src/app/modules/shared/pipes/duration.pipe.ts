import { Pipe, PipeTransform } from '@angular/core';
import { Duration } from 'luxon';

@Pipe({
	name : 'duration'
})
export class DurationPipe implements PipeTransform {
	transform(value : string , format : string) : string {
		return value ? Duration.fromObject({ seconds : +value }).toFormat(format) : null;
	}
}