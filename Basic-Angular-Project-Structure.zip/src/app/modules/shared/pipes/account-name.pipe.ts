import { Pipe, PipeTransform } from '@angular/core';
import { AccountDetails } from 'src/app/models/acount-details.model';

@Pipe({
	name : 'account'
})
export class AccountNamePipe implements PipeTransform {
	transform(value : number , accounts : AccountDetails[]) : string {
		return accounts.find(item => item.accountId == value).accountName;
	}
}