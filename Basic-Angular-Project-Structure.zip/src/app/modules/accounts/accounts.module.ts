import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { components } from '../accounts/components';

import { AccountsRoutingModule } from './accounts-routing.module';
import { SharedModule } from '../shared/shared.module';

import { NgSelectModule } from '@ng-select/ng-select';
import { ReactiveFormsModule } from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { CalendarModule, DateAdapter } from 'angular-calendar';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';

@NgModule({
	declarations : [...components],
	imports      : [
		AccountsRoutingModule,
		CommonModule,
		ReactiveFormsModule,
		NgSelectModule,
		FontAwesomeModule,
		SharedModule,

		PaginationModule.forRoot(),
		TooltipModule.forRoot(),
		BsDatepickerModule.forRoot(),
		CalendarModule.forRoot({ provide: DateAdapter, useFactory: adapterFactory })
	]
})
export class AccountsModule { }
