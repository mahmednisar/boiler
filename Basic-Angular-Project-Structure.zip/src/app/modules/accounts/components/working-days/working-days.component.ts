import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';

import { AccountRoleMapping, Employee, EmployeeList } from 'src/app/models/employee.model';
import { getWorkingDays, WorkingDays } from 'src/app/models/working-days.model';
import { IconDefinition, faInfoCircle, faPencil } from '@fortawesome/pro-regular-svg-icons';

import { EmployeeService } from 'src/app/services/employee.service';
import { WorkingDaysService } from './working-days.service';
import { CalendarView } from 'angular-calendar';
import { DateTimeFormatterService } from 'src/app/services/date-time-formatter.service';
import { map } from 'rxjs/operators';

@Component({
	selector    : 'working-days',
	templateUrl : './working-days.component.html',
	styleUrls   : ['./working-days.component.scss'],
	providers   : [WorkingDaysService]
})
export class WorkingDaysComponent implements OnInit 
{
	fa                : Record<string, IconDefinition>;
	employees         : Employee[];
	accounts          : AccountRoleMapping[];
	selectedAccount   : AccountRoleMapping;
	selectedEmployee  : Employee;
	employeeControl   : FormControl;
	accountControl    : FormControl;
	datePickerControl : FormControl;
	view              : CalendarView;
	viewDate          : Date;
	selectedDate      : Date;
	workingDays       : WorkingDays[];
	totalWorkingCount : number;
	openDatePicker    : Boolean;
	config            : any;
	choices           : any;


	constructor(
		private employeeService    : EmployeeService,
		private workingDaysService : WorkingDaysService,
		private dateTimeFormatter  : DateTimeFormatterService
	) 
	{
		this.fa                = { faInfoCircle, faPencil };
		this.employeeControl   = new FormControl();
		this.accountControl    = new FormControl();
		this.datePickerControl = new FormControl();
		this.openDatePicker    = false;
		this.view              = CalendarView.Month;
	}

	ngOnInit() : void
	{
		this.employeeService.getAllEmployees({})
		.subscribe(onSuccess.bind(this));
		function onSuccess(this : WorkingDaysComponent, response : EmployeeList) : void
		{
			response.result.map(item => item.fullName = `${item.firstName} ${item.lastName}`);
			this.employees = response.result;
		}

		this.onEmployeeChanged();
		this.onAccountChanged();
		this.onDateChanged();

		this.datePickerControl.setValue(new Date());
	}

	onEmployeeChanged() : void
	{
		this.employeeControl.valueChanges.subscribe(onValueChanged.bind(this));
		function onValueChanged(this : WorkingDaysComponent, value : string) : void
		{
			this.selectedEmployee = this.employees.find(emplo => emplo.userId == value);
			this.accounts         = this.selectedEmployee.userAccounts;
			this.config           = this.workingDaysService.getCalendarConfig();
			this.choices          = this.workingDaysService.getSelectOption();

			this.accountControl.reset();
			this.getWorkingDays();
		}
	}

	onAccountChanged() : void
	{
		this.accountControl.valueChanges.subscribe(onValueChanged.bind(this));
		function onValueChanged(this : WorkingDaysComponent, value : AccountRoleMapping) : void
		{
			this.selectedAccount = value;
			this.getWorkingDays();
		}
	}

	onDateChanged() : void
	{
		this.datePickerControl.valueChanges.subscribe(onValueChanged.bind(this));
		function onValueChanged(this : WorkingDaysComponent, value : any) : void
		{
			this.viewDate       = value;
			this.openDatePicker = false;
			this.getWorkingDays();
		}
	}

	getWorkingDays() : void
	{
		if(this.selectedEmployee && this.viewDate)
		{
			let temp = this.dateTimeFormatter.getSelectedMonth(this.viewDate);
			let data = {
				startDate : temp.start,
				endDate   : temp.end,
				userId    : this.selectedEmployee.userId,
				accountId : this.selectedAccount ? this.selectedAccount.accountId : null
			}
			this.workingDaysService.getWorkingDays(data)
			.pipe(map(manipulateDate.bind(this)))
			.subscribe(onSuccess.bind(this));
	
			function onSuccess(this : WorkingDaysComponent, response : getWorkingDays) : void
			{
				this.workingDays       = response.workingDays;
				this.totalWorkingCount = response.count;
			}
	
			function manipulateDate(this : WorkingDaysComponent, response : getWorkingDays) : getWorkingDays
			{
				response.workingDays.map(item => item.start = new Date(item.date));
				return response;
			}
		}
	}

	onOpenCalendar(container) : void
	{
		container.monthSelectHandler = (event: any): void => {
			container._store.dispatch(container._actions.select(event.date));
		};
		container.setViewMode('month');
	}

	enableInlineEdit(calendarEvent) : void
	{
		this.selectedDate = calendarEvent.day.events.length > 0 ? calendarEvent.day.date : null;
	}

	onOptionSelected(value, date) : void
	{
		let data = {
			date : this.dateTimeFormatter.toTimezoneISO(date),
			code : value,
			userId : this.selectedEmployee.userId
		}
		
		this.workingDaysService.updateWorkingDays(data).subscribe(onSuccess.bind(this));
		function onSuccess(this : WorkingDaysComponent, response) : void
		{
			this.getWorkingDays();
		}
	}
}
