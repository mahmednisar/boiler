import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { subDays, startOfDay, addDays } from 'date-fns';
import { Observable } from 'rxjs';
import { getWorkingDays } from 'src/app/models/working-days.model';

@Injectable()
export class WorkingDaysService
{
	constructor(private http : HttpClient) {}

	getCalendarConfig() : any
	{
		return {
			fullday : {
				title     : 'Full Day',
				primary   : '#1E90FF',
				secondary : '#D1E8FF',
			},
			halfday : {
				title     : 'Half Day',
				primary   : '#E3BC08',
				secondary : '#FDF1BA',
			},
			leave : {
				title     : 'Not Working',
				primary   : '#808080',
				secondary : '#EBEBEB',
			}
		}
	}

	getSelectOption()
	{
		return [
			{ key : 'Full Day', value : 'fullday'},
			{ key : 'Half Day', value : 'halfday'},
		]
	}

	getWorkingDays(data : Record<string, any>) : Observable<getWorkingDays>
	{
		return this.http.post('GetWorkingDays', data);
	}

	updateWorkingDays(data : Record<string, string>) : Observable<any>
	{
		return this.http.post('UpdateUserWorkingDay', data);
	}
}
