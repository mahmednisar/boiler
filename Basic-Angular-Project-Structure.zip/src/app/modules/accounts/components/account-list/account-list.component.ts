import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';

import { IconDefinition, faPlus, faSearch, faCubes } from '@fortawesome/pro-solid-svg-icons';
import { Observable, of } from 'rxjs';
import { debounceTime, filter, map, switchMap } from 'rxjs/operators';

import { AccountDetails } from 'src/app/models/acount-details.model';
import { ActiveUser } from 'src/app/models/active-user.model';
import { AccountSearchParams } from 'src/app/models/acount-filter-params.model';

import { AccountService } from 'src/app/services/account.service';
import { ActiveUserService } from 'src/app/services/active-user.service';
import { isEqual } from 'lodash';
import { Router } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { AddAccountComponent } from '../add-account/add-account.component';
import { AddSubaccountComponent } from '../add-subaccount/add-subaccount.component';

@Component({
	selector    : 'account-list',
	templateUrl : './account-list.component.html',
	styleUrls   : ['./account-list.component.scss']
})
export class AccountListComponent implements OnInit 
{

	fa                : Record<string, IconDefinition>;
	reloadSame        : boolean;
	totalAccounts     : number;
	pageSize          : number;
	timezones         : any;
	accountList       : AccountDetails[];
	selectedAccount   : AccountDetails;
	user              : ActiveUser;
	currentFilters    : AccountSearchParams;
	accountFilterForm : FormGroup;
	searchControl     : FormControl;
	

	constructor(
		private accountService    : AccountService,
		private formBuilder       : FormBuilder,
		private activeUserService : ActiveUserService,
		private router            : Router,
		private modalService      : BsModalService,
	)
	{
		this.fa             = { faPlus, faSearch, faCubes };
		this.pageSize       = 20;
		this.currentFilters = {};
		this.user           = this.activeUserService.getUser();

		this.accountFilterForm = this.formBuilder.group({
			userId          : this.user.userId,
			accountName     : null,
			timezoneId      : null,
			isActive        : null,
			onlyActive      : null,
			pageNumber      : 1,
			numberOfRecords : this.pageSize,
		});
		this.searchControl = new FormControl();
	}

	ngOnInit() : void
	{
		this.accountService.getTimeZoneMaster().subscribe(response => this.timezones = response);
		
		this.onAccountFilterChange();

		this.searchControl.valueChanges.pipe(debounceTime(500)).subscribe(value => this.accountFilterForm.controls.accountName.setValue(value));
		this.accountFilterForm.controls.isActive.setValue(true);
	}

	private onAccountFilterChange() : void
	{
		this.accountFilterForm.valueChanges
			.pipe(
				map(resetPaging.bind(this)),
				filter(checkIfChanged.bind(this)),
				switchMap(getTasks.bind(this))
			).subscribe(data => {
				this.accountList   = data.accounts;
				this.totalAccounts = data.count;
				this.reloadSame    = false;
				if(this.selectedAccount) {
					this.accountList.forEach(account => {
						if(account.accountId == this.selectedAccount.accountId) account.expanded = true;
					});
				}
			});

		function resetPaging(this : AccountListComponent, filters : AccountSearchParams) : AccountSearchParams
		{
			filters.onlyActive = filters.isActive;
			if(filters.pageNumber == this.currentFilters.pageNumber && !this.reloadSame)
			{
				filters.pageNumber = 1;
				this.accountFilterForm.controls.pageNumber.setValue(1, {emitEvent : false});
			}
			return filters;
		}

		function checkIfChanged(this : AccountListComponent, filters : AccountSearchParams) : boolean
		{
			return this.reloadSame || !isEqual(filters, this.currentFilters);
		}

		function getTasks(this : AccountListComponent, filters : AccountSearchParams) : Observable<AccountDetails[]>
		{
			this.currentFilters = filters;
			return this.accountService.getAccountList(filters);
		}
	}

	addNewAccount() : void
	{
		var initialState = 
		{
			timezones  : this.timezones
		}
		let modalRef = this.modalService.show(AddAccountComponent, { initialState, class: 'modal-lg' });
		modalRef.content.event.subscribe(res => {
			if(res) 
			{
				this.reloadSame    = true;
				this.accountFilterForm.updateValueAndValidity();
			}
		});
	}

	addNewSubaccount(account) : void
	{
		this.selectedAccount = account;
		var initialState = 
		{
			selectedAccount  : account
		}
		let modalRef = this.modalService.show(AddSubaccountComponent, { initialState, class: 'modal-lg' });
		modalRef.content.event.subscribe(res => {
			if(res) 
			{
				this.reloadSame    = true;
				this.accountFilterForm.updateValueAndValidity();
			}
		});
	}

	navigateToSubaccounts(account : AccountDetails) : void
	{
		this.router.navigate(['subaccount-list'], {queryParams : { accountId : account.accountId }})
	}

}
