import { AccountListComponent } from "./account-list/account-list.component";
import { AddAccountComponent } from "./add-account/add-account.component";
import { AddSubaccountComponent } from "./add-subaccount/add-subaccount.component";
import { SubaccountListComponent } from "./subaccount-list/subaccount-list.component";
import { WorkingDaysComponent } from "./working-days/working-days.component";

export let components = [
	AccountListComponent,
	AddAccountComponent,
	SubaccountListComponent,
	AddSubaccountComponent,
	WorkingDaysComponent
];