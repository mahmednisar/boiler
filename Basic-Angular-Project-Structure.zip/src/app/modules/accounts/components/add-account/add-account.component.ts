import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { IconDefinition, faTimes } from '@fortawesome/pro-solid-svg-icons';

import { BsModalRef } from 'ngx-bootstrap/modal';
import { AccountService } from 'src/app/services/account.service';

import { TimezoneModel } from 'src/app/models/MasterTemplate.model';
@Component({
	selector    : 'add-account',
	templateUrl : './add-account.component.html',
	styleUrls   : ['./add-account.component.scss']
})
export class AddAccountComponent
{
	public event = new EventEmitter();

	@Input() timezones : any;

	addAccountsForm  : FormGroup;
	submitting       : boolean;
	selectedTimeZone : TimezoneModel;
	fa               : Record<string, IconDefinition>;

	constructor(
		private formBuilder    : FormBuilder,
		private accountService : AccountService,
		public  activeModal    : BsModalRef,
	)
	{
		this.fa              = { faTimes };
		this.addAccountsForm = this.formBuilder.group({
			accountName      : [null, Validators.required],
			timeZoneId       : [null, Validators.required],
			timeZone         : null,
			isActive         : true,
			description      : null
		});
	}

	onTimeZoneChanged(event : TimezoneModel) : void
	{
		this.selectedTimeZone = event;
	}

	addAccount() : void
	{
		if(this.addAccountsForm.invalid) return;

		this.addAccountsForm.controls.timeZone.patchValue(this.selectedTimeZone.timeZoneName);
		this.accountService.addAccount(this.addAccountsForm.value).subscribe(onSuccess.bind(this));
		function onSuccess(this: AddAccountComponent, response) : void
		{
			this.event.emit(true);
			this.activeModal.hide();
		}
	}

}
