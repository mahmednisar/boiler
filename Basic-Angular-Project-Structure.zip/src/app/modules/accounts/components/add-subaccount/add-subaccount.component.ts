import { Component, EventEmitter, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { IconDefinition, faTimes } from '@fortawesome/pro-solid-svg-icons';

import { BsModalRef } from 'ngx-bootstrap/modal';
import { AccountDetails } from 'src/app/models/acount-details.model';
import { AccountService } from 'src/app/services/account.service';

@Component({
	selector    : 'add-subaccount',
	templateUrl : './add-subaccount.component.html',
	styleUrls   : ['./add-subaccount.component.scss']
})
export class AddSubaccountComponent
{
	public event = new EventEmitter();
	@Input() selectedAccount : AccountDetails;

	addSubaccountsForm : FormGroup;
	submitting         : boolean;
	fa                 : Record<string, IconDefinition>;

	constructor(
		private formBuilder    : FormBuilder,
		private accountService : AccountService,
		public  activeModal    : BsModalRef,
	) {
		this.fa                 = { faTimes };
	}

	ngOnInit() : void
	{
		if(this.selectedAccount) 
		{
			this.addSubaccountsForm = this.formBuilder.group({
				subaccountName : [null, Validators.required],
				accountName    : this.selectedAccount.accountName,
				accountId      : this.selectedAccount.accountId,
				description    : null,
			});
		}
	}

	addAccount(): void
	{
		if (this.addSubaccountsForm.invalid) return;

		this.accountService.addSubaccount(this.addSubaccountsForm.value).subscribe(onSuccess.bind(this));
		function onSuccess(this: AddSubaccountComponent, response): void
		{
			this.event.emit({ success: true });
			this.activeModal.hide();
		}
	}

}
