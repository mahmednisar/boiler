import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

import { IconDefinition, faPlus, faSearch, faArrowCircleLeft } from '@fortawesome/pro-solid-svg-icons';
import { isEqual } from 'lodash';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Observable } from 'rxjs';
import { debounceTime, filter, map, switchMap } from 'rxjs/operators';

import { AccountDetails, SubAccountDetails } from 'src/app/models/acount-details.model';
import { SubaccountSearchParams } from 'src/app/models/acount-filter-params.model';
import { ActiveUser } from 'src/app/models/active-user.model';
import { AccountService } from 'src/app/services/account.service';

import { ActiveUserService } from 'src/app/services/active-user.service';
import { AddSubaccountComponent } from '../add-subaccount/add-subaccount.component';

@Component({
	selector    : 'tests-subaccount-list',
	templateUrl : './subaccount-list.component.html',
	styleUrls   : ['./subaccount-list.component.scss']
})
export class SubaccountListComponent implements OnInit
{
	fa                   : Record<string, IconDefinition>;
	reloadSame           : boolean;
	totalsubaccounts     : number;
	pageSize             : number;
	selectedAccount      : AccountDetails;
	selectedAccountId    : number;
	timezones            : any;
	subaccountList       : SubAccountDetails[];
	user                 : ActiveUser;
	currentFilters       : SubaccountSearchParams;
	subaccountFilterForm : FormGroup;
	searchControl        : FormControl;

	constructor(
		private activeUserService : ActiveUserService,
		private accountService    : AccountService,
		private route             : ActivatedRoute,
		private formBuilder       : FormBuilder,
		private modalService      : BsModalService,
	)
	{
		this.fa                   = { faPlus, faSearch, faArrowCircleLeft };
		this.pageSize             = 20;
		this.currentFilters       = {};
		this.user                 = this.activeUserService.getUser();
		this.selectedAccountId    = this.route.snapshot.queryParams.accountId;
		
		this.searchControl        = new FormControl();
		this.subaccountFilterForm = this.formBuilder.group({
			accountId       : this.selectedAccountId,
			subaccountName  : null,
			isActive        : null,
			pageNumber      : 1,
			numberOfRecords : this.pageSize,
		});
	}

	ngOnInit(): void
	{
		this.accountService.getAccountList({accountId : this.selectedAccountId}).subscribe((res : any) => this.selectedAccount = res.accounts[0]);
		this.onSubaccountFilterChange();

		this.subaccountFilterForm.controls.isActive.setValue(true);
		this.searchControl.valueChanges.pipe(debounceTime(500)).subscribe(value => this.subaccountFilterForm.controls.subaccountName.setValue(value));
	}

	private onSubaccountFilterChange() : void
	{
		this.subaccountFilterForm.valueChanges
			.pipe(
				map(resetPaging.bind(this)),
				filter(checkIfChanged.bind(this)),
				switchMap(getTasks.bind(this)),
			).subscribe(data => {
				this.subaccountList   = data.subAccountList;
				this.totalsubaccounts = data.count;
				this.reloadSame       = false;
			});

		function resetPaging(this : SubaccountListComponent, filters : SubaccountSearchParams) : SubaccountSearchParams
		{
			if(filters.pageNumber == this.currentFilters.pageNumber && !this.reloadSame)
			{
				filters.pageNumber = 1;
				this.subaccountFilterForm.controls.pageNumber.setValue(1, {emitEvent : false});
			}
			return filters;
		}

		function checkIfChanged(this : SubaccountListComponent, filters : SubaccountSearchParams) : boolean
		{
			return this.reloadSame || !isEqual(filters, this.currentFilters);
		}

		function getTasks(this : SubaccountListComponent, filters : SubaccountSearchParams) : Observable<SubAccountDetails[]>
		{
			this.currentFilters = filters;
			return this.accountService.getSubaccountList(filters);
		}
	}

	addNewSubaccount() : void
	{
		var initialState = 
		{
			selectedAccount  : this.selectedAccount
		}
		let modalRef = this.modalService.show(AddSubaccountComponent, { initialState, class: 'modal-lg' });
		modalRef.content.event.subscribe(res => {
			if(res) 
			{
				this.reloadSame    = true;
				this.subaccountFilterForm.updateValueAndValidity();
			}
		});
	}
}
