import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppLayoutComponent } from '../shared/components/app-layout/app-layout.component';
import { AuthGuardService } from '../../services/auth-guard.service';
import { AccountListComponent } from './components/account-list/account-list.component';
import { SubaccountListComponent } from './components/subaccount-list/subaccount-list.component';
import { WorkingDaysComponent } from './components/working-days/working-days.component';

let routes : Routes = 
[
	{
		path             : '',
		component        : AppLayoutComponent,
		canActivateChild : [AuthGuardService],
		children         : 
		[
			{
				path      : 'account-list',
				component : AccountListComponent,
				data      : {title : 'Account', pageId : 'account_list'}
			},
			{
				path      : 'subaccount-list',
				component : SubaccountListComponent,
				data      : {title : 'Subaccount', pageId : 'subaccount_list'}
			},
			{
				path      : 'working-days',
				component : WorkingDaysComponent,
				data      : {title : 'Working Days', pageId : 'working_days'}
			}
		]
	}
];

@NgModule({
	imports : [RouterModule.forChild(routes)],
	exports : [RouterModule]
})
export class AccountsRoutingModule { }
