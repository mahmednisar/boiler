import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { CommonModule } from '@angular/common';
import { NgSelectModule } from '@ng-select/ng-select';
import { HighchartsChartModule } from 'highcharts-angular';
import { SharedModule } from '../shared/shared.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { ButtonsModule } from 'ngx-bootstrap/buttons';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { ProgressbarModule } from 'ngx-bootstrap/progressbar';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from '@danielmoncada/angular-datetime-picker';
import { GridsterModule } from 'angular-gridster2';

import {components} from './components';

@NgModule({
	declarations : [...components],

	imports :
	[
		DashboardRoutingModule,
		CommonModule,
		ReactiveFormsModule,
		SharedModule,
		NgSelectModule,
		HighchartsChartModule,
		FontAwesomeModule,

		TabsModule.forRoot(),
		ButtonsModule.forRoot(),
		PaginationModule.forRoot(),
		ProgressbarModule.forRoot(),
		TooltipModule.forRoot(),
		OwlDateTimeModule,
		OwlNativeDateTimeModule,
		GridsterModule
	]
})
export class DashboardModule {}