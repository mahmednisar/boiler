import { Component, Input, OnChanges, OnDestroy } from '@angular/core';

import { forkJoin, Subscription, timer } from 'rxjs';

import { TableStorageService } from 'src/app/services/table-storage.service';
import { TodaysOverviewService } from './todays-overview.service';
import { TemplateService } from 'src/app/services/template.service';

import * as Highcharts from 'highcharts';
import Export from 'highcharts/modules/exporting';
import NoData from 'highcharts/modules/no-data-to-display';
Export(Highcharts);
NoData(Highcharts);

import { MasterTemplate } from 'src/app/models/MasterTemplate.model';
import { TemplateCounts } from 'src/app/models/TemplateCounts.model';
import { ActiveUser } from 'src/app/models/active-user.model';
import { Widget } from '../dashboard/dashboard.model';

import { IconDefinition, faScrubber, faClock, faCheckCircle, faPauseCircle, faInfoCircle, faQuestionCircle } from '@fortawesome/pro-duotone-svg-icons';
import { AccountDetails } from 'src/app/models/acount-details.model';

@Component({
	selector    : 'todays-overview',
	templateUrl : './todays-overview.component.html',
	styleUrls   : ['./todays-overview.component.scss'],
	providers   : [TodaysOverviewService]
})
export class TodaysOverviewComponent implements OnChanges, OnDestroy
{
	@Input() selectedAccount  : AccountDetails;
	@Input() selectedTemplate : MasterTemplate;

	Highcharts      : typeof Highcharts;
	counts          : TemplateCounts;
	user            : ActiveUser;
	statusWidgets   : Widget[];
	pieConfig       : Highcharts.ChartOptions;
	statusConfig    : Highcharts.ChartOptions;
	fa              : Record<string, IconDefinition>;
	templateConfigs : Record<string, any>;
	refreshInterval : Subscription
	iconConfig      : any;
	selectedTabId   : number;

	constructor(
		private azureTables           : TableStorageService,
		private todaysOverviewService : TodaysOverviewService,
		private templateService       : TemplateService
	)
	{
		this.selectedTabId = 0;
		this.Highcharts    = Highcharts;
		this.statusWidgets = [];
		this.fa            = { faScrubber, faClock, faCheckCircle, faPauseCircle, faInfoCircle, faQuestionCircle };
	}

	onChartInit(instance : Highcharts.Chart, widget) : void
	{
		widget.chart = instance;
		setTimeout(() => widget.chart.reflow(), 200);
	}

	ngOnChanges() : void
	{
		if(this.selectedTabId == 0 && this.selectedTemplate)
		{
			if(this.refreshInterval) this.refreshInterval.unsubscribe();
			this.statusConfig = null;

			this.templateService.getTemplateConfig(this.selectedTemplate.templateId).subscribe(response => this.templateConfigs = response);
			this.refreshInterval = timer(0, 120000).subscribe(() => this.getTemplateCounts());
		}
	}

	ngOnDestroy() : void
	{
		if(this.refreshInterval) this.refreshInterval.unsubscribe();
	}

	selectTarget(index : number = null) : void
	{
		this.selectedTabId = index;
	}

	private getTemplateCounts(): void
	{
		let tableObject   = {
			tableName : 'todaystask',
			query     : `RowKey eq '${this.selectedTemplate.templateId}'`
		};

		this.azureTables.queryCustomEntities(tableObject.tableName, tableObject.query).subscribe(onSuccess.bind(this))
		function onSuccess(this : TodaysOverviewComponent, data) : void
		{
			let UserEntry = [];

			data.forEach(entry => {
				if(entry.PartitionKey == this.selectedTemplate.templateId)
				{
					entry.totalCounts = entry['new'] + entry['inprogress'] + entry['closed'] + (!!this.templateConfigs.allowhold ? entry['hold'] : 0);
					this.counts = entry;
				}
				else UserEntry.push(entry);
			});

			let statusConfig     = this.todaysOverviewService.getIconsAndColors().filter(item => item.name != 'Hold');
			let newConfig        = this.todaysOverviewService.getIconsAndColors().find(icon => icon.name == 'New');
			this.iconConfig      = this.templateConfigs.allowhold ? this.todaysOverviewService.getIconsAndColors() : statusConfig;
			this.pieConfig       = this.todaysOverviewService.getPieChartConfig(this.counts, UserEntry, this.iconConfig, this.templateConfigs, this);
			this.statusConfig    = this.todaysOverviewService.getBarChartConfig(UserEntry, newConfig.name, newConfig.code, newConfig.color);
		}
	}
}
