import { Injectable } from '@angular/core';

@Injectable()
export class TodaysOverviewService
{
	constructor() {}

	getIconsAndColors() : any
	{
		return [
			{ name : 'New',         code : 'new',        color : '#17A2B8B3', color2 : '#17A2B8', icon : 'faScrubber', sliced: true, selected: true },
			{ name : 'In Prog.',    code : 'inprogress', color : '#FFAC07B3', color2 : '#FFAC07', icon : 'faClock'},
			{ name : 'Closed',      code : 'closed',     color : '#28A745B3', color2 : '#28A745', icon : 'faCheckCircle' },
			{ name : 'Hold',        code : 'hold',       color : '#663399B3', color2 : '#663399', icon : 'faPauseCircle' }
		]
	}

	getPieChartConfig(totalCount : any, userEntries : any, iconConfig : any, templateConfig : Record<string, any>, componentInstance) : any
	{
		var vm = this;
		return {
			chart: {
				type         : 'pie',
				borderRadius : 8,
				borderWidth  : 1,
				borderColor  : '#ddd',
				style        : {
					fontFamily : 'Roboto'
				}
			},
			credits: {
				href : '',
				text : 'Admin Accounts'
			},
			title: {
				align  : 'left',
				margin : 20,
				style  : { 'font-size': '14px', 'font-weight': 'bold', 'color': '#663399' },
				text   : `Total Tasks : ${totalCount.totalCounts}`
			},
			exporting: {
				buttons: {
					contextButton : {
						symbol : 'menuball'
					}
				},
				sourceWidth  : 800,
				sourceHeight : 300,
				filename     : 'AA_Chart'
			},
			tooltip: {
				formatter: function() {
					return `<b>${this.key} :</b> ${this.y}`;
				},
			},
			plotOptions: {
				pie: {
					allowPointSelect : true,
					cursor           : 'pointer',
					dataLabels       : {
						enabled : true,
						format  : '<b>{point.name}</b>: {point.y}'
					},
					point: {
						events: {
							click : function()
							{
								iconConfig.forEach(element => element.selected = (this.code == element.code && !element.selected) ? true : false);
								componentInstance.statusConfig = vm.getBarChartConfig(userEntries, this.name, this.code, this.color);
							}
						}
					}
				}
			},
			series : manipulateStatuses(totalCount, iconConfig, templateConfig.allowhold)
		};

		function manipulateStatuses(counts : any, config : any, allowhold : boolean) : any
		{
			let data = [];

			let keys = ['new', 'inprogress', 'closed'];
			if(allowhold) keys.push('hold');

			for(let key of keys)
			{
				let conf   = config.find(item => item.code == key)
				let object = { 
					...conf,
					y : counts[key],
				}
				data.push(object);
			}

			return [{data : data}]
		}
	}

	getBarChartConfig(entry : any, title : string, status : string, color : string) : any
	{
		return {
			chart: {
				type         : 'column',
				borderRadius : 8,
				borderWidth  : 1,
				borderColor  : '#ddd',
				style        : {
					fontFamily : 'Roboto'
				}
			},
			credits: {
				href : '',
				text : 'Admin Accounts'
			},
			title: {
				align  : 'left',
				margin : 20,
				style  : { 'font-size': '14px', 'font-weight': 'bold', 'color': '#663399' },
				text   : title
			},
			exporting: {
				buttons: {
					contextButton : {
						symbol : 'menuball'
					}
				},
				sourceWidth  : 800,
				sourceHeight : 300,
				filename     : 'AA_Chart'
			},
			legend: {
				enabled : false
			},
			xAxis: {
				title: {
					text   : '',
					style  : { 'font-weight': 'bold' },
					margin : 13
				},
				type   : 'category',
				labels : {
					style : { 'font-size': '12px', 'color': '#333' }
				}
			},
			yAxis: {
				tickAmount    : 5,
				allowDecimals : false,
				title         : { text: '' },
				currentMin    : 0,
				labels        : {
					format : '{value}'
				}
			},
			tooltip: {
				formatter: function() {
					return `<b>${this.key} :</b> ${this.y}`;
				},
			},
			plotOptions : {
				series : {
					pointPadding : 0.0,
					color        : color
				}
			},
			series : manipulateEntriesData(entry, status, title)
		};

		function manipulateEntriesData(entry, status, title) : any
		{
			let data = [];
			entry.forEach(ent => data.push( [ent.UserName, ent[status]] ));
			return [{
				name : title,
				data : data
			}]
		}
	}
}