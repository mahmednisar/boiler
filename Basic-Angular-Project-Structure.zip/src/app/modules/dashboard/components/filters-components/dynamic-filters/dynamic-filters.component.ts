import { Component, ComponentFactoryResolver, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';

import { FiltersDirective } from '../filters-config/filters.directive';
import { FiltersConfigService } from '../filters-config/filters-config.service';

import { AddItem } from '../filters-config/filters-config.service';
import { AccountDetails } from 'src/app/models/acount-details.model';
import { FiltersList, ReportMaster } from 'src/app/models/ReportMaster.model';
@Component({
	selector    : 'dynamic-filters',
	templateUrl : './dynamic-filters.component.html',
	styleUrls   : ['./dynamic-filters.component.scss']
})
export class DynamicFiltersComponent implements OnInit {
	
	@ViewChild(FiltersDirective, { static: true }) filterHost : FiltersDirective;
	@Output() OnValueEmit = new EventEmitter();

	@Input() account : AccountDetails;
	@Input() report  : ReportMaster;
	filters          : AddItem[];
	componentFactory : any;
	viewContainerRef : any;
	componentRef     : any;

	constructor(
		private componentFactoryResolver : ComponentFactoryResolver,
		private filtersConfigService     : FiltersConfigService,
	)
	{}

	ngOnInit() : void
	{
		var temp = this.filtersConfigService.getFilters();
		this.report.reportFilters.forEach(filter => {
			this.filters = temp.filter(item => item.filterType == filter.filterType);
			this.loadComponents(filter);
		});
	}

	private loadComponents(filter : FiltersList) 
	{
		this.componentFactory = this.componentFactoryResolver.resolveComponentFactory(this.filters[0].component);
		this.viewContainerRef = this.filterHost.viewContainerRef;
		this.viewContainerRef.clear();
		this.componentRef     = this.viewContainerRef.createComponent(this.componentFactory);

		this.componentRef.instance.account    = this.account;
		this.componentRef.instance.filter     = filter;
		this.componentRef.instance.onValueChange.subscribe(event => this.OnValueEmit.emit(event));
	}

}
