import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { debounceTime } from 'rxjs/operators';

import { AccountDetails } from 'src/app/models/acount-details.model';
import { FiltersList } from 'src/app/models/ReportMaster.model';

@Component({
	selector    : 'subaccount-filter',
	templateUrl : './subaccount-filter.component.html'
})
export class SubaccountFilterComponent implements OnInit
{
	@Output() onValueChange = new EventEmitter();

	@Input() account    : AccountDetails;
	@Input() filter     : FiltersList;
	subaccountList      : Record<string, any>[];
	formControl         : FormControl;
	isMultiple          : boolean;
	formControls        : any;

	ngOnInit(): void 
	{
		this.subaccountList                         = this.account.subAccountDetails;
		this.isMultiple                             = !!(this.filter.controlType == 'multiselect');
		this.formControls                           = {};
		this.formControls[this.filter.propertyName] = new FormControl();

		this.onFormValueChange();
	}

	private onFormValueChange() : void
	{
		this.formControls[this.filter.propertyName].valueChanges.pipe(debounceTime(500)).subscribe(value => this.onValueChange.emit(this.formControls));
	}

}
