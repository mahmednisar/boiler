import { Type } from '@angular/core';
export class AddItem
{
	constructor(public component: Type<any>, public filterType: string) { }
}

///////////////////////////////////////////////////////////////////////////////

import { Injectable } from '@angular/core';
import { SubaccountFilterComponent } from '../subaccount-filter/subaccount-filter.component';
@Injectable({providedIn: 'root'})
export class FiltersConfigService
{
	getFilters()
	{
		return [
			new AddItem(SubaccountFilterComponent, 'subaccounts'),
		];
	}
}
