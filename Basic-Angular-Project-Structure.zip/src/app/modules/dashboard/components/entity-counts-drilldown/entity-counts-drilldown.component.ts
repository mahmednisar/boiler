import { Component, Input } from '@angular/core';

import { TaskService } from 'src/app/services/task.service';
import { SwalService } from 'src/app/services/swal.service';

import { TemplateCounts } from 'src/app/models/TemplateCounts.model';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { IconDefinition, faUserPlus, faSort, faSortUp, faSortDown } from '@fortawesome/pro-solid-svg-icons';
import { orderBy } from 'lodash';

@Component({
	selector    : 'entity-counts-drilldown',
	templateUrl : './entity-counts-drilldown.component.html',
	styleUrls   : ['./entity-counts-drilldown.component.scss']
})
export class EntityCountsDrilldownComponent {
	@Input() template : TemplateCounts[];
	@Input() level    : boolean;

	editIndex   : number | null;
	fa          : Record<string, IconDefinition>;
	assignForm  : FormGroup;
	columnName: string;
	sortOrder: boolean;

	constructor(
		private formBuilder : FormBuilder,
		private taskService : TaskService,
		private swal : SwalService
	) {
		this.fa         = { faUserPlus, faSort, faSortUp, faSortDown };
		this.assignForm = this.formBuilder.group({instance : [null, Validators.required]})
	}

	openAssign(index : number) : void {
		this.assignForm.reset();
		this.editIndex = index;
	}

	assignTask(template : TemplateCounts) : void {
		if(!this.assignForm.valid) return;

		let data = {
			taskMappings : [
				{
					instance   : this.assignForm.controls.instance.value,
					assignedTo : template.UserId,
				}
			],
			templateId : template.RowKey.split('_')[0].replace('T', '')
		};

		this.taskService.assignRandomTask(data).subscribe(() => {
			this.editIndex = null;
		});
	}

	sortTable(column : string) : void
	{
		(this.columnName != column) ? (this.columnName = column, this.sortOrder = true) : ((this.sortOrder) ? this.sortOrder = false : this.sortOrder = true)
		this.template = orderBy(this.template, [column], [this.sortOrder ? 'asc' : 'desc']);
	}
}