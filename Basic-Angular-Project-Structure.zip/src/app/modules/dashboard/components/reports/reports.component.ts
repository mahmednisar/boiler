import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';

import { IconDefinition, faCaretLeft, faCaretRight, faExternalLinkAlt } from '@fortawesome/pro-solid-svg-icons';
import isEqual from 'lodash/isEqual';
import { map, switchMap, filter } from 'rxjs/operators';
import { Observable, of, forkJoin, noop } from 'rxjs';

import { TemplateService } from 'src/app/services/template.service';
import { ActiveUserService } from 'src/app/services/active-user.service';
import { ReportService } from 'src/app/services/report.service';
import { CommonService } from 'src/app/services/common.service';

import { ActiveUser } from 'src/app/models/active-user.model';
import { MasterTemplate, TimezoneModel } from 'src/app/models/MasterTemplate.model';
import { ReportSearchParams } from 'src/app/models/ReportSearchParams.model';
import { DateTime } from 'luxon';
import groupBy from 'lodash/groupBy';
import { AccountService } from 'src/app/services/account.service';
import { AccountDetails } from 'src/app/models/acount-details.model';
import { ReportMaster } from 'src/app/models/ReportMaster.model';
import { AuthorizationService } from 'src/app/services/authorization.service';
import { TabsetComponent } from 'ngx-bootstrap/tabs';

@Component({
	templateUrl : './reports.component.html',
	styleUrls   : ['./reports.component.scss']
})
export class ReportsComponent implements OnInit {
	@ViewChild('Tabset', {static : false}) tabset : TabsetComponent;

	reportFiltersForm  : FormGroup;
	templateSelect     : FormControl;
	accountSelect      : FormControl;
	templates          : MasterTemplate[];
	accounts           : AccountDetails[];
	selectedTemplateId : number;
	selectedAccount    : AccountDetails;
	activeUser         : ActiveUser;
	currentTimezone    : TimezoneModel;
	reportsList        : Record<string, any>;
	selectedReport     : ReportMaster;
	timelines          : Record<string, any>;
	fa                 : Record<string, IconDefinition>;
	currentFilters     : ReportSearchParams;
	reports            : ReportMaster[];
	columnNames        : string[];
	reloadSame         : boolean;
	reportData         : any;
	reportCount        : number;
	panelOpen          : boolean;

	show_account_reports  : boolean;

	constructor(
		private formBuilder       : FormBuilder,
		private templateService   : TemplateService,
		private activeUserService : ActiveUserService,
		private reportService     : ReportService,
		private accountService    : AccountService,
		private commonService     : CommonService,
		private authorization     : AuthorizationService
	)
	{
		this.currentFilters    = {};
		this.panelOpen         = true;
		this.fa                = { faCaretLeft, faCaretRight, faExternalLinkAlt };

		this.activeUser        = this.activeUserService.getUser();

		this.accountSelect     = new FormControl();
		this.templateSelect    = new FormControl();

		this.reportFiltersForm = this.formBuilder.group({
			templateId      : null,
			reportCode      : null,
			reportType      : null,
			endPoint        : null,
			createdOn       : null,
			numberOfRecords : 50,
			pageNumber      : 1,
			userId          : null,
			assignedTo      : null,
			primaryEntity   : null,
			secondaryEntity : null,
		});
	}

	ngOnInit(): void
	{
		forkJoin([
			this.authorization.getNavigations(this.activeUser.roleId),
			this.accountService.getAccountDetails(this.activeUser.userId)
		]).subscribe(response => {
			this.show_account_reports = response[0].actions.some(action => action.code == 'show_account_reports');
			setTimeout(() => {
				if(!this.show_account_reports) this.tabset.tabs[1].active = true;
			}, 0);

			this.accounts             = response[1];
			this.accountSelect.setValue(this.accounts[0]);
		});

		this.onAccountChange();
		this.onTemplateSelected();
		this.onReportFilterChanges();
		this.onTimelineChange();
	}

	private onAccountChange() : void
	{
		this.accountSelect.valueChanges.pipe(
			map(clearPreviousData.bind(this)),
			map(getAccountData.bind(this))
		).subscribe((account : AccountDetails) => {
			this.selectedAccount = account;
			this.reportFiltersForm.controls.primaryEntity.setValue(this.selectedAccount.accountId, {emitEvent : false});
			this.reportFiltersForm.controls.secondaryEntity.setValue(null, {emitEvent : false});
		});

		function clearPreviousData(this: ReportsComponent, account: AccountDetails) : AccountDetails
		{
			this.templates          = null;
			this.selectedTemplateId = null;
			this.selectedReport     = null;
			this.templateSelect.setValue(null);

			return account;
		}

		function getAccountData(this: ReportsComponent, account : AccountDetails) : AccountDetails
		{
			forkJoin([
				this.templateService.getAccountTemplates(account.accountId),
				this.reportService.getReportList(account.accountId.toString()),
			]).subscribe(onSuccess.bind(this));

			function onSuccess(this : ReportsComponent, data : any) : void
			{
				this.templates      = data[0];
				this.reports        = data[1];
				this.reportsList    = groupBy(this.reports, 'reportType');
			}
			return account;
		}
	}

	private onTemplateSelected() : void
	{
		this.templateSelect.valueChanges.subscribe(onTemplateChanged.bind(this));
		function onTemplateChanged(this : ReportsComponent, templateId : number) : void
		{
			if(!!templateId)
			{
				this.selectedTemplateId          = templateId;
				this.reportsList.TemplateReports = this.reports.filter(item => item.templateId == templateId);
				this.reportFiltersForm.controls.templateId.setValue(this.selectedTemplateId, {emitEvent : false});
			}
			else
			{
				this.selectedTemplateId = null;
				this.selectedReport     = null;
			}
		}
	}

	private onReportFilterChanges() : void
	{
		this.reportFiltersForm.valueChanges
			.pipe(
				map(resetPaging.bind(this)),
				filter(checkIfChanged.bind(this)),
				switchMap(getTasks.bind(this)))
			.subscribe(data => {
				this.reportData  = data.result;
				this.reportCount = data.count;
				this.reloadSame  = false;

				if(this.reportData[0]) this.columnNames = Object.keys(this.reportData[0]);
			});

		function resetPaging(this : ReportsComponent, filters : ReportSearchParams) : ReportSearchParams
		{
			if(filters.pageNumber == this.currentFilters.pageNumber && !this.reloadSame)
			{
				filters.pageNumber = 1;
				this.reportFiltersForm.controls.pageNumber.setValue(1, {emitEvent : false});
			}
			return filters;
		}

		function checkIfChanged(this : ReportsComponent, filters : ReportSearchParams) : boolean
		{
			return this.reloadSame || !isEqual(filters, this.currentFilters);
		}

		function getTasks(this : ReportsComponent, filters : ReportSearchParams) : Observable<any>
		{
			this.currentFilters = filters;
			if (this.selectedReport.isView) {
				return this.reportService.getReportsData(filters);
			}
			else return of();
		}
	}

	private onTimelineChange() : void
	{
		this.reportFiltersForm.controls.createdOn.valueChanges.subscribe(value => {
			value ? this.reportFiltersForm.controls.createdOn.setValue(value, {emitEvent : false}) : this.reportFiltersForm.controls.createdOn.setValue(this.timelines[0].value);
		});
	}

	listHideUnhide() : void
	{
		this.panelOpen = !this.panelOpen;
	}

	onReportSelected(report) : void
	{
		this.reportData  = null;
		this.reportCount = null;
		this.selectedReport = report;
		if (this.selectedReport.reportType == 'TemplateReports') {
			let currentTemplate  = this.templates.find(template => template.templateId == this.selectedTemplateId);
			this.currentTimezone = currentTemplate.timeZones.find(zone => zone.isDefault);
		}
		else {
			this.currentTimezone = this.selectedAccount.timeZone;
		}
		this.timelines = this.reportService.getReportTimelines(this.currentTimezone.utcOffset).filter(time => time.name != this.selectedReport.excludeTimeline);

		this.reportFiltersForm.controls.createdOn.setValue(this.timelines[0].value);
		this.reportFiltersForm.controls.reportCode.setValue(this.selectedReport.reportCode, {emitEvent : false});
		this.reportFiltersForm.controls.reportType.setValue(this.selectedReport.reportType, {emitEvent : false});
		this.reportFiltersForm.controls.endPoint.setValue(this.selectedReport.endPoint);
	}

	getReportToExcel() : void
	{
		this.reportService.getReportsToExcel(this.currentFilters).subscribe(onSuccess.bind(this))
		
		function onSuccess(this : ReportsComponent, response) : void
		{
			let fileName;
			if(this.selectedReport.reportType == "AccountReports")
			{
				fileName = `${this.currentFilters.reportCode}_${this.selectedAccount.accountName}_${DateTime.fromJSDate(this.currentFilters.createdOn[0]).toFormat('DD')}-${DateTime.fromJSDate(this.currentFilters.createdOn[1]).toFormat('DD')}.xlsx`
			}
			else
			{
				let selectedTemplate = this.templates.find(item => item.templateId == this.currentFilters.templateId);

				fileName = `${this.currentFilters.reportCode}_${selectedTemplate.templateName}_${DateTime.fromJSDate(this.currentFilters.createdOn[0]).toFormat('DD')}-${DateTime.fromJSDate(this.currentFilters.createdOn[1]).toFormat('DD')}.xlsx`
			}
			this.commonService.downloadBlob(response, fileName);
		}
	}

	onDynamicFiltersValue(event) : void
	{
		this.reportFiltersForm.addControl(Object.keys(event)[0], Object.values(event)[0] as any);
	}

}
