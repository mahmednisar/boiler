import { DashboardComponent } from './dashboard/dashboard.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { TodaysOverviewComponent } from './todays-overview/todays-overview.component';

import { TeamOverviewComponent } from './team-overview/team-overview.component';
import { EntityCountsComponent } from './entity-counts/entity-counts.component';
import { EntityCountsDrilldownComponent } from './entity-counts-drilldown/entity-counts-drilldown.component';

import { ReportsComponent } from './reports/reports.component';
import { DynamicFiltersComponent } from './filters-components/dynamic-filters/dynamic-filters.component';
import { FiltersDirective } from './filters-components/filters-config/filters.directive';
import { SubaccountFilterComponent } from './filters-components/subaccount-filter/subaccount-filter.component';

export let components = [
	DashboardComponent,
	UserDashboardComponent,
	TodaysOverviewComponent,

	TeamOverviewComponent,
	EntityCountsComponent,
	EntityCountsDrilldownComponent,
	ReportsComponent,

	DynamicFiltersComponent,
	FiltersDirective,
	SubaccountFilterComponent,
];