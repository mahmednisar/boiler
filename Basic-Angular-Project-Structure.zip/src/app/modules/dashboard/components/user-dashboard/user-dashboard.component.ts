import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';

import { filter, map, switchMap } from 'rxjs/operators';
import { forkJoin, Subscription, timer } from 'rxjs';

import * as Highcharts from 'highcharts';
import Export from 'highcharts/modules/exporting';
import NoData from 'highcharts/modules/no-data-to-display';
Export(Highcharts);
NoData(Highcharts);

import { ActiveUserService } from 'src/app/services/active-user.service';
import { TemplateService } from 'src/app/services/template.service';
import { UserDashboardService } from './user-dashboard.service';
import { DashboardService } from '../dashboard/dashboard.service';
import { DateTimeFormatterService } from 'src/app/services/date-time-formatter.service';
import { MetricService } from 'src/app/services/metric.service';
import { AccountService } from 'src/app/services/account.service';
import { TableStorageService } from 'src/app/services/table-storage.service';
import { TodaysOverviewService } from '../todays-overview/todays-overview.service';

import { MasterTemplate, TimezoneModel } from 'src/app/models/MasterTemplate.model';
import { ActiveUser } from 'src/app/models/active-user.model';
import { MetricsConfiguration } from 'src/app/models/MetricsConfiguration.model';
import { AccountDetails } from 'src/app/models/acount-details.model';
import { DashboardTimelines } from 'src/app/models/dashboard-timelines.model';
@Component({
	templateUrl : './user-dashboard.component.html',
	styleUrls   : ['./user-dashboard.component.scss'],
	providers   : [ UserDashboardService, DashboardService, TodaysOverviewService ]
})
export class UserDashboardComponent implements OnInit, OnDestroy
{
	Highcharts       : typeof Highcharts;
	refreshInterval  : Subscription;
	templateSelect   : FormControl;
	accountSelect    : FormControl;
	timelineControl  : FormControl;
	user             : ActiveUser;
	accounts         : AccountDetails[];
	selectedAccount  : AccountDetails;
	templates        : MasterTemplate[];
	selectedTemplate : MasterTemplate;
	timelines        : DashboardTimelines[];
	selectedTimeline : DashboardTimelines;
	metrics          : MetricsConfiguration[];
	actuals          : Record<string, any>;
	currentTimezone  : TimezoneModel;
	templateConfigs  : Record<string, any>;
	chartConfig      : Highcharts.ChartOptions;
	todaysDate       : Date;
	iconConfig       : any;
	
	constructor(
		private activeUserService     : ActiveUserService,
		private userDashboardService  : UserDashboardService,
		private dashboardService      : DashboardService,
		private todaysOverviewService : TodaysOverviewService,
		private accountService        : AccountService,
		private templateService       : TemplateService,
		private metricService         : MetricService,
		private dateTimeFormat        : DateTimeFormatterService,
		private azureTables           : TableStorageService,
	) {
		this.Highcharts     = Highcharts;
		this.templateSelect = new FormControl();
		this.accountSelect  = new FormControl();
		this.timelineControl= new FormControl();
	}

	onChartInit(instance : Highcharts.Chart, widget : any) : void
	{
		widget.chart = instance;
		setTimeout(() => widget.chart.reflow(), 300);
	}

	ngOnInit() : void
	{
		this.user = this.activeUserService.getUser();

		this.accountService.getAccountDetails(this.user.userId).subscribe(onSuccess.bind(this));
		function onSuccess(this : UserDashboardComponent, response : AccountDetails[]) : void
		{
			this.accounts = response;
			this.accountSelect.setValue(this.accounts[0]);
		}

		this.onAccountChange();
		this.onTemplateChange();
		this.onTimelineChange();
	}

	ngOnDestroy() : void
	{
		if (this.refreshInterval) this.refreshInterval.unsubscribe();
	}

	onAccountChange() : void
	{
		this.accountSelect.valueChanges
			.pipe(map(clearPreviousData.bind(this))
			).subscribe(onAccountChanged.bind(this));

			function onAccountChanged(this : UserDashboardComponent, account : AccountDetails) : void
			{
				this.selectedAccount = account;
				this.templateService.getAccountTemplates(account.accountId).subscribe((template : MasterTemplate[]) => {
					this.templates = template;
					this.templateSelect.setValue(this.templates[0]);
				});
			}

		function clearPreviousData(this: UserDashboardComponent, account: AccountDetails) : AccountDetails
		{
			this.templates = this.selectedTemplate = this.currentTimezone = null;
			this.actuals   = this.metrics          = this.chartConfig = null;
			this.templateSelect.setValue(null);

			return account;
		}
	}

	onTemplateChange() : void
	{
		this.templateSelect.valueChanges
		.pipe
		(
			filter(template => !!template),
			map(assignSelectedTemplate.bind(this)),
			switchMap(getData.bind(this))
		)
		.subscribe(response => {
			Object.assign(this, response);

			this.iconConfig  = this.todaysOverviewService.getIconsAndColors();
			this.timelineControl.setValue(this.timelines.find(timeline => timeline.code == 'todaystask'));
		});

		function assignSelectedTemplate(this: UserDashboardComponent, template: MasterTemplate) : MasterTemplate
		{
			if (this.refreshInterval) this.refreshInterval.unsubscribe();

			this.selectedTemplate = template;
			this.currentTimezone  = template.timeZones.find(zone => zone.isDefault);
			this.todaysDate       = this.dateTimeFormat.getTodaysDate(this.currentTimezone.utcOffset);
			this.refreshInterval  = timer(0, 120000).subscribe(() => this.getTodaysOverview(template));

			return this.selectedTemplate;
		}

		function getData(this : UserDashboardComponent, template ) : any
		{
			return forkJoin({
				timelines       : this.dashboardService.getDashboardTimelines(this.user.roleId),
				templateConfigs : this.templateService.getTemplateConfig(template.templateId),
			})
		}
	}

	onTimelineChange() : void
	{
		this.timelineControl.valueChanges.subscribe(onTimelineChanged.bind(this));
		function onTimelineChanged(this : UserDashboardComponent, timeline : DashboardTimelines) : void
		{
			if(this.selectedTimeline == timeline) return;

			this.selectedTimeline = timeline;

			this.metricService.getMetricsConfiguration(this.selectedTemplate.templateId).subscribe(response => {
				this.metrics = timeline.code == 'todaystask' ? response.filter(metric => metric.dashboardDisplay) : response;
			});

			let tableObject;
			if(timeline.hasStatusCharts)
			{
				tableObject   = {
					tableName : 'todaystask',
					query     : `PartitionKey eq '${this.user.userId}' and RowKey eq '${this.selectedTemplate.templateId}'`
				};
			}
			else
			{
				tableObject   = {
					tableName : `acc${this.selectedAccount.accountId}${timeline.code}`,
					query     : `PartitionKey eq 'template_${this.selectedTemplate.templateId}_${this.user.roleId}' and RowKey eq '${this.user.userId}'`
				};
			}
			this.onTemplateCount(tableObject.tableName, tableObject.query);
		}
	}

	private getTodaysOverview(template : MasterTemplate) : void
	{
		this.azureTables.queryEntities('todaystask', {PartitionKey: this.user.userId ,RowKey : template.templateId})
		.subscribe(response => this.chartConfig = this.userDashboardService.getChartConfig(response, this.iconConfig, this.templateConfigs));
	}

	private onTemplateCount(tableName : string, customQuery : string) : void
	{
		this.azureTables.queryCustomEntities(tableName, customQuery).subscribe(response => this.actuals = response[0]);
	}
}
