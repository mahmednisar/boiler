import { Injectable } from '@angular/core';

import { TableStorageService } from 'src/app/services/table-storage.service';
import { MasterTemplate } from 'src/app/models/MasterTemplate.model';
import { catchError } from 'rxjs/operators';
import { empty, of } from 'rxjs';

@Injectable()
export class UserDashboardService
{

	constructor(private azureTables : TableStorageService){}

	getChartData(userId : string ,template : MasterTemplate)
	{
		return this.azureTables.queryEntities('todaystask', {PartitionKey: userId ,RowKey : template.templateId}).pipe(catchError(() => of({})));
	}

	getChartConfig(chartData : Record<string,any>, iconConfig, templateConfig : Record<string, boolean>) : any {
		return {
			chart: {
				type         : 'column',
				borderRadius : 8,
				borderWidth  : 1,
				borderColor  : '#ddd',
				style        : {
					fontFamily : 'Roboto'
				}
			},
			credits: {
				href : '',
				text : 'Admin Accounts'
			},
			title: {
				align  : 'left',
				margin : 20,
				style  : { 'font-size': '14px', 'font-weight': 'bold', 'color': '#663399' },
				text   : 'Task Status'
			},
			exporting: {
				buttons: {
					contextButton : {
						symbol : 'menuball'
					}
				},
				sourceWidth  : 800,
				sourceHeight : 300,
				filename     : 'AA_Chart'
			},
			legend: {
				enabled : false
			},
			xAxis: {
				title: {
					text   : '',
					style  : { 'font-weight': 'bold' },
					margin : 13
				},
				type   : 'category',
				labels : {
					style : { 'font-size': '12px', 'color': '#333' }
				}
			},
			yAxis: {
				tickAmount    : 5,
				allowDecimals : false,
				title         : { text: '' },
				currentMin    : 0,
				labels        : {
					format : '{value}'
				}
			},
			tooltip: {
				formatter: function() {
					return `<b>${this.key} :</b> ${this.y}`;
				},
			},
			plotOptions: {
				series : {
					pointPadding : 0.0,
					color        : '#7f59a6a6',
				}
			},
			series : manipulateEntriesData(chartData, iconConfig, templateConfig)
		};

		function manipulateEntriesData(chartData, config, templateConfig) : any
		{
			let data = [];

			let keys = ['new', 'inprogress', 'closed'];
			if(templateConfig && !!templateConfig.allowhold) keys.push('hold');

			for(let key of keys)
			{
				let conf   = config.find(item => item.code == key)
				let object = { 
					...conf,
					y : chartData[key],
				}
				data.push(object);
			}
			return [{data : data}];
		}
	}
}