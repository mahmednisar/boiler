import { Component, Input } from '@angular/core';
import { TemplateCounts } from 'src/app/models/TemplateCounts.model';

@Component({
	selector    : '[entity-counts]',
	templateUrl : './entity-counts.component.html',
	styleUrls   : ['./entity-counts.component.scss']
})
export class EntityCountsComponent
{
	@Input() name   : string;
	@Input() counts : TemplateCounts;
	@Input() level  : boolean;
}