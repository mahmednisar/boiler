import { Component, OnInit, OnDestroy, Input, OnChanges } from '@angular/core';

import { forkJoin, timer, Subscription } from 'rxjs';
import groupBy from 'lodash/groupBy';
import sumByKeys from 'src/app/helpers/sumByKeys';

import { UserService } from 'src/app/services/user.service';
import { TableStorageService } from 'src/app/services/table-storage.service';
import { TemplateService } from 'src/app/services/template.service';
import { ActiveUserService } from 'src/app/services/active-user.service';

import { User } from 'src/app/models/User.model';
import { TemplateCounts } from 'src/app/models/TemplateCounts.model';
import { MasterTemplate } from 'src/app/models/MasterTemplate.model';
import { Tab, Count } from './team-overview.model';
import { ActiveUser } from 'src/app/models/active-user.model';
import { AccountDetails } from 'src/app/models/acount-details.model';
import { FormControl } from '@angular/forms';
@Component({
	selector    : 'team-overview',
	templateUrl : './team-overview.component.html',
	styleUrls   : ['./team-overview.component.scss'],
})
export class TeamOverviewComponent implements OnInit, OnChanges, OnDestroy
{
	@Input() accountId     : number;
	@Input() selectedTabId : number;

	counts          : Record<string, Count[]>;
	activeUser      : ActiveUser;
	accounts        : AccountDetails[];
	users           : User[];
	templates       : MasterTemplate[];
	currentAccount  : FormControl;
	userIds         : string[];
	templateIds     : string[];
	selectedIndex   : number;
	tabs            : Tab[];
	refreshInterval : Subscription;

	constructor(
		private userService       : UserService,
		private azureTables       : TableStorageService,
		private templateService   : TemplateService,
		private activeUserService : ActiveUserService
	) {
		this.currentAccount  = new FormControl();
		this.activeUser      = this.activeUserService.getUser();
	}

	ngOnInit() : void
	{
		this.tabs = [{
			key     : 'user',
			heading : 'User View',
			level   : true
		}, {
			key     : 'template',
			heading : 'Template View',
			level   : false
		}];

		this.counts = {};
	}

	ngOnChanges() : void
	{
		if(this.selectedTabId == 1) 
		{
			if(this.refreshInterval) this.refreshInterval.unsubscribe();
			this.onAccountChange(this.accountId);
		}
	}

	ngOnDestroy() : void
	{
		if(this.refreshInterval) this.refreshInterval.unsubscribe();
	}

	selectEntity(index : number = null) : void
	{
		this.selectedIndex = index;
	}

	private onAccountChange(accountId : number) : void
	{
		forkJoin({
			users     : this.userService.getUsers({accountId : accountId, functionCode : 'canprocesstask'}),
			templates : this.templateService.getAccountTemplates(accountId)
		}).subscribe(onSuccess.bind(this));
		function onSuccess(this : TeamOverviewComponent, data) : void
		{
			Object.assign(this, data);

			this.userIds         = this.users.map(user => user.userId);
			this.templateIds     = this.templates.map(template => (template.templateId as unknown as string));
			this.refreshInterval = timer(0, 120000).subscribe(() => this.getCounts());
		}
	}

	private getCounts() : void
	{
		forkJoin([
			this.azureTables.queryMultipleEntities<TemplateCounts[]>('todaystask', this.userIds),
			this.azureTables.queryMultipleEntities<TemplateCounts[]>('todaystask', this.templateIds)
		]).subscribe(data => {
			let accountUsers   = data[0].filter(item => item.PrimaryEntity == this.accountId)
			let userCounts     = groupBy(accountUsers, 'UserId');
			let templateCounts = groupBy(data[0], 'TemplateId');

			this.counts.user = this.users.map(user => {

				let temp = {
					name        : user.fullName,
					totalCounts : sumByKeys(userCounts[user.userId] || [], ['new', 'inprogress', 'closed']) as unknown as TemplateCounts,
					allCounts   : userCounts[user.userId] || []
				};

				let total = temp.totalCounts.new + temp.totalCounts.inprogress + temp.totalCounts.closed;
				temp.totalCounts.completion = (temp.totalCounts.closed / total) * 100;

				return temp;
			});

			this.counts.template = this.templates.map(template => {
				let temp = {
					name        : template.templateName,
					totalCounts : data[1].find(count => count.TemplateId == template.templateId) || ({} as TemplateCounts),
					allCounts   : templateCounts[template.templateId] || []
				}

				let total = temp.totalCounts.new + temp.totalCounts.inprogress + temp.totalCounts.closed;
				temp.totalCounts.completion = (temp.totalCounts.closed / total) * 100;

				return temp;
			});
		});
	}
}