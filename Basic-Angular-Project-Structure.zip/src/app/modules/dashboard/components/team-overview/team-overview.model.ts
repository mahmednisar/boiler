import { TemplateCounts } from 'src/app/models/TemplateCounts.model';

export interface Tab
{
	key     : string;
	heading : string;
	level   : boolean;
}

export interface Count
{
	name        : string;
	totalCounts : TemplateCounts;
	allCounts   : TemplateCounts[];
}