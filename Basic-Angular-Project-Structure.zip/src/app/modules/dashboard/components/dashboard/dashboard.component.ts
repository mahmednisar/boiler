import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Subscription, timer, forkJoin } from 'rxjs';

import * as Highcharts from 'highcharts';
import Export from 'highcharts/modules/exporting';
import NoData from 'highcharts/modules/no-data-to-display';
Export(Highcharts);
NoData(Highcharts);

import { ActiveUserService } from 'src/app/services/active-user.service';
import { TemplateService } from 'src/app/services/template.service';
import { DashboardService } from './dashboard.service';
import { TableStorageService } from 'src/app/services/table-storage.service';
import { AccountService } from 'src/app/services/account.service';
import { OrgStructureService } from 'src/app/services/org-structure.service';

import { MasterTemplate, TimezoneModel } from 'src/app/models/MasterTemplate.model';
import { Widget, ChartData } from './dashboard.model';
import { User } from 'src/app/models/User.model';
import { map, switchMap } from 'rxjs/operators';

import { AccountDetails } from 'src/app/models/acount-details.model';
import { ActiveUser } from 'src/app/models/active-user.model';
import { DashboardTimelines } from 'src/app/models/dashboard-timelines.model';
import { GridsterItem, GridsterConfig } from 'angular-gridster2';
import { Roles } from 'src/app/models/org-structure.model';
import { isEqual, sortBy } from 'lodash';

@Component({
	templateUrl : './dashboard.component.html',
	styleUrls   : ['./dashboard.component.scss'],
	providers   : [DashboardService]
})
export class DashboardComponent implements OnInit, OnDestroy
{
	Highcharts       : typeof Highcharts;
	templates        : MasterTemplate[];
	accounts         : AccountDetails[];
	selectedTemplate : MasterTemplate;
	selectedAccount  : AccountDetails;
	timelines        : DashboardTimelines[]
	currentTimezone  : TimezoneModel;
	users            : User[];
	activeUser       : ActiveUser;
	roles            : Roles[];
	metricsWidgets   : Widget[];
	filterForm       : FormGroup;
	userIds          : string[];
	templateIds      : string[];
	todaysDate       : Date;
	selectedTimeline : string;
	gridsterConfig   : GridsterConfig;
	refreshInterval  : Subscription;
	currentFilters   : any;

	static eventStop(widget: GridsterItem): void
	{
		setTimeout(() => widget.chart.reflow(), 200);
	}

	constructor(
		private templateService     : TemplateService,
		private activeUserService   : ActiveUserService,
		private dashboardService    : DashboardService,
		private azureTables         : TableStorageService,
		private accountService      : AccountService,
		private orgStructureService : OrgStructureService,
		private formBuilder         : FormBuilder
	)
	{
		this.metricsWidgets  = [];
		this.Highcharts      = Highcharts;
		this.activeUser      = this.activeUserService.getUser();
		this.filterForm      = this.formBuilder.group({
			account   : null,
			template  : null,
			roles     : null,
			timeline  : null
		});
	}

	resizeGraphs() : void
	{
		Highcharts.charts.filter(Boolean).forEach(chart => chart.reflow());
	}

	onChartInit(instance : Highcharts.Chart, widget : Widget) : void
	{
		widget.chart = instance;
		setTimeout(() => widget.chart.reflow(), 500);
	}

	ngOnDestroy() : void
	{
		if(this.refreshInterval) this.refreshInterval.unsubscribe();
	}

	ngOnInit() : void
	{
		this.gridsterConfig  = {
			gridType          : 'verticalFixed',
			displayGrid       : 'none',
			setGridSize       : true,
			margin            : 10,
			minCols           : 2,
			maxCols           : 2,
			rowHeight         : 400,
			compactType       : 'compactUp',
			pushItems         : true,
			swap              : true,
			swapWhileDragging : true,
			draggable         : {
				delayStart    : 0,
				enabled       : true,
				stop          : DashboardComponent.eventStop,
			},
			resizable         : {
				delayStart    : 0,
				enabled       : true,
				stop          : DashboardComponent.eventStop,
			},
		}

		forkJoin({
			accounts  : this.accountService.getAccountDetails(this.activeUser.userId),
			roles     : this.orgStructureService.getReportingRoles(this.activeUser.userId),
			timelines : this.dashboardService.getDashboardTimelines()
		}).subscribe(onSuccess.bind(this));

		function onSuccess(this : DashboardComponent, response) : void
		{
			response.timelines = sortBy(response.timelines, ['id']);
			response.roles     = response.roles.filter(role => role.viewFilter);

			Object.assign(this, response);
			this.filterForm.controls.account.setValue(this.accounts[0]);
			this.filterForm.controls.roles.setValue(this.roles.find(item => item.id == 'b9e492f7-7d28-4d78-a90f-f271cca9042d'))
		}

		this.onAccountChange();
		this.onTemplateChange();
		this.onFilterFormChange();
	}

	private onAccountChange() : void
	{
		this.filterForm.controls.account.valueChanges.subscribe(onAccountChanged.bind(this));
		function onAccountChanged(this: DashboardComponent, account : AccountDetails) : void
		{
			this.selectedAccount = account;
			this.templateService.getAccountTemplates(this.selectedAccount.accountId).subscribe(response => {
				this.templates = response;
				this.filterForm.controls.template.setValue(this.templates[0]);
			});
		}
	}

	private onTemplateChange() : void
	{
		this.filterForm.controls.template.valueChanges.subscribe(onTemplateChanged.bind(this))
		function onTemplateChanged(this : DashboardComponent, template : MasterTemplate) : void
		{
			this.selectedTemplate = template;
			this.currentTimezone  = template.timeZones.find(zone => zone.isDefault);

			this.filterForm.controls.timeline.setValue(this.timelines.find(timeline => timeline.code == 'todaystask'));
		}
	}

	private onFilterFormChange() : void
	{
		this.filterForm.valueChanges.subscribe(onValueChanged.bind(this));
		function onValueChanged(this : DashboardComponent, value) : void
		{
			if(isEqual(this.currentFilters, value)) return;
			this.currentFilters = value;

			if(!Object.values(value).some((x : any) => x == null || x.length == 0))
			{
				this.dashboardService.metricWidget(value.template.templateId, value.timeline.code).subscribe(data => {
					this.metricsWidgets  = this.dashboardService.generateWidgets(data);
				});

				if(this.refreshInterval) this.refreshInterval.unsubscribe();
				this.resizeGraphs();

				let tableObject;
				this.selectedTimeline = value.timeline;
				if(value.timeline.hasStatusCharts)
				{
					tableObject   = {
						tableName : 'todaystask',
						query     : 
							this.activeUser.accessLevel == 'allaccess'
							? `RowKey eq '${value.template.templateId}' and PartitionKey ne '${value.template.templateId}'`
							: `RowKey eq '${value.template.templateId}' and PartitionKey ne '${value.template.templateId}' and ${this.activeUser.OrgEntityColumn} eq '${this.activeUser.userId}'`
					};
					this.refreshInterval = timer(0, 120000).subscribe(() => this.onTemplateCount(tableObject.tableName, tableObject.query));
				}
				else
				{
					if(this.activeUser.accessLevel == 'allaccess')
					{
						tableObject   = {
							tableName : `acc${value.account.accountId}${value.timeline.code}`,
							query     : `PartitionKey eq 'template_${value.template.templateId}_${value.roles.id}'`
						};
					}
					else
					{
						tableObject   = {
							tableName : `emp${this.activeUser.userId.replaceAll('-', '')}${value.timeline.code}acc${this.selectedAccount.accountId}`,
							query     : `PartitionKey eq 'template_${value.template.templateId}_${value.roles.id}'`
						};
					}
					this.onTemplateCount(tableObject.tableName, tableObject.query);
				}
			}
		}
	}

	private onTemplateCount(tableName ?: string, customQuery ?: string) : void
	{
		this.azureTables.queryCustomEntities(tableName, customQuery).subscribe(onSuccess.bind(this));
		function onSuccess(this : DashboardComponent, data : any) : void
		{
			setTimeout(() => {
				if(this.selectedAccount.hasUsers)
				{
					for (let widget of this.metricsWidgets) widget.chart.showLoading();
					this.getWidgetChart(this.metricsWidgets, data);
				}
			}, 1500);
		}
	}

	private getWidgetChart(widgets, todaysData) : void
	{
		this.dashboardService.getChartData(this.selectedTemplate, widgets, todaysData).subscribe(setChartData.bind(this));
		function setChartData(this : DashboardComponent, data : Record<string, ChartData[]>) : void {
			for (let widget of widgets)
			{
				widget.chart.series.forEach((series, index) => {
					series.setData(data[widget.keys ? widget.keys[index] : widget.key]);
				});
				widget.chart.hideLoading();
			}
		}
	}
}