import { Injectable } from '@angular/core';
import { MetricService } from 'src/app/services/metric.service';
import { HttpClient } from '@angular/common/http';

import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import merge from 'lodash/merge';
import { Duration } from 'luxon';

import { MasterTemplate } from 'src/app/models/MasterTemplate.model';
import { DashboardTimelines } from 'src/app/models/dashboard-timelines.model';
import { Widget, ChartData } from './dashboard.model';
@Injectable()
export class DashboardService
{
	constructor(private metricService : MetricService, private http : HttpClient) {}

	metricWidget(templateId ?: number, timelineCode ?: string) : Observable<any>
	{
		return this.metricService.getMetricsConfiguration(templateId).pipe(map(preProcessData));

		function preProcessData(response) : Record<string, ChartData[]>
		{
			let data = timelineCode == 'todaystask' ? response.filter(metric => metric.dashboardDisplay) : response;
			return data.map(processData);

			function processData(metric)
			{
				let yAxis = (metric.type == 'time') ? { yAxis  : { labels : { formatter(point) {return Duration.fromObject({ seconds : point.value }).toFormat(metric.format)}} }} : {}
				let series = (metric.type == 'time')
					? {
						series: [
							{ name: 'Actual', tooltip: { pointFormatter() { return Duration.fromObject({ seconds: this.y }).toFormat(metric.format); } } },
							{ name: 'Target', tooltip: { pointFormatter() { return Duration.fromObject({ seconds: this.y }).toFormat(metric.format); } }, color: '#A696FF' }
						]
					}
					: {
						series: [
							{ name: 'Actual' }, { name: 'Target', color: '#A696FF' }
						]
					}

				return {
					title  : { text : metric.format ? `${metric.metricName} (${metric.format})` : `${metric.metricName}`},
					legend : { align: 'center', verticalAlign: 'top', floating: true },
					series : [ { name : 'Actual' }, { name: 'Target', color: '#A696FF' } ],
					keys   : [ `Actual${metric.actualColumn}`, `Target${metric.targetColumn}` ],
					...yAxis,
					...series
				};
			}
		}
	}

	generateWidgets(widget) : Widget[] {
		return widget.map(entry => {
			return {
				config : this.getChartConfig(entry),
				keys   : entry.keys,
			};
		});
	}

	getChartData(template: MasterTemplate, Widget, todaysData) : Observable<Record<string, ChartData[]>> {
		let keys = Widget.map(entry => entry.keys).flat();
		let baseObject = keys.reduce((object, key) => (object[key] = [], object), {});
		return of(todaysData).pipe(map(setChartData), catchError(() => of({})));

		function setChartData(data) : Record<string, ChartData[]> {
			return data.reduce(processData, baseObject);
		}

		function processData(config, entry) : Record<string, ChartData[]> {
			for (let key of keys) config[key].push(getDataObject(entry, key));
			return config;
		}

		function getDataObject(entry, key) : ChartData {
			return {
				id   : entry.PartitionKey,
				name : shortName(entry.UserName),
				y    : entry[key]
			};
		}

		function shortName (str) : string {
			var splitNames = str.trim().split(" ");
			if (splitNames.length > 1) {
				return (splitNames[0] + " " + splitNames[1].charAt(0) + ".");
			}
			return splitNames[0];
		};
	}

	private getChartConfig(widgetConfig) : Highcharts.ChartOptions 
	{
		return merge({
			chart: {
				type         : 'column',
				borderRadius : 8,
				borderWidth  : 1,
				borderColor  : '#ddd',
				style        : {
					fontFamily: 'Roboto'
				}
			},
			credits: {
				href : '',
				text : 'Admin Accounts'
			},
			title: {
				align  : 'left',
				margin : 20,
				style  : { 'font-size': '14px', 'font-weight': 'bold', 'color': '#663399' }
			},
			exporting: {
				buttons: {
					contextButton : {
						symbol    : 'menuball'
					}
				},
				sourceWidth  : 800,
				sourceHeight : 300,
				filename     : 'AA_Chart'
			},
			xAxis: {
				title: {
					text   : '',
					style  : { 'font-weight': 'bold' },
					margin : 13
				},
				type: 'category',
				labels: {
					style : { 'font-size': '12px', 'color': '#333' }
				},
			},
			yAxis: {
				tickAmount    : 5,
				allowDecimals : false,
				title         : { text: '' },
				currentMin    : 0,
				labels        : {
					format : '{value}'
				}
			},
			plotOptions : {
				series : {
					pointPadding : 0.0,
					color : '#663399D6',
				}
			}
		}, widgetConfig);
	}

	getDashboardTimelines(roleId ?: string) : Observable<DashboardTimelines[]>
	{
		return this.http.get<DashboardTimelines[]>('GetDashboardTimelines', {params: {roleId}});
	}
}