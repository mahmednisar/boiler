import * as Highcharts from 'highcharts';

export interface Widget {
	key     : string;
	config  : Highcharts.ChartOptions;
	chart  ?: Highcharts.Chart;
	keys   ?: any;
}

export interface ChartData {
	id   : string;
	name : string;
	y    : number;
}