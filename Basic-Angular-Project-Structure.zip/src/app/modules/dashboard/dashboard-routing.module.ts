import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService } from 'src/app/services/auth-guard.service';

import { AppLayoutComponent } from '../shared/components/app-layout/app-layout.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { UserDashboardComponent } from './components/user-dashboard/user-dashboard.component';

import { TeamOverviewComponent } from './components/team-overview/team-overview.component';
import { ReportsComponent } from './components/reports/reports.component';

let routes : Routes =
[
	{
		path             : '',
		component        : AppLayoutComponent,
		canActivateChild : [AuthGuardService],
		children         :
		[
			{
				path        : 'dashboard',
				component   : DashboardComponent,
				data        : {title: 'Dashboard', pageId : 'dashboard'}
			},
			{
				path        : 'user-dashboard',
				component   : UserDashboardComponent,
				data        : {title: 'Dashboard', pageId : 'user_dashboard'}
			},
			{
				path        : 'team-overview',
				component   : TeamOverviewComponent,
				data        : {title: 'Team Overview', pageId : 'team_overview'}
			},
			{
				path        : 'reports',
				component   : ReportsComponent,
				data        : {title: 'Reports', pageId : 'reports'}
			}
		]
	}
];

@NgModule({
	imports : [RouterModule.forChild(routes)],
	exports : [RouterModule]
})
export class DashboardRoutingModule {}