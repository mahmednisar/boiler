import { AuthService } from './auth.service';
export let providers = [AuthService];