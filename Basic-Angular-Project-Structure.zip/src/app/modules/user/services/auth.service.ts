import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { UserLoginData, UserLoginResponse } from 'src/app/models/user-login.model';
import { Role } from 'src/app/models/Role.model';
import { ActiveUserExternal } from 'src/app/models/active-user.model';

@Injectable()
export class AuthService {
	constructor(private http : HttpClient) {}

	login(data : UserLoginData) : Observable<UserLoginResponse> 
	{
		let headers = { Authorization : '' };
		return this.http.post<UserLoginResponse>('login', data, { headers });
	}

	forgotPassword(email : string) : Observable<any>
	{
		return this.http.get('ForgotPassword', {params: {email}});
	}

	changePassword(data : Record<any, any>) : Observable<any>
	{
		return this.http.post('ChangePassword', data);
	}

	resetPassword(data : any ) : Observable<any>
	{
		return this.http.post('ResetPassword', data );
	}

	getUserRoles(userId : string) : Observable<Role[]>
	{
		return this.http.get<Role[]>('GetUserRoles', {params: {userId}});
	}

	setCurrentRole(data : any) : Observable<UserLoginResponse>
	{
		return this.http.post<UserLoginResponse>('SetCurrentRole', data);
	}

	setPassword(data : ActiveUserExternal ) : Observable<any>
	{
		return this.http.post('SetPassword', data );
	}
}