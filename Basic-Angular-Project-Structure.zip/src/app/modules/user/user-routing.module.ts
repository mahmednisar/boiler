import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuardService } from 'src/app/services/auth-guard.service';

import { UnauthorizedComponent } from 'src/app/unauthorized';
import { NotFoundComponent } from 'src/app/not-found';
import { UserLoginComponent } from './components/user-login/user-login.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { RoleSelectionComponent } from './components/role-selection/role-selection.component';
import { SetPasswordComponent } from './components/set-password/set-password.component';

let routes : Routes =
[
	{
		path       : '',
		redirectTo : '/login',
		pathMatch  : 'full'
	},
	{
		path        : 'login',
		component   : UserLoginComponent,
		canActivate : [AuthGuardService],
		data        : { isGuestOnly : true, title : 'Login' }
	},
	{
		path        : 'forgot-password',
		component   : ForgotPasswordComponent,
		data        : { title : 'Forgot Password' }
	},
	{
		path        : 'reset-password',
		component   : ResetPasswordComponent,
		data        : { title : 'Reset Password' }
	},
	{
		path        : 'role-selection',
		component   : RoleSelectionComponent,
		data        : { title : 'Role Selection' }
	},
	{
		path        : 'set-password',
		component   : SetPasswordComponent,
		data        : {title: 'Set Password'}
	},
	{
		path      : 'un-authorized',
		component : UnauthorizedComponent
	},
	{
		path      : '**',
		component : NotFoundComponent
	}
];

@NgModule({
	imports : [RouterModule.forChild(routes)],
	exports : [RouterModule]
})
export class UserRoutingModule {}