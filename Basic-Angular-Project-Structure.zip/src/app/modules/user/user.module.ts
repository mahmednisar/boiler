import { NgModule } from '@angular/core';

import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { UserRoutingModule } from './user-routing.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { SharedModule } from '../shared/shared.module';
import { NgSelectModule } from '@ng-select/ng-select';

import { PopoverModule } from 'ngx-bootstrap/popover';

import {components} from './components';
import {providers} from './services';
import { SetPasswordComponent } from './components/set-password/set-password.component';


@NgModule({
	providers : providers,

	declarations : [...components, SetPasswordComponent],

	imports :
	[
		CommonModule,
		ReactiveFormsModule,
		UserRoutingModule,
		FontAwesomeModule,
		SharedModule,
		NgSelectModule,
		PopoverModule.forRoot()
	]
})
export class UserModule {}