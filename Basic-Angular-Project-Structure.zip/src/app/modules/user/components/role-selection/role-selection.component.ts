import { Component, HostBinding, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActiveUser } from 'src/app/models/active-user.model';
import { Role } from 'src/app/models/Role.model';
import { UserLoginResponse } from 'src/app/models/user-login.model';
import { ActiveUserService } from 'src/app/services/active-user.service';
import { AuthService } from '../../services/auth.service';

@Component({
	selector    : 'role-selection',
	templateUrl : './role-selection.component.html',
	styleUrls   : ['./role-selection.component.scss']
})
export class RoleSelectionComponent implements OnInit
{
	@HostBinding('class') class = 'wrapper d-flex align-items-center justify-content-center bg-light';

	roleSelectionForm : FormGroup;
	submitting        : boolean;
	errorMessage      : string;
	user              : ActiveUser
	userRoles         : Role[];

	constructor(
		private formBuilder       : FormBuilder,
		private authService       : AuthService,
		private activeUserService : ActiveUserService
	)
	{
		this.user = this.activeUserService.getUser();

		this.roleSelectionForm = this.formBuilder.group({
			roleId : [null, Validators.required],
			userId : this.user.userId
		});
	}

	ngOnInit(): void
	{
		this.authService.getUserRoles(this.user.userId).subscribe(response => this.userRoles = response);
	}

	changeRole() : void
	{
		if(this.roleSelectionForm.invalid) return;

		this.submitting = true;
		this.authService.setCurrentRole(this.roleSelectionForm.value).subscribe(setAndRedirectUser.bind(this));
		function setAndRedirectUser(this : RoleSelectionComponent, data : UserLoginResponse) : void
		{
			this.submitting = false;
			this.activeUserService.setUser(data.token);
			this.activeUserService.goToHomeScreen();
		}
	}

}
