import { Component, HostBinding } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

import { AuthService } from '../../services/auth.service';

import { IconDefinition, faKey } from '@fortawesome/pro-solid-svg-icons';
import { CValidators } from 'src/app/helpers/password-validators';
import { ActiveUserService } from 'src/app/services/active-user.service';
import { ActiveUser } from 'src/app/models/active-user.model';

@Component({
	selector    : 'reset-password',
	templateUrl : './reset-password.component.html',
	styleUrls   : ['./reset-password.component.scss']
})
export class ResetPasswordComponent {
	@HostBinding('class') class = 'wrapper d-flex align-items-center justify-content-center bg-light';

	resetPasswordForm : FormGroup;
	submitting        : boolean;
	showMessage       : boolean;
	fa                : Record<string, IconDefinition>;
	email             : string;
	token             : any;
	pattern           : any;
	user              : ActiveUser;
	
	constructor(
		private formBuilder       : FormBuilder,
		private route             : ActivatedRoute,
		private authService       : AuthService,
		private activeUserService : ActiveUserService
	)
	{
		this.pattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\s]).*$/;
		this.user    = this.activeUserService.getUser();
		this.fa      = { faKey };

		let { required, minLength, pattern }    = Validators;
		let { shouldNotBeName, matchPasswords } = CValidators;

		this.resetPasswordForm = this.formBuilder.group({
			password        : [null, [required, minLength(8), pattern(this.pattern), shouldNotBeName(this.user) ]],
			confirmPassword : [null, required],
		},
		{
			validators: this.password.bind(this)
		});

		this.route.queryParams.subscribe(params => 
		{
			this.email = params.email,
			this.token = params.token
		});
	}

	resetPassword() : void
	{
		if (this.resetPasswordForm.invalid) return;

		this.submitting = true;
		let postObject = {
			email                          : this.email,
			passwordResetConfirmationToken : this.token,
			newPassword                    : this.resetPasswordForm.value.password,
			confirmPassword                : this.resetPasswordForm.value.confirmPassword
		}
		this.authService.resetPassword(postObject).subscribe(onSuccess.bind(this), setError.bind(this));

		function onSuccess(this : ResetPasswordComponent) : void {
			this.submitting  = false;
			this.showMessage = true;
		}

		function setError(this : ResetPasswordComponent) : void {
			this.submitting = false;
		}
	}


	password(formGroup: FormGroup) {
		const { value: password } = formGroup.get('password');
		const { value: confirmPassword } = formGroup.get('confirmPassword');
		return password === confirmPassword ? null : { passwordNotMatch: true };
	}

}
