import { Component, HostBinding, OnInit} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { faKey, IconDefinition } from '@fortawesome/pro-solid-svg-icons';
import { parseJWT } from 'src/app/helpers/parseJWT';
import { CValidators } from 'src/app/helpers/password-validators';
import { ActiveUser } from 'src/app/models/active-user.model';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'set-password',
  templateUrl: './set-password.component.html',
  styleUrls: ['./set-password.component.scss']
})
export class SetPasswordComponent{
  @HostBinding('class') class = 'wrapper d-flex align-items-center justify-content-center bg-light';

	setPasswordForm   : FormGroup;
	submitting        : boolean;
	showMessage       : boolean;
	fa                : Record<string, IconDefinition>;
	email             : string;
	token             : any;
	pattern           : any;
  	user              : ActiveUser;
	firstname         : string;
	lastName          : string;

  constructor(
    private formBuilder       : FormBuilder,            private route             : ActivatedRoute,
	private authService       : AuthService
  ) { 
    this.pattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\s]).*$/;
		this.fa      = { faKey };

		let { required, minLength, pattern }    = Validators;
		let { shouldNotBeName,matchPasswords} = CValidators;

		this.route.queryParams.subscribe(params => 
			{
				this.email     = params.email,
				this.token     = params.token,
				this.firstname = params.firstname,
				this.lastName  = params.lastname
			});

		this.setPasswordForm = this.formBuilder.group({
			password        : [null, [required, minLength(8), pattern(this.pattern), shouldNotBeName({firstName:this.firstname,lastName:this.lastName})]],
			confirmPassword : [null, required],
		},
		{
			validators: [this.password,matchPasswords],
		});
  }

  setPassword() : void
	{
		if (this.setPasswordForm.invalid) return;

		this.submitting = true;
		let postObject = {
			email                          : this.email,
			passwordResetConfirmationToken : this.token,
			newPassword                    : this.setPasswordForm.value.password,
			confirmPassword                : this.setPasswordForm.value.confirmPassword
		}
		this.authService.setPassword(postObject).subscribe(onSuccess.bind(this), setError.bind(this));

		function onSuccess(this : SetPasswordComponent) : void {
			this.submitting  = false;
			this.showMessage = true;
		}

		function setError(this : SetPasswordComponent) : void {
			this.submitting = false;
		}
	}


	password(formGroup: FormGroup) {
		const { value: password } = formGroup.get('password');
		const { value: confirmPassword } = formGroup.get('confirmPassword');
		return password === confirmPassword ? null : { passwordNotMatch: true };
	}
}
