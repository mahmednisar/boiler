import { Component, OnInit, HostBinding } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { IconDefinition, faEnvelope, faKey } from '@fortawesome/pro-solid-svg-icons';

import { AuthService } from '../../services/auth.service';
import { ActiveUserService } from 'src/app/services/active-user.service';

import { HttpErrorResponse } from '@angular/common/http';
import { UserLoginData, UserLoginResponse } from 'src/app/models/user-login.model';
import { SwalService } from 'src/app/services/swal.service';

@Component({
	templateUrl : './user-login.component.html',
	styleUrls   : ['./user-login.component.scss']
})
export class UserLoginComponent implements OnInit {
	@HostBinding('class') class = 'wrapper d-flex align-items-center justify-content-center bg-light';

	loginForm    : FormGroup;
	submitting   : boolean;
	errorMessage : string;
	fa           : Record<string, IconDefinition>;


	constructor(
		private formBuilder       : FormBuilder,
		private authService       : AuthService,
		private activeUserService : ActiveUserService,
		private router            : Router,
		private route             : ActivatedRoute,
		private swal              : SwalService
	)
	{
		this.fa = { faEnvelope, faKey };
	}

	ngOnInit() : void {
		let { required, email } = Validators;

		this.loginForm = this.formBuilder.group({
			email    : ['', [required, email]],
			password : ['', required]
		});
	}

	login() : void {
		if (this.loginForm.invalid) return;

		this.submitting = true;
		this.authService.login((this.loginForm.value) as UserLoginData).subscribe(setAndRedirectUser.bind(this), setError.bind(this));

		function setAndRedirectUser(this : UserLoginComponent, data : UserLoginResponse) : void {
			this.submitting = false;
			this.activeUserService.setUser(data.token);
			this.swal.toast(`Welcome! ${this.activeUserService.getUser().fullName}`, 'success');

			let returnURL = this.route.snapshot.queryParams.returnURL;
			returnURL ? this.router.navigateByUrl(returnURL) : this.activeUserService.goToLanding();
		}

		function setError(this : UserLoginComponent, response : HttpErrorResponse) : void {
			this.submitting = false;
			this.errorMessage = response.error.message;
		}
	}
}