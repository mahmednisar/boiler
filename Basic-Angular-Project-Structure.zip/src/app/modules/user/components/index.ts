import { UserLoginComponent } from './user-login/user-login.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component'
import { RoleSelectionComponent } from './role-selection/role-selection.component';

export let components = 
[
	UserLoginComponent,
	ForgotPasswordComponent,
	ResetPasswordComponent,
	RoleSelectionComponent
];