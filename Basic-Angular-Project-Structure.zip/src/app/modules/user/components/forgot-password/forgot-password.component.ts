import { Component, HostBinding } from '@angular/core';

import { IconDefinition, faEnvelope } from '@fortawesome/pro-solid-svg-icons';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
	selector: 'forgot-password',
	templateUrl: './forgot-password.component.html',
	styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent {
	@HostBinding('class') class = 'wrapper d-flex align-items-center justify-content-center bg-light';

	forgotPasswordForm : FormGroup;
	submitting         : boolean;
	errorMessage       : string;
	showMessage        : boolean;
	fa                 : Record<string, IconDefinition>;

	constructor(
		private formBuilder : FormBuilder,
		private router      : Router,
		private authService : AuthService,
	)
	{
		this.fa = { faEnvelope };

		let { required, email } = Validators;
		this.forgotPasswordForm = this.formBuilder.group({email : [null, [required, email]]});
	}

	forgotPassword() : void
	{
		if (this.forgotPasswordForm.invalid) return;

		this.submitting = true;
		this.authService.forgotPassword(this.forgotPasswordForm.value.email).subscribe(onSuccess.bind(this), setError.bind(this))

		function onSuccess(this : ForgotPasswordComponent) : void {
			this.submitting  = false;
			this.showMessage = true;
		}

		function setError(this : ForgotPasswordComponent, response : HttpErrorResponse) : void {
			this.submitting = false;
			this.errorMessage = response.error.message;
		}
	}

}
