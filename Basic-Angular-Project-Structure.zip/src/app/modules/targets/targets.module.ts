import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {components} from './components';

import { TargetsRoutingModule } from './targets-routing.module';
import { SharedModule } from '../shared/shared.module';

import { NgSelectModule } from '@ng-select/ng-select';
import { ReactiveFormsModule } from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { ButtonsModule } from 'ngx-bootstrap/buttons';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { ModalModule } from 'ngx-bootstrap/modal';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from '@danielmoncada/angular-datetime-picker';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { PopoverModule } from 'ngx-bootstrap/popover';
@NgModule({
	declarations : [...components],
	imports      : [
		TargetsRoutingModule,
		CommonModule,
		ReactiveFormsModule,
		NgSelectModule,
		FontAwesomeModule,
		SharedModule,
		
		TabsModule.forRoot(),
		ButtonsModule.forRoot(),
		TimepickerModule.forRoot(),
		TooltipModule.forRoot(),
		ModalModule.forRoot(),
		PopoverModule.forRoot(),
		OwlDateTimeModule,
		OwlNativeDateTimeModule,
	]
})
export class TargetsModule { }
