import { Component, Input, OnChanges } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';

import { IconDefinition, faBan, faPencilAlt, faPlus } from '@fortawesome/pro-solid-svg-icons';
import { faTimes, faCheck } from '@fortawesome/pro-light-svg-icons';
import { faInfoCircle } from '@fortawesome/pro-regular-svg-icons';

import { DateTimeFormatterService } from 'src/app/services/date-time-formatter.service';

import { TimezoneModel } from 'src/app/models/MasterTemplate.model';
import { Targets } from 'src/app/models/targets.model';
import { AccountDetails } from 'src/app/models/acount-details.model';
import { TargetsAccount } from 'src/app/models/targets-account.model';
import { TargetService } from 'src/app/services/target.service';
import { DateTime } from 'luxon';
@Component({
	selector    : 'account-target',
	templateUrl : './account-target.component.html',
	styleUrls   : ['./account-target.component.scss']
})
export class AccountTargetComponent implements OnChanges {

	@Input() selectedAccount   : AccountDetails;
	@Input() selectedTargetTab : number;

	fa                : Record<string, IconDefinition>;
	isSelectedTargets : Targets;
	targets           : TargetsAccount[];
	timelines         : { key: string; value: any; }[];
	timelineForm      : FormControl;
	targetEditControl : FormControl;
	selectedDate      : Date;
	todaysDate        : Date;
	yesterdaysDate    : Date;
	timePickerMax     : Date;

	constructor(
		private dateTimeFormat : DateTimeFormatterService,
		private targetService  : TargetService
	) {
		this.timelineForm      = new FormControl();
		this.fa                = { faTimes, faBan, faPencilAlt, faPlus, faCheck, faInfoCircle };
		this.targetEditControl = new FormControl();
	}

	ngOnChanges(): void
	{
		if (this.selectedTargetTab == 0)
		{
			this.onTimelineChange();
			this.getDatesAndTimelines(this.selectedAccount.timeZone);
		}
	}

	private onTimelineChange(): void
	{
		this.timelineForm.valueChanges.subscribe(onTimelineValueChanges.bind(this));
		function onTimelineValueChanges(this: AccountTargetComponent, value: Date): void
		{
			if (value.getDate() == this.todaysDate.getDate() && value.getMonth() == this.todaysDate.getMonth() && value.getFullYear() == this.todaysDate.getFullYear()) {
				value = this.todaysDate;
			}
			if (value.getDate() == this.yesterdaysDate.getDate() && value.getMonth() == this.yesterdaysDate.getMonth() && value.getFullYear() == this.yesterdaysDate.getFullYear()) {
				value = this.yesterdaysDate;
			}
			value ? this.timelineForm.setValue(value, { emitEvent: false }) : this.timelineForm.setValue(this.todaysDate);
			this.getAccountTargets(this.timelineForm.value, false);
		}
	}

	private getDatesAndTimelines(timezone: TimezoneModel): void
	{
		this.todaysDate     = this.dateTimeFormat.getTodaysDate(timezone.utcOffset);
		this.yesterdaysDate = this.dateTimeFormat.getYesterdaysDate(timezone.utcOffset);
		this.timelineForm.setValue(this.todaysDate);
		this.timelines = [
			{ key: "Today", value: this.todaysDate },
			{ key: "Yesterday", value: this.yesterdaysDate },
		];
	}

	getAccountTargets(date: Date, reloadSame: boolean): void
	{
		if(this.selectedDate == date && !reloadSame) return;

		this.selectedDate = date;
		this.targetService.getAccountTargets(this.selectedAccount.accountId, this.dateTimeFormat.toTimezoneISO(date)).subscribe(response => this.targets = response);
	}

	editTarget(targetindex: number): void
	{
		if (this.selectedDate >= this.todaysDate)
		{
			let temp              = DateTime.fromSeconds(this.targets[targetindex].maxTarget).setZone('utc');
			this.timePickerMax    = DateTime.local().set({ hour: temp.hour, minute: temp.minute, second: temp.second }).toJSDate();
			var targetTime        = this.targets[targetindex].targetValue.split(':');
			var targetValueToTime = DateTime.local().set({ hour: +targetTime[0], minute: +targetTime[1], second: 0 }).toJSDate();

			this.targetEditControl.setValue(targetValueToTime);
			
			this.targets.forEach((item, index) => {
				!item.editing ? (item.editing = targetindex == index ? true : false) : item.editing = false;
			});
		}
	}

	saveTarget(target: TargetsAccount): void
	{
		if(!this.targetEditControl.value) return;

		target.editing        = false;
		let targetValueFormat = DateTime.fromJSDate(this.targetEditControl.value).toFormat('HH:mm:ss');

		let oldTarget = target.targetValue;
		let newValue  = targetValueFormat;

		if (oldTarget != newValue) 
		{
			target.targetValue = targetValueFormat;
			this.targetService.addUpdateWorkSchedule({ ...target }).subscribe(() => this.getAccountTargets(this.selectedDate, true));
		}
	}
}

