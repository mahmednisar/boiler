import { Component, Input } from '@angular/core';
import { MetricsConfiguration } from 'src/app/models/MetricsConfiguration.model';
import { FormGroup } from '@angular/forms';

@Component({
	selector    : 'metric-field',
	templateUrl : './metric-field.component.html',
	styleUrls   : ['./metric-field.component.scss']
})
export class MetricFieldComponent {

	@Input() metric : MetricsConfiguration;
	@Input() form   : FormGroup;

}
