import { Component, OnInit, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { TargetService } from 'src/app/services/target.service';
import { BsModalRef } from 'ngx-bootstrap/modal';

import { IconDefinition, faTimesCircle } from '@fortawesome/pro-solid-svg-icons';

import { Targets } from 'src/app/models/targets.model';

@Component({
	templateUrl : './deactivate-target.component.html',
	styleUrls   : ['./deactivate-target.component.scss']
})
export class DeactivateTargetComponent implements OnInit {

	public event = new EventEmitter();
	
	target       : Targets;
	selectedDate : Date;

	fa   : Record<string, IconDefinition>;
	form : FormGroup

	constructor(
		public  activeModal   : BsModalRef,
		private targetService : TargetService,
		private formBuilder   : FormBuilder
	) {
		this.fa = { faTimesCircle };

		this.form = this.formBuilder.group({
			targetId       : null,
			deactivateDate : null,
			isReactivate   : null,
			reactivateDate : null,
		});
	}

	ngOnInit(): void {
		this.form.controls.targetId.setValue(this.target.targetId);
		this.form.controls.deactivateDate.setValue(this.selectedDate);
		this.onFormChange();
	}

	deactivate() : void
	{
		if(this.form.invalid) return;

		var data = { ...this.form.value };
		this.targetService.deactivateTarget(data).subscribe(onSuccess.bind(this));

		function onSuccess(this : DeactivateTargetComponent, data : any)
		{
			this.event.emit({success : true});
			this.activeModal.hide();
		}
	}

	private onFormChange()
	{
		this.form.controls.isReactivate.valueChanges.subscribe(value => {
			value ? this.form.controls.reactivateDate.setValidators([Validators.required]) : this.form.controls.reactivateDate.setValidators(null);
		});
	}
}
