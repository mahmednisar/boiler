import { Component, OnChanges, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { forkJoin, Observable } from 'rxjs';

import { IconDefinition, faTimes } from '@fortawesome/pro-solid-svg-icons';

import { DateTimeFormatterService } from 'src/app/services/date-time-formatter.service';
import { UserService } from 'src/app/services/user.service';
import { MetricService } from 'src/app/services/metric.service';
import { FormGeneratorService } from 'src/app/services/form-generator.service';
import { TargetService } from 'src/app/services/target.service';

import { MasterTemplate } from 'src/app/models/MasterTemplate.model';
import { User } from 'src/app/models/User.model';
import { MetricsConfiguration } from 'src/app/models/MetricsConfiguration.model';
import { Targets } from 'src/app/models/targets.model';


@Component({
	selector    : 'add-edit-target',
	templateUrl : './add-edit-target.component.html',
	styleUrls   : ['./add-edit-target.component.scss']
})
export class AddEditTargetComponent implements OnChanges {

	@Input() template   : MasterTemplate;
	@Input() target     : Targets;
	@Input() selectDate : Date;
	
	@Output() onClose = new EventEmitter();
	@Output() onAdd   = new EventEmitter();

	fa               : Record<string, IconDefinition>;
	addTargetsForm   : FormGroup;
	metricsFieldForm : FormGroup;
	metrics          : MetricsConfiguration[];
	users            : User[];

	yesterdaysDate : Date;

	constructor(
		private formBuilder          : FormBuilder,
		private dateTimeFormat       : DateTimeFormatterService,
		private userService          : UserService,
		private metricService        : MetricService,
		private formGeneratorService : FormGeneratorService,
		private targetService        : TargetService
	) {
		this.fa = { faTimes };

		this.addTargetsForm = this.formBuilder.group({
			targetDate : ['', Validators.required],
			users      : ['', Validators.required]
		});
	}

	ngOnChanges(): void 
	{
		if(this.target) 
		{
			this.removeValidators();
			this.addTargetsForm.controls.users.setValue([this.target.userId]);
		}

		let currentTimezone = this.template.timeZones.find(zone => zone.isDefault);
		this.yesterdaysDate = this.dateTimeFormat.getYesterdaysDate(currentTimezone.utcOffset);
		this.addTargetsForm.controls.targetDate.setValue(this.selectDate);

		this.getData(this.template);
	}

	private removeValidators() : void
	{
		this.addTargetsForm.controls.targetDate.setValidators(null);
		this.addTargetsForm.controls.users.setValidators(null);
	}

	private getData(template: MasterTemplate): void
	{
		forkJoin({
			users   : getUsers.call(this, template),
			metrics : this.metricService.getMetricsConfiguration(template.templateId)
		}).subscribe(onDataGet.bind(this));

		function onDataGet(this: AddEditTargetComponent, data: any): void{
			Object.assign(this, data);

			this.metricsFieldForm = this.formGeneratorService.generateMetricForm(this.metrics);
		}

		function getUsers(this: AddEditTargetComponent, template: MasterTemplate): Observable<User[]> 
		{
			return this.userService.getUsers({
				accountId    : template.primaryEntity,
				subAccountId : template.secondaryEntity,
				functionCode : "canprocesstask"
			});
		}
	}

	addTargets(): void {
		if (!this.addTargetsForm.valid || !this.metricsFieldForm.valid) return;

		let data = { ...this.addTargetsForm.value };

		data.accountId    = this.template.primaryEntity;
		data.subAccountId = this.template.secondaryEntity;
		data.templateId   = this.template.templateId;
		data.metrics      = this.getMetricsData();
		data.activeFrom   = this.dateTimeFormat.toTimezoneISO(data.targetDate);

		this.targetService.addTargets(data).subscribe(onSuccess.bind(this));

		function onSuccess(this: AddEditTargetComponent, data: any): void 
		{
			this.onAdd.emit({targetDate : this.addTargetsForm.controls.targetDate.value});
			this.closeAddTargets();
		}
	}

	private getMetricsData(): any 
	{
		return this.metrics.map((metric) => {
			return {
				metricId    : metric.metricId,
				metricName  : metric.metricName,
				targetValue : (metric.type == 'time' ? (this.metricsFieldForm.value[metric.metricName] ? this.metricsFieldForm.value[metric.metricName].toLocaleTimeString('it-IT') : null) : this.metricsFieldForm.value[metric.metricName]) || 0
			};
		});
	}

	closeAddTargets() : void
	{
		this.onClose.emit();
		this.addTargetsForm.reset();
		this.metricsFieldForm.reset();
	}

}
