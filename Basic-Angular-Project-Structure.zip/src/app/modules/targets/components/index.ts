import { TargetsComponent } from './targets/targets.component';
import { MetricFieldComponent } from './metric-field/metric-field.component';
import { AddEditTargetComponent } from './add-edit-target/add-edit-target.component';
import { DeactivateTargetComponent } from './deactivate-target/deactivate-target.component';
import { AccountTargetComponent } from './account-target/account-target.component';
import { TemplateTargetComponent } from './template-target/template-target.component';


export let components =
[
	TargetsComponent,
	MetricFieldComponent,
	AddEditTargetComponent,
	DeactivateTargetComponent,
	AccountTargetComponent,
	TemplateTargetComponent
];