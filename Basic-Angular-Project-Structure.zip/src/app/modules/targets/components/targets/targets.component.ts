import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';

import { ActiveUserService } from 'src/app/services/active-user.service';
import { AccountService } from 'src/app/services/account.service';

import { TimezoneModel } from 'src/app/models/MasterTemplate.model';
import { ActiveUser } from 'src/app/models/active-user.model';
import { AccountDetails } from 'src/app/models/acount-details.model';
import { TargetsAccount } from 'src/app/models/targets-account.model';

@Component({
	templateUrl : './targets.component.html',
	styleUrls   : ['./targets.component.scss']
})
export class TargetsComponent implements OnInit {
	
	accountSelect    : FormControl;
	accounts         : AccountDetails[];
	activeUser       : ActiveUser;
	selectedAccount  : AccountDetails;
	currentTimezone  : TimezoneModel;
	selectedTargetTab: number;

	constructor
	(
		private activeUserService : ActiveUserService,
		private accountService    : AccountService,
	)
	{
		this.activeUser 		= this.activeUserService.getUser();
		this.accountSelect  	= new FormControl();
		this.selectedTargetTab  = 0;
	}

	ngOnInit() : void
	{
		this.accountService.getAccountDetails(this.activeUser.userId).subscribe(onSuccess.bind(this));
		function onSuccess(this: TargetsComponent, response : AccountDetails[]) : void
		{
			this.accounts = response;
			this.accountSelect.setValue(this.accounts[0]);
		}
		this.onAccountChange();
	}

	onAccountChange() : void
	{
		this.accountSelect.valueChanges.subscribe((value: AccountDetails) => {
			this.selectedAccount = value;
			this.currentTimezone = value.timeZone;
		});	
	}

	selectTarget(index : number = null) : void
	{
		this.selectedTargetTab = index;
	}

}
