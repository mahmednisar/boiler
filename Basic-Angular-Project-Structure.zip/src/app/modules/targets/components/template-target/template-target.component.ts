import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { map } from 'rxjs/operators';

import { IconDefinition, faTimes, faBan, faPencilAlt, faPlus } from '@fortawesome/pro-solid-svg-icons';

import { ActiveUserService } from 'src/app/services/active-user.service';
import { TemplateService } from 'src/app/services/template.service';
import { MetricService } from 'src/app/services/metric.service';
import { TargetService } from 'src/app/services/target.service';
import { DateTimeFormatterService } from 'src/app/services/date-time-formatter.service';
import { BsModalService } from 'ngx-bootstrap/modal';

import { DeactivateTargetComponent } from '../deactivate-target/deactivate-target.component';

import { MetricsConfiguration } from 'src/app/models/MetricsConfiguration.model';
import { MasterTemplate, TimezoneModel } from 'src/app/models/MasterTemplate.model';
import { ActiveUser } from 'src/app/models/active-user.model';
import { Targets } from 'src/app/models/targets.model';
import { AccountDetails } from 'src/app/models/acount-details.model';
@Component({
	selector    : 'template-target',
	templateUrl : './template-target.component.html',
	styleUrls   : ['./template-target.component.scss']
})
export class TemplateTargetComponent implements OnInit, OnChanges
{
	@Input() selectedAccount   : AccountDetails;
	@Input() selectedTargetTab : number;


	templates         : MasterTemplate[];
	accounts          : AccountDetails[];
	activeUser        : ActiveUser;
	selectedTemplate  : MasterTemplate;
	metrics           : MetricsConfiguration[];
	targets           : Targets[];
	isSelectedTargets : Targets;
	currentTimezone   : TimezoneModel;

	timelineForm      : FormControl;
	templateSelect    : FormControl;

	fa                : Record<string, IconDefinition>;
	timelines         : { key: string; value: any; }[];
	isAddTargets      : boolean;
	todaysDate        : Date;
	yesterdaysDate    : Date;
	selectedDate      : Date;

	constructor(
		private activeUserService : ActiveUserService,
		private templateService   : TemplateService,
		private metricService     : MetricService,
		private targetService     : TargetService,
		private dateTimeFormat    : DateTimeFormatterService,
		private modalService      : BsModalService,
	) {
		this.activeUser     = this.activeUserService.getUser();
		this.templateSelect = new FormControl();
		this.timelineForm   = new FormControl();
		this.fa             = { faTimes, faBan, faPencilAlt, faPlus };
	}

	ngOnInit() : void
	{
		this.onTemplateChange();
		this.onTimelineChange();
	}

	ngOnChanges(): void
	{
		if (this.selectedTargetTab == 1) {
			this.templateService.getAccountTemplates(this.selectedAccount.accountId).subscribe(response => {
				this.templates = response.filter(item => !item.noComputation);
				this.templateSelect.setValue(this.templates[0]);
			});
		}
	}

	private onTemplateChange(): void
	{
		this.templateSelect.valueChanges.pipe(
			map(getMetricConfigs.bind(this))
		).subscribe(onTemplateSelected.bind(this));

		function getMetricConfigs(this: TemplateTargetComponent, template: MasterTemplate): MasterTemplate
		{
			this.metricService.getMetricsConfiguration(template.templateId).subscribe(response => {
				this.metrics = response;
				this.timelineForm.setValue(this.todaysDate);
			});
			return template;
		}

		function onTemplateSelected(this: TemplateTargetComponent, template: MasterTemplate): void
		{
			if (!template) return;
			this.selectedTemplate = template;
			this.currentTimezone  = template.timeZones.find(zone => zone.isDefault);
			this.getDatesAndTimelines(this.currentTimezone);
		}
	}

	private onTimelineChange(): void
	{
		this.timelineForm.valueChanges.subscribe(value => {
			if (value.getDate() == this.todaysDate.getDate() && value.getMonth() == this.todaysDate.getMonth() && value.getFullYear() == this.todaysDate.getFullYear()) {
				value = this.todaysDate;
			}
			if (value.getDate() == this.yesterdaysDate.getDate() && value.getMonth() == this.yesterdaysDate.getMonth() && value.getFullYear() == this.yesterdaysDate.getFullYear()) {
				value = this.yesterdaysDate;
			}
			value ? this.timelineForm.setValue(value, { emitEvent: false }) : this.timelineForm.setValue(this.todaysDate);
			this.getTargets(this.timelineForm.value, false);
		});
	}

	private getDatesAndTimelines(timezone: TimezoneModel): void
	{
		this.todaysDate     = this.dateTimeFormat.getTodaysDate(timezone.utcOffset);
		this.yesterdaysDate = this.dateTimeFormat.getYesterdaysDate(timezone.utcOffset);
		this.timelineForm.setValue(this.todaysDate);
		this.timelines = [
			{ key: "Today", value: this.todaysDate },
			{ key: "Yesterday", value: this.yesterdaysDate },
		];
	}

	getTargets(date: Date, reloadSame: boolean): void 
	{
		if(this.selectedDate == date && !reloadSame) return;

		this.selectedDate = date;
		this.targetService.getTargets(this.selectedTemplate.templateId, this.dateTimeFormat.toTimezoneISO(date)).subscribe(response => this.targets = response);
	}

	closeAddTargets(): void
	{
		this.isAddTargets      = !this.isAddTargets;
		this.isSelectedTargets = null;
	}

	onTargetAdded(targetDate: Date): void
	{
		this.timelineForm.setValue(targetDate);
	}

	editTargets(target: Targets): any
	{
		this.isAddTargets      = !this.isAddTargets;
		this.isSelectedTargets = target;
	}

	deactivateTarget(target: Targets): any 
	{
		var initialState = {
			target       : target,
			selectedDate : this.selectedDate
		};
		let modalRef = this.modalService.show(DeactivateTargetComponent, { initialState });
		modalRef.content.event.subscribe(onValueEmit.bind(this));

		function onValueEmit(this: TemplateTargetComponent, data: any): void
		{
			if (data.success) this.getTargets(this.selectedDate, true);
		}
	}


}
