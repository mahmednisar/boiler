import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppLayoutComponent } from '../shared/components/app-layout/app-layout.component';
import { AuthGuardService } from 'src/app/services/auth-guard.service';

import { TargetsComponent } from './components/targets/targets.component';

let routes : Routes = 
[
	{
		path             : '',
		component        : AppLayoutComponent,
		canActivateChild : [AuthGuardService],
		children         : 
		[
			{
				path      : 'targets',
				component : TargetsComponent,
				data      : {title : 'Targets', pageId: 'targets'}
			}
		]
	}
];

@NgModule({
	imports : [RouterModule.forChild(routes)],
	exports : [RouterModule]
})
export class TargetsRoutingModule { }
