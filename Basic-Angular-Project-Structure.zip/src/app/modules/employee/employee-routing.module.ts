import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppLayoutComponent } from '../shared/components/app-layout/app-layout.component';
import { AuthGuardService } from '../../services/auth-guard.service';
import { EmployeeComponent } from './components/employee/employee.component';
import { UserProfileComponent } from './components/user-profile/user-profile.component';

let routes : Routes = 
[
	{
		path             : '',
		component        : AppLayoutComponent,
		canActivateChild : [AuthGuardService],
		children         : 
		[
			{
				path      : 'employee-list',
				component : EmployeeComponent,
				data      : {title : 'Employee', pageId : 'employee_list'}
			},
			{
				path      : 'user-profile',
				component : UserProfileComponent,
				data      : {title : 'Profile', pageId : 'user_profile'}
			}
		]
	}
];

@NgModule({
	imports : [RouterModule.forChild(routes)],
	exports : [RouterModule]
})
export class EmployeeRoutingModule { }
