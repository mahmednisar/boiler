import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EmployeeRoutingModule } from './employee-routing.module';
import { SharedModule } from '../shared/shared.module';

import { NgSelectModule } from '@ng-select/ng-select';
import { ReactiveFormsModule } from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { ModalModule } from 'ngx-bootstrap/modal';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from '@danielmoncada/angular-datetime-picker';

import { EmployeeComponent } from './components/employee/employee.component';
import { AddEmployeeComponent } from './components/add-employee/add-employee.component';
import { DeactivateEmployeeComponent } from './components/deactivate-employee/deactivate-employee.component';
import { UserProfileComponent } from './components/user-profile/user-profile.component';
import { ChangePasswordComponent } from './components/change-password/change-password.component';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { EditProfileComponent } from './components/edit-profile/edit-profile.component';

let components = 
[
	EmployeeComponent,
	AddEmployeeComponent,
	DeactivateEmployeeComponent,
	UserProfileComponent,
	ChangePasswordComponent,
	EditProfileComponent
]


@NgModule({
	declarations : [...components],
	imports      : [
		EmployeeRoutingModule,
		CommonModule,
		ReactiveFormsModule,
		NgSelectModule,
		FontAwesomeModule,
		SharedModule,

		PaginationModule.forRoot(),
		AccordionModule.forRoot(),
		PopoverModule.forRoot(),
		ModalModule.forRoot(),
		TooltipModule.forRoot(),
		TabsModule.forRoot(),
		OwlDateTimeModule,
		OwlNativeDateTimeModule,
	]
})
export class EmployeeModule { }
