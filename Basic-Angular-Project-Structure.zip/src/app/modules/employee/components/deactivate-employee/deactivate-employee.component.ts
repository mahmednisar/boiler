import { Component, EventEmitter, OnInit } from '@angular/core';
import { Employee } from 'src/app/models/employee.model';

import { IconDefinition, faTimesCircle } from '@fortawesome/pro-solid-svg-icons';
import { EmployeeService } from 'src/app/services/employee.service';
import { BsModalRef } from 'ngx-bootstrap/modal';

@Component({
	selector    : 'deactivate-employee',
	templateUrl : './deactivate-employee.component.html',
	styleUrls   : ['./deactivate-employee.component.scss']
})
export class DeactivateEmployeeComponent 
{
	public event = new EventEmitter();

	employee : Employee;
	fa       : Record<string, IconDefinition>;

	constructor(
		public  activeModal     : BsModalRef,
		private employeeService : EmployeeService,
	)
	{
		this.fa = { faTimesCircle };
	}

	deactivate() : void
	{
		this.employeeService.deactivateEmployee(this.employee.userId).subscribe(onSuccess.bind(this));

		function onSuccess(this : DeactivateEmployeeComponent, data : any)
		{
			this.event.emit({success : true});
			this.activeModal.hide();
		}
	}
}
