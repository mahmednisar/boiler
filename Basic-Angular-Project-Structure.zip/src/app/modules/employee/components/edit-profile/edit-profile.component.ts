import { Component, EventEmitter, OnInit } from '@angular/core';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EmployeeService } from 'src/app/services/employee.service';
import { DateTimeFormatterService } from 'src/app/services/date-time-formatter.service';
import { BsModalRef } from 'ngx-bootstrap/modal';

import { IconDefinition, faTimes } from '@fortawesome/pro-light-svg-icons';
import { Employee } from 'src/app/models/employee.model';

@Component({
	selector    : 'edit-profile',
	templateUrl : './edit-profile.component.html',
	styleUrls   : ['./edit-profile.component.scss']
})
export class EditProfileComponent implements OnInit
{
	public event = new EventEmitter();

	employee        : Employee;
	fa              : Record<string, IconDefinition>;
	currentDateTime : any;
	form            : FormGroup;
	isWrongSize     : boolean;

	constructor(
		public  activeModal     : BsModalRef,
		private formBuilder     : FormBuilder,
		private employeeService : EmployeeService,
		private dateTimeFormat  : DateTimeFormatterService
	) {
		this.fa = { faTimes };
	}

	ngOnInit(): void 
	{
		this.currentDateTime = this.dateTimeFormat.getTodaysDate('-07:00:00');
		this.form            = this.formBuilder.group
		({
			firstName     : [null, Validators.required],
			middleName    : null,
			lastName      : [null, Validators.required],
			phoneNumber   : null,
			dob           : null,
			imageUrl      : null,
			profileImg    : null,
			userId        : this.employee.userId,
			email         : this.employee.email,
			psgEmployeeId : this.employee.psgEmployeeId,
		});
		this.form.patchValue(this.employee);
	}

	onFileChange(event)
	{
		const reader = new FileReader();
		if (event.target.files[0].size > 1000000) this.isWrongSize = true;
		else {
			this.isWrongSize = false;
			this.form.controls.profileImg.setValue(event.target.files[0])
			const [file] = event.target.files;
			reader.readAsDataURL(this.form.controls.profileImg.value);
			reader.onload = () => {
				this.employee.imageUrl = reader.result as string;
				this.form.controls.imageUrl.setValue(reader.result as string);
			};
		}
	}

	updateProfile() : void
	{
		if(this.form.invalid) return;

		let data = {...this.form.value};
		data.dob = this.dateTimeFormat.toTimezoneISO(data.dob);

		this.employeeService.updateProfile(data).subscribe(onSuccess.bind(this));
		function onSuccess(this : EditProfileComponent, response) : void
		{
			this.event.emit({success : true});
			this.activeModal.hide();
		}
	}

}
