import { Component, EventEmitter, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { forkJoin } from 'rxjs';

import { AccountService } from 'src/app/services/account.service';
import { ActiveUserService } from 'src/app/services/active-user.service';
import { EmployeeService } from 'src/app/services/employee.service';
import { DateTimeFormatterService } from 'src/app/services/date-time-formatter.service';

import { AccountDetails, RoleDetails } from 'src/app/models/acount-details.model';
import { ActiveUser } from 'src/app/models/active-user.model';

import { IconDefinition, faTimes, faPlus, faMinus, faExclamationTriangle, faInfoCircle } from '@fortawesome/pro-regular-svg-icons';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { Employee } from 'src/app/models/employee.model';
import { cloneDeep, differenceBy, isEqual } from 'lodash';

@Component({
	selector    : 'add-employee',
	templateUrl : './add-employee.component.html',
	styleUrls   : ['./add-employee.component.scss']
})
export class AddEmployeeComponent implements OnInit
{
	public event = new EventEmitter();
	employee             : Employee;
	selectedAccounts     : AccountDetails[];
	addEmployeeForm      : FormGroup;
	userAccounts         : FormArray;
	accountSelectControl : FormControl;
	submitted            : boolean;
	activeUsers          : ActiveUser;
	cacheAccounts        : AccountDetails[];
	accounts             : AccountDetails[];
	cacheRoles           : RoleDetails[];
	roles                : any;
	subAccounts          : any;
	reporting            : any;
	fa                   : Record<string, IconDefinition>;
	currentDateTime      : Date;
	accountControl       : FormControl;
	isNewlyAdded         : any;
	currentMock: any[];

	constructor(
		private formBuilder       : FormBuilder,
		private accountService    : AccountService,
		private activeUserService : ActiveUserService,
		private employeeService   : EmployeeService,
		public activeModal        : BsModalRef,
		private dateTimeFormat    : DateTimeFormatterService,
	)
	{
		this.fa                 = { faTimes, faPlus, faMinus, faExclamationTriangle, faInfoCircle };
		this.activeUsers        = this.activeUserService.getUser();
		this.subAccounts        = {};
		this.roles              = {};
		this.reporting          = {};
		this.isNewlyAdded       = [];
		this.selectedAccounts   = [];
		this.currentMock        = [];

		let { required, email } = Validators;
		this.accountControl     = new FormControl();
		this.userAccounts       = this.formBuilder.array([]);
		this.addEmployeeForm    = this.formBuilder.group({
			firstName     : [null, required],
			lastName      : [null, required],
			email         : [null, [required, email]],
			psgEmployeeId : [null, required],
			phoneNumber   : null,
			dob           : null,
			userAccounts  : this.userAccounts,
			userId        : this.employee ? this.employee.userId : null,
			hireDate      : null
		});
	}

	ngOnInit() : void
	{
		this.currentDateTime = this.dateTimeFormat.getTodaysDate('-07:00:00');

		forkJoin([
			this.accountService.getAccountDetails(this.activeUsers.userId),
			this.accountService.getRoleDetails()
		]).subscribe(onSuccess.bind(this));
		function onSuccess(this : AddEmployeeComponent, response : any) : void
		{
			this.cacheAccounts = this.accounts = response[0];
			this.cacheRoles    = response[1].filter(role => role.name != 'Admin');
			this.accounts.forEach(account => this.subAccounts[account.accountId] = account.subAccountDetails);
			if(this.employee) this.patchData();
		}

		this.onUserAccountChanges();
	}

	patchData() : any
	{
		if (!this.employee) return;

		this.employee.userAccounts.forEach((account, index) => {
			this.addAccountAdded(account as AccountDetails, false );
			var subAccountIds = [];
			account.subaccounts.forEach(subacc => subAccountIds.push(subacc.subAccountId));
			return account.subaccounts = subAccountIds;
		});
		this.addEmployeeForm.patchValue(this.employee);
	}

	addAccountAdded(account : AccountDetails, value ?: boolean) : void
	{
		this.userAccounts.push(this.generateMappingControl(account));
		this.accountControl.reset();
		
		this.accounts                 = this.accounts.filter(item => item.accountId != account.accountId);
		this.roles[account.accountId] = this.cacheRoles;
		
		this.isNewlyAdded[account.accountId] = value;
	}

	private generateMappingControl(account : AccountDetails) : FormGroup
	{
		return this.formBuilder.group({
			roleIds     : [null, Validators.required],
			subaccounts : [null, Validators.required],
			reportings  : [null, Validators.required],
			accountId   : account.accountId,
		});
	}

	removeMappingControl(index : number) : void
	{
		this.userAccounts.removeAt(index);
		this.accounts = differenceBy(this.cacheAccounts, this.userAccounts.value, 'accountId')
	}

	onRoleChange(selectedRole: RoleDetails[], accountId : number) : void
	{
		if(selectedRole.length)
		{
			if(selectedRole[0].name == 'Auditor' || selectedRole[0].name == 'User')
			{
				this.roles[accountId] = this.cacheRoles.filter(role => role.name == 'Auditor' || role.name == 'User');
			}
			else this.roles[accountId] = this.cacheRoles.filter(role => role.name == selectedRole[0].name);
		}
		else this.roles[accountId] = this.cacheRoles;
	}

	onUserAccountChanges(): void
	{
		this.userAccounts.valueChanges.subscribe(onValueChange.bind(this));
		function onValueChange(this: AddEmployeeComponent, formValues) : void
		{
			let mockFormValues    = cloneDeep(formValues);
			mockFormValues.forEach((object, index) => 
			{
				delete object['reportings'];
				if(!Object.values(object).some((x : any) => x == null || x.length == 0))
				{
					if(!isEqual(object, this.currentMock[index])) {
						this.employeeService.getReportingTo(object).subscribe(response => this.reporting[object.accountId] = response);
						this.currentMock = cloneDeep(mockFormValues);
					}
				}
				else if (!!formValues[index].reportings) {
					this.reporting[object.accountId] = [];
					this.userAccounts.controls[index].patchValue({ 'reportings' : null });
				}
			});
		}
	}

	addEmployee() : void
	{
		this.submitted = true;
		if (this.addEmployeeForm.invalid || !this.userAccounts.controls.length) return;

		let data = { ...this.addEmployeeForm.value };
		data.userAccounts.forEach(account => account.reportings = this.reporting[account.accountId].find(item => item.userId == account.reportings));

		this.employeeService.addEmployee(data).subscribe(onSuccess.bind(this));
		function onSuccess(this : AddEmployeeComponent, response : any) : void
		{
			this.submitted = false;
			this.event.emit({success : true});
			this.activeModal.hide();
		}
	}

	updateEmployee() : void
	{
		this.submitted = true;
		if (this.addEmployeeForm.invalid || !this.userAccounts.controls.length) return;

		let data = { ...this.addEmployeeForm.value };
		data.userAccounts.forEach(account => account.reportings = this.reporting[account.accountId].find(item => item.userId == account.reportings));

		this.employeeService.updateEmployee(data).subscribe(onSuccess.bind(this));
		function onSuccess(this : AddEmployeeComponent, response : any) : void
		{
			this.submitted = false;
			this.event.emit({success : true});
			this.activeModal.hide();
		}
	}
}
