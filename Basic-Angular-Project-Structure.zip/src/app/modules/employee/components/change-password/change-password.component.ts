import { Component, EventEmitter, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { IconDefinition, faTimes } from '@fortawesome/pro-light-svg-icons';
import { CValidators } from '../../../../helpers/password-validators';

import { BsModalRef } from 'ngx-bootstrap/modal';
import { ActiveUserService } from 'src/app/services/active-user.service';
import { AuthService } from 'src/app/modules/user/services/auth.service';

import { ActiveUser } from 'src/app/models/active-user.model';
import { Employee } from 'src/app/models/employee.model';
@Component({
	selector    : 'change-password',
	templateUrl : './change-password.component.html',
	styleUrls   : ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit
{
	public event = new EventEmitter();

	employee    : Employee;
	fa          : Record<string, IconDefinition>;
	user        : ActiveUser;
	form        : FormGroup;
	isSubmitted : boolean;
	pattern     : any;

	constructor(
		public  activeModal       : BsModalRef,
		private activeUserService : ActiveUserService,
		private formBuilder       : FormBuilder,
		private authService       : AuthService
	) 
	{
		this.pattern     =  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\s]).*$/;
		this.user        = this.activeUserService.getUser();
		this.fa          = { faTimes };
		this.isSubmitted = false;
	}

	ngOnInit() : void
	{
		let { required, minLength, pattern }    = Validators;
		let { shouldNotBeName, matchPasswords } = CValidators;

		this.form = this.formBuilder.group({
			email           : this.employee.email,
			currentPassword : [null, required],
			newPassword     : [null, [required, minLength(8), pattern(this.pattern), shouldNotBeName(this.user) ]],
			confirmPassword : [null, required],
		},
		{
			validator : matchPasswords
		});
	}
	
	changePassword() : void
	{
		this.isSubmitted = true;
		if(this.form.invalid) return;

		this.authService.changePassword(this.form.value).subscribe(onSuccess.bind(this));
		function onSuccess(this : ChangePasswordComponent, data) : void
		{
			this.event.emit({success : true});
			this.activeModal.hide();
		}
	}

}
