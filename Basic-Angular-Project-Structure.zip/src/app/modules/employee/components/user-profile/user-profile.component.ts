import { Component, OnInit } from '@angular/core';

import { ActivatedRoute } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ActiveUserService } from 'src/app/services/active-user.service';
import { EmployeeService } from 'src/app/services/employee.service';
import { UserService } from 'src/app/services/user.service';
import { OrgStructureService } from 'src/app/services/org-structure.service';
import { AccountService } from 'src/app/services/account.service';

import { ChangePasswordComponent } from '../change-password/change-password.component';
import { EditProfileComponent } from '../edit-profile/edit-profile.component';
import { forkJoin } from 'rxjs';
import { cloneDeep } from 'lodash';

import { ActiveUser } from 'src/app/models/active-user.model';
import { Employee } from 'src/app/models/employee.model';
import { AccountDetails } from 'src/app/models/acount-details.model';

import { IconDefinition, faEnvelope, faPhone, faCaretDown, faCaretRight } from '@fortawesome/pro-solid-svg-icons';
import { faCube, faAddressBook, faSitemap, faUsers } from '@fortawesome/pro-regular-svg-icons';
import { faKey, faPencil } from '@fortawesome/pro-light-svg-icons';
import { FormControl } from '@angular/forms';
import { User } from 'src/app/models/User.model';

@Component({
	selector    : 'user-profile',
	templateUrl : './user-profile.component.html',
	styleUrls   : ['./user-profile.component.scss']
})
export class UserProfileComponent implements OnInit
{
	employeeDetails     : Employee;
	activeUser          : ActiveUser;
	fa                  : Record<string, IconDefinition>;
	accounts            : AccountDetails[];
	roleLogs            : any;
	user                : any;
	subordinates        : any;
	reportingMembers    : any;
	reportingHistory    : any;
	hasReportingHistory : boolean;
	hasRoleLogs         : boolean;
	accountControl      : FormControl;

	constructor(
		private route               : ActivatedRoute,
		private modalService        : BsModalService,
		private accountService      : AccountService,
		private employeeService     : EmployeeService,
		private userService         : UserService,
		private activeUserService   : ActiveUserService,
		private orgStructureService : OrgStructureService
	) {
		this.activeUser     = this.activeUserService.getUser();
		this.fa             = { faEnvelope, faPhone, faKey, faPencil, faCaretDown, faCaretRight, faCube, faAddressBook, faSitemap, faUsers };
		this.accountControl = new FormControl();
	}

	ngOnInit() : void
	{
		this.user = this.route.snapshot.queryParams;
		forkJoin({
			roleLogs         : this.userService.getUserRoleLogs(this.user.userId),
			employeeDetails  : this.employeeService.getEmployee(this.user.userId),
			accounts         : this.accountService.getUserAccounts(this.user.userId),
			reportingHistory : this.orgStructureService.getReportingHistory(this.user.userId)
		}).subscribe(onSuccess.bind(this));
		function onSuccess(this : UserProfileComponent, data) : void
		{
			Object.assign(this, data);

			this.hasReportingHistory     = !!Object.keys(this.reportingHistory).length;
			this.hasRoleLogs             = !!Object.keys(this.roleLogs).length;
			this.employeeDetails.isAdmin = this.employeeDetails.userAccounts.some(item => item.roleName == 'Admin');
		}

		this.onAccountChange();
	}

	private onAccountChange() : void
	{
		this.accountControl.valueChanges.subscribe(onSuccess.bind(this));
		function onSuccess(this : UserProfileComponent, account : AccountDetails) : void
		{
			this.orgStructureService.traverseDown(this.user.userId, account.accountId).subscribe(response => {
				this.subordinates = !!response.length ? response : null;
			});
		}
	}

	changePassword() : void
	{
		var initialState = {
			employee : cloneDeep(this.employeeDetails)
		}
		let modalRef = this.modalService.show(ChangePasswordComponent , { initialState, class: 'modal-sm' } );
		modalRef.content.event.subscribe(onValueEmit.bind(this));
		function onValueEmit(this : UserProfileComponent, data : any) : void
		{
			if(data.success) this.ngOnInit();
		}
	}

	editProfile() : void
	{
		var initialState = {
			employee : cloneDeep(this.employeeDetails)
		}
		let modalRef = this.modalService.show(EditProfileComponent , {initialState});
		modalRef.content.event.subscribe(onValueEmit.bind(this));
		function onValueEmit(this : UserProfileComponent, data : any) : void
		{
			if(data.success) this.ngOnInit();
		}
	}

}
