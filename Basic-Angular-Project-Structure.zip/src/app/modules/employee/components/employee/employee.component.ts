import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';

import { forkJoin, Observable } from 'rxjs';
import { cloneDeep, isEqual } from 'lodash';
import { debounceTime, filter, map, switchMap } from 'rxjs/operators';
import { IconDefinition, faSearch, faUser, faUserSlash, faUserUnlock, faPlusCircle, faMinusCircle, faBan, faPencilAlt, faExternalLinkAlt, faReply } from '@fortawesome/pro-regular-svg-icons';
import { faPlus } from '@fortawesome/pro-solid-svg-icons';

import { EmployeeService } from 'src/app/services/employee.service';
import { ActiveUserService } from 'src/app/services/active-user.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { CommonService } from 'src/app/services/common.service';
import { Router } from '@angular/router';

import { Employee, EmployeeFilter, EmployeeList } from 'src/app/models/employee.model';
import { ActiveUser } from 'src/app/models/active-user.model';
import { AccountService } from 'src/app/services/account.service';
import { AccountDetails, RoleDetails } from 'src/app/models/acount-details.model';
import { AddEmployeeComponent } from '../add-employee/add-employee.component';
import { DeactivateEmployeeComponent } from '../deactivate-employee/deactivate-employee.component';
import { GrantAccessComponent } from 'src/app/modules/shared/components/grant-access/grant-access.component';
@Component({
	selector    : 'employee',
	templateUrl : './employee.component.html',
	styleUrls   : ['./employee.component.scss']
})
export class EmployeeComponent implements OnInit
{
	employeeFilterForm : FormGroup;
	searchControl      : FormControl;
	fa                 : Record<string, IconDefinition>;
	employeeList       : EmployeeList;
	accounts           : AccountDetails[];
	roles              : RoleDetails[];
	activeUser         : ActiveUser;
	currentFilters     : EmployeeFilter;
	reloadSame         : boolean;
	pageSize           : number;

	constructor (
		private formBuilder       : FormBuilder,
		private activeUserService : ActiveUserService,
		private employeeService   : EmployeeService,
		private accountService    : AccountService,
		private modalService      : BsModalService,
		private commonService     : CommonService,
		private router            : Router
	) 
	{
		this.currentFilters = {};
		this.pageSize       = 15;
		this.searchControl  = new FormControl();
		this.fa             = { faSearch, faUser, faUserSlash, faUserUnlock, faPlusCircle, faMinusCircle, faBan, faPencilAlt, faPlus, faExternalLinkAlt, faReply };
	}

	ngOnInit() : void
	{
		this.activeUser         = this.activeUserService.getUser();
		this.employeeFilterForm = this.formBuilder.group({
			pageNumber      : 1,
			numberOfRecords : this.pageSize,
			onlyActive      : null,
			isDescending    : true,
			orderBy         : null,
			filterBy        : null,
			searchText      : null,
			accountId       : null,
			roleId          : null,
		});

		this.getData();
		this.onEmployeeFilterFormChange();
		this.employeeFilterForm.controls.onlyActive.setValue(true);
		this.searchControl.valueChanges.pipe(debounceTime(500)).subscribe(value => this.employeeFilterForm.controls.searchText.setValue(value));
	}

	private getData() : void
	{
		forkJoin([
			this.accountService.getAccountDetails(this.activeUser.userId),
			this.accountService.getRoleDetails()
		]).subscribe(onSuccess.bind(this));
		function onSuccess(this : EmployeeComponent, response : any) : void
		{
			this.accounts = response[0];
			this.roles    = response[1];
		}
	}

	onEmployeeFilterFormChange() : void
	{
		this.employeeFilterForm.valueChanges
			.pipe(map(resetPaging.bind(this)), filter(checkIfChanged.bind(this)), switchMap(getEmployees.bind(this)))
			.subscribe(data => {
				data.result.forEach(user => user.isAdmin = user.userAccounts.some(role => role.roleName == 'Admin'));
				this.employeeList = data;
				this.reloadSame   = false;
			});

		function resetPaging(this : EmployeeComponent, filters : EmployeeFilter) : EmployeeFilter
		{
			if(filters.pageNumber == this.currentFilters.pageNumber && !this.reloadSame)
			{
				filters.pageNumber = 1;
				this.employeeFilterForm.controls.pageNumber.setValue(1, {emitEvent : false});
			}

			return filters;
		}

		function checkIfChanged(this : EmployeeComponent, filters : EmployeeFilter) : boolean
		{
			return this.reloadSame || !isEqual(filters, this.currentFilters);
		}

		function getEmployees(this : EmployeeComponent, filters : EmployeeFilter) : Observable<EmployeeList>
		{
			this.currentFilters = filters;
			return this.employeeService.getAllEmployees(filters);
		}
	}

	openAddEmployee() : void
	{
		let modalRef = this.modalService.show(AddEmployeeComponent, {class: 'modal-xl'});
		modalRef.content.event.subscribe(onValueEmit.bind(this));
		function onValueEmit(this : EmployeeComponent, data : any) : void
		{
			this.reloadSame = true;
			if(data.success) this.ngOnInit();
		}
	}

	editEmployee(employee : Employee) : void
	{
		var initialState = {
			employee : cloneDeep(employee)
		}
		let modalRef = this.modalService.show(AddEmployeeComponent, {initialState, class: 'modal-xl'})
		modalRef.content.event.subscribe(onValueEmit.bind(this));
		function onValueEmit(this : EmployeeComponent, data : any) : void
		{
			this.reloadSame = true;
			if(data.success) this.ngOnInit();
		}
	}

	deactivateEmployee(employee : Employee) : void
	{
		var initialState = {
			employee : cloneDeep(employee)
		}
		let modalRef = this.modalService.show(DeactivateEmployeeComponent, { initialState });
		modalRef.content.event.subscribe(onValueEmit.bind(this));
		function onValueEmit(this : EmployeeComponent, data : any) : void
		{
			this.reloadSame = true;
			if(data.success) this.ngOnInit();
		}
	}

	grantAccess(employee : Employee) : void
	{
		var initialState = {
			employee : cloneDeep(employee)
		}
		let modalRef = this.modalService.show( GrantAccessComponent, { initialState} );
		modalRef.content.event.subscribe(onSuccess.bind(this));
		function onSuccess(this : EmployeeComponent, response) : void 
		{
			this.reloadSame    = true;
			this.employeeFilterForm.updateValueAndValidity();
		}
	}

	exportEmployeesToExcel() : void
	{
		this.employeeService.exportEmployeesToExcel(this.currentFilters).subscribe(onSuccess.bind(this))
		function onSuccess(this : EmployeeComponent, response) : void
		{
			this.commonService.downloadBlob(response, 'Employees.xlsx');
		}
	}

	userProfile(user : Employee) : void
	{
		this.router.navigate(['user-profile'], {queryParams : { userId : user.userId }})
	}

	resendInvite(employee) {
		this.employeeService.resendInvite(employee.email).subscribe();
	}

}
