import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppLayoutComponent } from '../shared/components/app-layout/app-layout.component';
import { AuthGuardService } from '../../services/auth-guard.service';
import { TemplateArrangementComponent } from './components/template-arrangement/template-arrangement.component';
import { ExternalAccessComponent } from './components/external-access/external-access.component';
import { OrgStructureComponent } from './components/org-structure/org-structure.component';
import { AddNewBandRoleComponent } from './components/add-new-band-role/add-new-band-role.component';
import { TemplateListComponent } from './components/template-list/template-list.component';



let routes : Routes = 
[
	{
		path             : '',
		component        : AppLayoutComponent,
		canActivateChild : [AuthGuardService],
		children         : 
		[
			{
				path      : 'template-list',
				component : TemplateListComponent,
				data      : {title : 'Template List', pageId : 'template_list'}
			},
			{
				path      : 'template-config',
				component : TemplateArrangementComponent,
				data      : {title : 'Template Config', pageId : 'template_config'}
			},
			{
				path      : 'external-access',
				component : ExternalAccessComponent,
				data      : {title : 'External Access', pageId : 'external_access'}
			},
			{
				path      : 'org-structure',
				component : OrgStructureComponent,
				data      : {title : 'Organization Structure', pageId : 'org_structure'}
			}
		]
	}
];

@NgModule({
	imports : [RouterModule.forChild(routes)],
	exports : [RouterModule]
})
export class ConfigRoutingModule { }
