import { Component, OnInit } from '@angular/core';

import { IconDefinition, faTimes } from '@fortawesome/pro-solid-svg-icons';

import { BsModalRef } from 'ngx-bootstrap/modal';

import { AccessLogs } from 'src/app/models/external-access.model';
import { ExternalAccessService } from 'src/app/services/external-access.service';

@Component({
	selector    : 'access-logs',
	templateUrl : './access-logs.component.html',
	styleUrls   : ['./access-logs.component.scss']
})
export class AccessLogsComponent implements OnInit
{

	fa            : Record<string, IconDefinition>;
	userLog       : AccessLogs;
	accessedLogs  : any;
	viewAccessLog : boolean;
	today         : Date;

	constructor(
		public  activeModal           : BsModalRef,
		private externalAccessService : ExternalAccessService
	) {
		this.fa    = { faTimes };
		this.today = new Date();
	}

	ngOnInit(): void 
	{
		let data = {
			userId    : this.userLog.userId,
			startDate : this.userLog.startDate,
			endDate   : this.userLog.endDate
		}
		this.externalAccessService.getExternalAccessLogByUser(data).subscribe(onSuccess.bind(this));
		function onSuccess(this : AccessLogsComponent, response) : void
		{
			this.accessedLogs  = response;
			this.viewAccessLog = true;
		}
	}

}
