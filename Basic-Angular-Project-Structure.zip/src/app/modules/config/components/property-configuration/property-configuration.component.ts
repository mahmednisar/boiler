import { Component, Input, OnChanges } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { IconDefinition, faPlus, faMinus } from '@fortawesome/pro-solid-svg-icons';

import { findIndex, groupBy, isEqual, reject } from 'lodash';
import { CustomField } from 'src/app/models/MasterTemplateProperties.model';
import { TemplatePropertyValidation } from 'src/app/models/TemplatePropertyValidation.model';

@Component({
	selector    : 'property-configuration',
	templateUrl : './property-configuration.component.html',
	styleUrls   : ['./property-configuration.component.scss']
})
export class PropertyConfigurationComponent implements OnChanges
{
	@Input() selectedComponent : CustomField;
	@Input() components        : CustomField[];
	@Input() validations       : TemplatePropertyValidation[];
	@Input() configs           : any;
	@Input() customFields      : CustomField[];
	@Input() formTabIndex      : number;

	fa                         : Record<string, IconDefinition>;
	typeControl                : FormControl;
	defaultValue               : FormControl;
	configValue                : FormControl;
	parentControl              : FormControl;

	configChoices              : any[];
	cascadingParents           : CustomField[];
	parentChilds               : CustomField[];
	childs                     : Record<string, CustomField[]>;
	childChoices               : any;

	constructor()
	{
		this.fa               = { faPlus, faMinus };
		this.typeControl      = new FormControl();
		this.defaultValue     = new FormControl();
		this.configValue      = new FormControl();
		this.parentControl    = new FormControl(null, Validators.required);

		this.configChoices    = [
			{
				'name'     : 'Title',
				'code'     : 1,
				'disabled' : false
			},
			{
				'name'     : 'Subtitle',
				'code'     : 6,
				'disabled' : false
			},
			{
				'name'     : 'Subtitle 2',
				'code'     : 9,
				'disabled' : false
			}
		]
	}

	ngOnChanges() : void
	{
		this.parentChilds     = [];
		this.childChoices     = [];
		this.cascadingParents = [];
		this.parentControl.reset();

		this.typeControl.setValue(this.selectedComponent.type);
		this.configValue.setValue(this.selectedComponent.useForTaskPropertyRefId);
		this.defaultValue.setValue(this.selectedComponent.value);

		this.selectedComponent.hasCascading = this.selectedComponent.validations.some(validation => validation.validationType == 'cascadingDropdown');

		Object.keys(this.customFields).forEach(key => {
			this.customFields[key].filter(item => !!item.useForTaskPropertyRefId).forEach(value => {
				this.configChoices = this.configChoices.map(item => {
					item.disabled = item.disabled || item.code == value.useForTaskPropertyRefId;
					return item;
				});
			});
			this.customFields[key].forEach(item => {
				if(item.type == 'select' && !isEqual(item, this.selectedComponent)) this.cascadingParents.push(item);
			});
		});

		this.onConfigChanged();
		this.watchDefaultValue();
		this.onParentControlChanged();

		if(this.selectedComponent.hasChildEntity && !this.selectedComponent.childs.length) this.addChildEntities(true);
		if(!this.selectedComponent.validationsList) this.validations = this.components.find(comp => comp.type == this.selectedComponent.type).validationsList;
		if(this.selectedComponent.hasCascading) this.addCascadingEntities();
	}

	addChildEntities(isDefault ?: boolean) : void
	{
		this.selectedComponent.childs.push(this.addChildObject(isDefault) as CustomField);
	}

	addChildObject(isDefault ?: boolean) : CustomField
	{
		return {
			displayName        : isDefault ? 'Choice 1' : null,
			type               : "string",
			controlType        : "string",
			propertyType       : "string",
			newProperty        : true
		} as CustomField
	}

	removeChildEntities(index : number) : void
	{
		this.selectedComponent.childs.splice(index, 1);
	}

	validationChecked(validation : TemplatePropertyValidation, componentValidation : TemplatePropertyValidation[]) : boolean
	{
		return componentValidation.some(valid => valid.validationType == validation.validationType);
	}

	valueChecked(validation : TemplatePropertyValidation, value : boolean) : void
	{
		if(value) this.selectedComponent.validations.push(this.addValidationObject(validation));
		else {
			let indexToRemove = findIndex(this.selectedComponent.validations, valid => valid.validationType == validation.validationType);
			this.selectedComponent.validations.splice(indexToRemove, 1);
		}
		this.selectedComponent.hasCascading = this.selectedComponent.validations.some(validation => validation.validationType == 'cascadingDropdown');
	}

	addValidationObject(selected : TemplatePropertyValidation) : TemplatePropertyValidation
	{
		return {
			displayName           : selected.displayName,
			validationType        : selected.validationType,
			validationCondition   : null,
			validationValue       : null,
		} as TemplatePropertyValidation
	}

	setValidationValue(value: string, type: string) : void
	{
		this.selectedComponent.validations.map(item => item.validationType == type ? item.validationValue = value : null);
	}

	watchDefaultValue() : void
	{
		this.defaultValue.valueChanges.subscribe(value => this.selectedComponent.value = value);
	}

	onConfigChanged() : void
	{
		this.configValue.valueChanges.subscribe(onValueChanged.bind(this));
		function onValueChanged(this : PropertyConfigurationComponent, value) : void
		{
			if(!!value) {
				this.selectedComponent.useForTaskPropertyRefId = value;
				this.configChoices = this.configChoices.map(item => {
					item.disabled = item.disabled || item.code == value;
					return item;
				});
			}
			else return;
		}
	}

	private addCascadingEntities() : void
	{
		let ValidationProperty = this.selectedComponent.validations.find(validation => validation.validationType == 'cascadingDropdown');
		let parentValidation   = this.cascadingParents.find(item => (item.newProperty ? item.displayName : item.propertyName) == ValidationProperty.dependentPropertyName);

		this.parentControl.setValue(parentValidation.displayName);
	}

	private onParentControlChanged() : void
	{
		this.parentControl.valueChanges.subscribe(onValueChange.bind(this));
		function onValueChange(this : PropertyConfigurationComponent, value) : void
		{
			if(!!value) {
				let parent = this.cascadingParents.find(item => item.displayName == value);
				if(!!parent) {
					this.parentChilds             = parent.childs;
					this.selectedComponent.childs = reject(this.selectedComponent.childs, item => !item.filterPropertyName);
					this.selectedComponent.validations.find(validation => validation.validationType == 'cascadingDropdown').dependentPropertyName = parent.newProperty ? parent.displayName : parent.propertyName;

					this.parentChilds.forEach(item => this.childChoices[item.displayName] = []);
				}
			}
			else return;
		}
	}

	onCascadeChildAdd(value ?: string, parent ?: any) : void
	{
		if(!!value) {
			this.selectedComponent.childs.push(this.addChildChoice(value, parent.newProperty ? parent.displayName : parent.propertyName) as CustomField);
			this.ngOnChanges();
		}
	}

	private addChildChoice(value ?: string, parent ?: string) : CustomField
	{
		return {
			displayName        : value,
			filterPropertyName : parent,
			type               : "string",
			controlType        : "string",
			propertyType       : "string",
			newProperty        : true
		} as CustomField
	}
}
