import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { AccessLevels, Bands, Roles } from 'src/app/models/org-structure.model';

import { OrgStructureService } from 'src/app/services/org-structure.service';

@Component({
	selector    : 'add-entity',
	templateUrl : './add-entity.component.html',
	styleUrls   : ['./add-entity.component.scss']
})
export class AddEntityComponent implements OnInit 
{
	@Input() bands        : Bands[];
	@Input() roles        : Roles[];
	@Input() selectedBand : Bands;
	@Input() accessLevels : AccessLevels;
	@Output() event       = new EventEmitter();
	@Output() cancel      = new EventEmitter();

	addEntityForm   : FormGroup;
	parentBandList  : Bands[];
	parentBandRoles : Roles[];

	constructor(
		private formBuilder         : FormBuilder,
		private orgStructureService : OrgStructureService
	)
	{ 
		this.parentBandList  = [];
		this.parentBandRoles = [];
		this.addEntityForm   = this.formBuilder.group({
			parentBandId : [null, Validators.required],
			parentRoleId : [null, Validators.required],
			name         : [null, Validators.required],
			accessLevel  : [null, Validators.required],
			bandId       : [null, Validators.required],
		});
	}

	ngOnInit(): void
	{
		this.getParentBands(this.selectedBand.parentBandId ? this.selectedBand.parentBandId.toLocaleLowerCase() : null);
		this.addEntityForm.controls.accessLevel.setValue(this.selectedBand.accessLevel);
		this.addEntityForm.controls.bandId.setValue(this.selectedBand.id);
	}

	private getParentBands (parentNodeId) {
		var parentNode = this.bands.find(band => band.id == parentNodeId);

		if (parentNode)
		{
			this.parentBandList.push(parentNode);
			if(parentNode.parentBandId) this.getParentBands(parentNode.parentBandId.toLocaleLowerCase());
		}
	}

	getParentRoles(parentBand : Bands) : void
	{
		this.parentBandRoles = this.roles.filter(entity => entity.bandId == parentBand.id);
	}

	addEntity() : void
	{
		if (this.addEntityForm.invalid) return;

		this.orgStructureService.addRole({...this.addEntityForm.value}).subscribe(onSuccess.bind(this));
		function onSuccess(this : AddEntityComponent, response) : void
		{
			this.event.emit({success : true});
		}
	}

}
