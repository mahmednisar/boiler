import { Component, EventEmitter, Input, OnChanges, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { forkJoin } from 'rxjs';

import { findIndex, groupBy } from 'lodash';
import { IconDefinition, faPlus, faMinus } from '@fortawesome/pro-regular-svg-icons';

import { MasterTemplate } from 'src/app/models/MasterTemplate.model';
import { ConfigModel } from 'src/app/models/TaskStatus.model';

import { AccountService } from 'src/app/services/account.service';
import { TemplateService } from 'src/app/services/template.service';

@Component({
	selector    : 'template-basic-config',
	templateUrl : './template-basic-config.component.html',
	styleUrls   : ['./template-basic-config.component.scss']
})
export class TemplateBasicConfigComponent implements OnChanges
{
	@Output() onSave       = new EventEmitter();
	@Input() template      : MasterTemplate;
	@Input() selectedTabId : number;

	fa                : Record<string, IconDefinition>;
	templateConfigs   : ConfigModel[];
	templateBasicForm : FormGroup;
	timezones         : any;
	groupedConfigs    : Record<string, ConfigModel[]>;
	configurations    : ConfigModel[];


	constructor(
		private formBuilder     : FormBuilder,
		private templateService : TemplateService,
		private accountService  : AccountService
	) {
		this.fa                = { faPlus, faMinus };
		this.templateBasicForm = this.formBuilder.group({
			templateId          : null,
			templateName        : [null, Validators.required],
			primaryEntityName   : [null, Validators.required],
			secondaryEntityName : [null, Validators.required],
			templateKey         : [null, Validators.required],
			description         : null,
			timezone            : null
		});
	}

	ngOnChanges() : void
	{
		if(this.selectedTabId == 0)
		{
			this.templateBasicForm.patchValue({...this.template});
			this.templateBasicForm.controls.timezone.setValue(this.template.timeZones[0].timeZone);
			this.configurations = [...this.template.configurations];

			forkJoin({
				templateConfigs : this.templateService.getMasterConfigurations(false),
				timezones       : this.accountService.getTimeZoneMaster()
			}).subscribe(onSuccess.bind(this));
			function onSuccess(this: TemplateBasicConfigComponent, response ) : void
			{
				Object.assign(this, response);
				this.groupedConfigs  = groupBy(this.templateConfigs, 'groupName');
			}
		}
	}

	examineConfigs(code) : boolean
	{
		return this.template.configurations.some(config => config.configCode == code);
	}

	configChecked(config : ConfigModel, value : boolean) : void
	{
		if(value) this.configurations.push(config);
		else {
			let indexToRemove = findIndex(this.configurations, configuration => configuration.configCode == config.configCode);
			this.configurations.splice(indexToRemove, 1);
		}
	}

	saveConfiguration() : void
	{
		this.templateService.updateTemplate({...this.templateBasicForm.value, configurations : [...this.configurations], updateBasicFieldConfigs : false}).subscribe(() => this.onSave.emit(true));
	}

}
