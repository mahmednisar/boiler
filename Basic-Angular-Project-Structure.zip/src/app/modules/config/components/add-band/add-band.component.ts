import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { OrgStructureService } from 'src/app/services/org-structure.service';

import { IconDefinition } from '@fortawesome/pro-solid-svg-icons';
import { last } from 'lodash';

import { AccessLevels, Bands } from 'src/app/models/org-structure.model';

@Component({
	selector    : 'add-band',
	templateUrl : './add-band.component.html',
	styleUrls   : ['./add-band.component.scss']
})
export class AddBandComponent implements OnInit
{
	@Input() bands        : Bands[];
	@Input() accessLevels : AccessLevels[];
	@Output() event       = new EventEmitter();
	@Output() cancel      = new EventEmitter();

	fa           : Record<string, IconDefinition>;
	addBandForm  : FormGroup;
	color        : string;

	constructor(
		private formBuilder         : FormBuilder,
		private orgStructureService : OrgStructureService
	) {
		this.addBandForm = this.formBuilder.group({
			parentBandId : [null, Validators.required],
			color        : [null, Validators.required],
			name         : [null, Validators.required],
			accessLevel  : [null, Validators.required],
		})
	}

	ngOnInit(): void 
	{
		var parentBand = last(this.bands);
		this.color     = '#FFF';
		this.addBandForm.controls.color.setValue(this.color);
		this.addBandForm.controls.parentBandId.setValue((parentBand.parentBandId).toLowerCase());
	}

	onColorChanged(color : string) : void
	{
		this.addBandForm.controls.color.setValue(color, {emitEvent : false});
		this.color = color;
	}

	addBand() : void
	{
		if (this.addBandForm.invalid) return;

		this.orgStructureService.addBand({...this.addBandForm.value}).subscribe(onSuccess.bind(this));
		function onSuccess(this : AddBandComponent, response) : void
		{
			this.event.emit({success : true});
		}
	}
}
