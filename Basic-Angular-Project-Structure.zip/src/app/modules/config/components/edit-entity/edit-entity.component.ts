import { Component, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { IconDefinition, faTimes } from '@fortawesome/pro-light-svg-icons';
import { OrgStructureService } from 'src/app/services/org-structure.service';

import { BsModalRef } from 'ngx-bootstrap/modal';
import { AccessLevels, Roles } from 'src/app/models/org-structure.model';

@Component({
	selector    : 'edit-entity',
	templateUrl : './edit-entity.component.html',
	styleUrls   : ['./edit-entity.component.scss']
})
export class EditEntityComponent
{
	public event = new EventEmitter();

	role           : Roles;
	accessLevels   : AccessLevels[];
	fa             : Record<string, IconDefinition>;
	editEntityForm : FormGroup;

	constructor(
		public  activeModal         : BsModalRef,
		private orgStructureService : OrgStructureService,
		private formBuilder         : FormBuilder
	) {
		this.fa           = { faTimes };
		this.editEntityForm = this.formBuilder.group({
			id          : [null, Validators.required],
			bandId      : [null, Validators.required],
			name        : [null, Validators.required],
			accessLevel : [null, Validators.required]
		});
	}

	ngOnInit() : void
	{
		this.editEntityForm.patchValue({...this.role});
	}

	updateEntity() : void
	{
		if (this.editEntityForm.invalid) return;

		this.orgStructureService.updateRole(this.editEntityForm.value).subscribe(onEntityUpdated.bind(this))
		function onEntityUpdated(this : EditEntityComponent, response) : void
		{
			this.activeModal.hide();
			this.event.emit(true);
		}
	}
}
