import { Component, EventEmitter, Input, OnChanges, Output } from '@angular/core';
import { forkJoin, of } from 'rxjs';
import { TemplateService } from 'src/app/services/template.service';

import { IconDefinition, faPlus, faMinus } from '@fortawesome/pro-regular-svg-icons';

import { MasterTemplate } from 'src/app/models/MasterTemplate.model';
import { ConfigModel } from 'src/app/models/TaskStatus.model';
import { MasterTemplateProperties } from 'src/app/models/MasterTemplateProperties.model';
import { findIndex, groupBy } from 'lodash';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
	selector    : 'basic-fields-config',
	templateUrl : './basic-fields-config.component.html',
	styleUrls   : ['./basic-fields-config.component.scss']
})
export class BasicFieldsConfigComponent implements OnChanges
{
	@Output() onSave = new EventEmitter();
	@Input() template      : MasterTemplate;
	@Input() selectedTabId : number;

	configs           : ConfigModel[];
	props             : MasterTemplateProperties;
	choices           : any;
	titledropdown     : boolean;
	subtitledropdown  : boolean;
	subtitle2dropdown : boolean;
	fa                : Record<string, IconDefinition>;
	groupedConfigs    : any;
	templateBasicForm : FormGroup;
	configurations    : ConfigModel[];

	constructor(
		private formBuilder     : FormBuilder,
		private templateService : TemplateService
	) {
		this.fa = { faPlus, faMinus };
		this.templateBasicForm = this.formBuilder.group({
			templateId          : null,
			templateName        : null,
			primaryEntityName   : null,
			secondaryEntityName : null,
			templateKey         : null,
			description         : null,
			timezone            : null
		});
	}

	ngOnChanges() : void
	{
		if(this.selectedTabId == 1)
		{
			this.titledropdown     = false;
			this.subtitledropdown  = false;
			this.subtitle2dropdown = false;
			this.choices           = {
				titledropdown     : [],
				subtitledropdown  : [],
				subtitle2dropdown : []
			};

			this.templateBasicForm.patchValue({...this.template});
			this.templateBasicForm.controls.timezone.setValue(this.template.timeZones[0].timeZone);
			this.configurations = [...this.template.configurations];

			forkJoin({
				configs : this.templateService.getMasterConfigurations(true),
				props   : this.templateService.getTemplateDetails(this.template.templateId)
			}).subscribe(onSuccess.bind(this));
			function onSuccess(this : BasicFieldsConfigComponent, response) : void
			{
				Object.assign(this, response);
				this.configs.filter(config => config.hasChoices).forEach(item => {
					let temp = this.template.configurations.find(i => i.configCode == item.configCode);
					if(!!temp) {
						item.choices = [...temp.choices];
						item.choices.forEach(child => this.addChoices(temp.configCode, child))
						this[item.configCode] = !this[item.configCode];
					}
				})
				this.groupedConfigs = groupBy(this.configs, 'groupName');
			}
		}
	}

	addChoices(code : string, value ?: any) : void
	{
		this.choices[code].push(this.addChildObject(value ? value : null));
	}

	addChildObject(value : any) : any
	{
		return {
			templatePropertyId : !value ? 0        : value.templatePropertyId,
			displayName        : !value ? 'Choice' : value.displayName,
			controlType        : "string",
			propertyType       : "string",
			type               : "string",
			isbasicproperty    : true,
			newProperty        : !value ? true     : false
		}
	}

	removeChoices(value : string, index : number) : void
	{
		this.choices[value].splice(index, 1);
	}

	examineConfigs(code) : boolean
	{
		return this.template.configurations.some(config => config.configCode == code);
	}

	configChecked(config : ConfigModel, value : boolean) : void
	{
		if(value) this.configurations.push(config);
		else {
			let indexToRemove = findIndex(this.configurations, configuration => configuration.configCode == config.configCode);
			this.configurations.splice(indexToRemove, 1);
		}

		if(config.hasChoices) {
			this        [config.configCode] = !this[config.configCode];
			this.choices[config.configCode] = [];
			this.addChoices(config.configCode);
		}
	}

	saveBasicFields() : void
	{
		this.configs.filter(config => config.hasChoices).forEach(item => {
			let temp = this.configurations.find(i => i.configCode == item.configCode);
			if(!!temp) {
				temp.choices = this.choices[item.configCode];
				temp.choices.forEach((item, index) => item.sortOrder = (index + 1) * 10);
			}
		});
		this.templateService.updateTemplate({...this.templateBasicForm.value, configurations : [...this.configurations], updateBasicFieldConfigs : true}).subscribe(() => {
			this.titledropdown = this.subtitledropdown = this.subtitle2dropdown = false;
			this.choices       = {
				titledropdown     : [],
				subtitledropdown  : [],
				subtitle2dropdown : []
			};
			this.onSave.emit(true);
		});
	}

}
