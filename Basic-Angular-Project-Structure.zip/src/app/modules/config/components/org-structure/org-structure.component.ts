import { Component, OnInit } from '@angular/core';
import { forkJoin } from 'rxjs';

import { IconDefinition, faPencilAlt, faPlus, faSitemap, faTh } from '@fortawesome/pro-light-svg-icons';
import { faInfoCircle } from '@fortawesome/pro-regular-svg-icons';

import { BsModalService } from 'ngx-bootstrap/modal';
import { OrgStructureService } from 'src/app/services/org-structure.service';

import { EditBandComponent } from '../edit-band/edit-band.component';
import { EditEntityComponent } from '../edit-entity/edit-entity.component';
import { cloneDeep, sortBy } from 'lodash';

import { AccessLevels, Bands, Roles } from 'src/app/models/org-structure.model';
import { Router } from '@angular/router';
import { map } from 'rxjs/operators';
import { AddEntityComponent } from '../add-entity/add-entity.component';
@Component({
	selector    : 'org-structure',
	templateUrl : './org-structure.component.html',
	styleUrls   : ['./org-structure.component.scss']
})
export class OrgStructureComponent implements OnInit
{
	fa           : Record<string, IconDefinition>;
	bands        : Bands[];
	roles        : Roles[];
	accessLevels : AccessLevels[];
	chartData    : any;
	showTree     : boolean;

	constructor(
		private modalService        : BsModalService,
		private orgStructureService : OrgStructureService,
		private router              : Router
	) {
		this.fa = { faPencilAlt, faPlus, faSitemap, faTh, faInfoCircle };
	}

	ngOnInit() : void
	{
		forkJoin({
			bands        : this.orgStructureService.getBands(),
			roles        : this.orgStructureService.getRoles(),
			accessLevels : this.orgStructureService.getAccessLevels()
		}).pipe(map(manipulateBands.bind(this)))
		.subscribe(onSuccess.bind(this));

		function manipulateBands(this : OrgStructureComponent, response) : any
		{
			response.bands.forEach(band => band.roles = response.roles.filter(role => role.bandId == band.id));
			response.bands = sortBy(response.bands, ['bandOrder']);
			return response;
		}

		function onSuccess(this : OrgStructureComponent, response) : void
		{
			Object.assign(this, response);
			this.chartData = this.manipulateObjects(this.roles);
		}
	}

	private manipulateObjects(temp) : void
	{
		return temp.map(item => {
			return {
				id       : item.id,
				name     : item.name,
				parentId : item.parentRoleId ? item.parentRoleId.toLowerCase() : '',
				color    : item.band.color,
				level    : item.band.name
			}
		});
	}

	editBand(band) : void
	{
		var initialState = {
			band         : cloneDeep(band),
			accessLevels : this.accessLevels
		}
		let modalRef = this.modalService.show(EditBandComponent, { initialState });
		modalRef.content.event.subscribe(() => this.ngOnInit());
	}

	editRole(role) : void
	{
		var initialState = {
			role         : cloneDeep(role),
			accessLevels : this.accessLevels
		}
		let modalRef = this.modalService.show(EditEntityComponent, { initialState });
		modalRef.content.event.subscribe(() => this.ngOnInit());
	}

	addNewBandRole() : void
	{
		this.router.navigateByUrl('band-roles');
	}
}
