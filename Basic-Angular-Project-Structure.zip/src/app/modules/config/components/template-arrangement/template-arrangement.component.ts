import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { IconDefinition, faCube, faCubes, faArrowLeft } from '@fortawesome/pro-solid-svg-icons';
import { map } from 'rxjs/operators';
import { AccountDetails } from 'src/app/models/acount-details.model';
import { ActiveUser } from 'src/app/models/active-user.model';
import { MasterTemplate } from 'src/app/models/MasterTemplate.model';
import { AccountService } from 'src/app/services/account.service';
import { ActiveUserService } from 'src/app/services/active-user.service';
import { TemplateService } from 'src/app/services/template.service';

@Component({
	selector    : 'template-arrangement',
	templateUrl : './template-arrangement.component.html',
	styleUrls   : ['./template-arrangement.component.scss']
})
export class TemplateArrangementComponent implements OnInit
{
	fa              : Record<string, IconDefinition>;
	templateSelect  : FormControl;
	accountSelect   : FormControl;
	user            : ActiveUser;
	accounts        : AccountDetails[];
	selectedAccount : AccountDetails;
	templates       : MasterTemplate[];
	selectedTemplate: MasterTemplate;
	selectedTabId   : number;

	constructor(
		private accountService    : AccountService,
		private templateService   : TemplateService,
		private activeUserService : ActiveUserService,
		private route             : ActivatedRoute,
		private router            : Router,
	) 
	{
		this.selectedTabId  = 0;
		this.fa             = { faCube, faCubes, faArrowLeft };
		this.user           = this.activeUserService.getUser();
		this.templateSelect = new FormControl();
		this.accountSelect  = new FormControl();
	}

	ngOnInit() : void
	{
		this.accountService.getAccountDetails(this.user.userId).subscribe(onSuccess.bind(this));
		function onSuccess(this : TemplateArrangementComponent, response : AccountDetails[]) : void
		{
			this.accounts = response;
			if (!this.route.snapshot.queryParams.accountId) this.accountSelect.setValue(this.accounts[0]);
			else
			{
				let queryAccount = this.accounts.find(account => account.accountId == this.route.snapshot.queryParams.accountId);
				this.accountSelect.setValue(queryAccount);
			}
		}

		this.onAccountChange();
		this.onTemplateChange();
	}

	onAccountChange() : void
	{
		this.accountSelect.valueChanges
			.pipe(
				map(getTemplates.bind(this))
			).subscribe((value: AccountDetails) => {
				this.selectedAccount = value;
			});

		function getTemplates(this: TemplateArrangementComponent, account: AccountDetails) : AccountDetails
		{
			this.templateService.getAccountTemplates(account.accountId).subscribe((template : MasterTemplate[]) => {
				this.templates = template;
				if(!this.route.snapshot.queryParams.templateId) this.templateSelect.setValue(this.templates[0]);
				else
				{
					let queryTemplate = this.templates.find(template => template.templateId == this.route.snapshot.queryParams.templateId);
					this.templateSelect.setValue(queryTemplate);
				}
			});
			return account;
		}
	}

	onTemplateChange() : void
	{
		this.templateSelect.valueChanges.subscribe(onTemplateSelected.bind(this));

		function onTemplateSelected(this: TemplateArrangementComponent, template : MasterTemplate) : void
		{
			if(!template) return;
			this.selectedTemplate = template;
		}
	}

	selectTarget(index : number = null) : void
	{
		this.selectedTabId = index;
	}

	goToTemplateList() : void
	{
		this.router.navigate(['template-list'], {queryParams : { accountId : this.selectedAccount.accountId, subaccountId : this.selectedTemplate.secondaryEntity }});
	}

}
