import { AccessLogsComponent } from "./access-logs/access-logs.component";
import { AddBandComponent } from './add-band/add-band.component';
import { AddEntityComponent } from './add-entity/add-entity.component';
import { AddNewBandRoleComponent } from "./add-new-band-role/add-new-band-role.component";
import { BasicFieldsConfigComponent } from "./basic-fields-config/basic-fields-config.component";
import { CustomFieldConfigComponent } from "./custom-field-config/custom-field-config.component";
import { CustomTrialComponent } from "./custom-trial/custom-trial.component";
import { EditBandComponent } from "./edit-band/edit-band.component";
import { EditEntityComponent } from "./edit-entity/edit-entity.component";
import { ExternalAccessComponent } from "./external-access/external-access.component";
import { PropertyConfigurationComponent } from "./property-configuration/property-configuration.component";
import { TemplateArrangementComponent } from "./template-arrangement/template-arrangement.component";
import { TemplateBasicConfigComponent } from "./template-basic-config/template-basic-config.component";
import { TemplateConfigComponent } from "./template-config/template-config.component";
import { OrgStructureComponent } from './org-structure/org-structure.component';
import { TemplateListComponent } from "./template-list/template-list.component";
import { AddTemplateComponent } from "./add-template/add-template.component";

export let components = [
	TemplateListComponent,
	AddTemplateComponent,
	TemplateArrangementComponent,
	TemplateBasicConfigComponent,
	BasicFieldsConfigComponent,
	TemplateConfigComponent,
	PropertyConfigurationComponent,
	CustomFieldConfigComponent,
	CustomTrialComponent,

	ExternalAccessComponent,
	AccessLogsComponent,

	AddBandComponent,
	AddEntityComponent,
	AddNewBandRoleComponent,
	EditBandComponent,
	EditEntityComponent,
	OrgStructureComponent
];