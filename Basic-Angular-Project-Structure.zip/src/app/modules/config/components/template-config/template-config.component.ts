import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';

import { cloneDeep, groupBy, sortBy } from 'lodash';
import { forkJoin } from 'rxjs';
import { IconDefinition, faCube, faCubes, faText, faTextHeight, faBallot, faList, faTasks, faCalendar, faCalendarDay, faHashtag, faCheckSquare, faDotCircle, faToggleOn, faRectangleWide } from '@fortawesome/pro-regular-svg-icons';
import { faCheck, faFolderDownload, faTrash, faCaretDown, faCaretRight, faExclamationTriangle } from '@fortawesome/pro-solid-svg-icons';

import { TableStorageService } from 'src/app/services/table-storage.service';
import { DragulaService } from 'ng2-dragula';
import { BsModalService } from 'ngx-bootstrap/modal';
import { TemplateService } from 'src/app/services/template.service';
import { MetricService } from 'src/app/services/metric.service';

import { CustomField } from 'src/app/models/MasterTemplateProperties.model';
import { TemplatePropertyValidation } from 'src/app/models/TemplatePropertyValidation.model';
import { MasterTemplate } from 'src/app/models/MasterTemplate.model';

import { CustomTrialComponent } from '../custom-trial/custom-trial.component';
import Swal from 'sweetalert2';

@Component({
	selector    : 'template-config',
	templateUrl : './template-config.component.html',
	styleUrls   : ['./template-config.component.scss']
})
export class TemplateConfigComponent implements OnInit, OnChanges
{
	@Input() template      : MasterTemplate;
	@Input() selectedTabId : number;

	fa                  : Record<string, IconDefinition>;
	components          : CustomField[];
	renderComponents    : Record<string, CustomField[]>;
	backupComponents    : Record<string, CustomField[]>;
	selectedComponent   : CustomField;
	validations         : TemplatePropertyValidation[];
	canAudit            : boolean;
	hasGroups           : boolean;
	sectionName         : FormControl;
	groupList           : string[];
	configs             : any;
	formTabIndex        : number;

	constructor(
		private azureTables     : TableStorageService,
		private dragulaService  : DragulaService,
		private modalService    : BsModalService,
		private templateService : TemplateService,
		private metricService   : MetricService
	)
	{
		this.formTabIndex        = 0;
		this.components          = [] as CustomField[];
		this.renderComponents    = { null : [] };
		this.backupComponents    = { null : [] };
		this.fa                  = { faCube, faCubes, faText, faTextHeight, faBallot, faList, faTasks, faCalendar, faCalendarDay, faHashtag, faCheckSquare, faDotCircle, faToggleOn, faRectangleWide, faCheck, faFolderDownload, faTrash, faCaretDown, faCaretRight, faExclamationTriangle };
		this.hasGroups           = false;
		this.sectionName         = new FormControl(null, Validators.required);
	}

	selectTab(index : number = null) : void
	{
		this.formTabIndex = index;
		this.getFormFields();
	}

	ngOnInit() : void
	{
		this.dragulaService.createGroup('COMPONENTS', {
			copy: (el, source) => {
				return source.id === 'components';
			},
			copyItem: (component : CustomField) => {
				component.newProperty = true;
				component.validations = [];
				component.childs      = component.hasChildEntity ? [] : null;

				this.selectComponent(cloneDeep(component));

				return this.selectedComponent;
			},
			accepts: (el, target) => {
				return target.id !== 'components';
			}
		});
		this.onComponentDropped();
	}

	ngOnChanges(): void
	{
		if(this.selectedTabId == 2)
		{
			forkJoin([
				this.templateService.getComponents(),
				this.templateService.getTemplateConfig(this.template.templateId),
				this.metricService.getMetricsConfiguration(this.template.templateId)
			]).subscribe(onSuccess.bind(this));
	
			function onSuccess(this : TemplateConfigComponent, response) : void
			{
				this.components = sortBy(response[0], ['sortOrder']);
				this.configs    = response[1];
				this.canAudit   = response[2].some(metric => metric.metricName == 'Quality');

				this.getFormFields();
			}
		}
	}

	private getFormFields() : void
	{
		if(!this.formTabIndex) this.templateService.getTemplateDetails(this.template.templateId, true).subscribe(onSuccess.bind(this));
		else this.templateService.getCustomFormProperties(this.template.templateId, true).subscribe(onSuccess.bind(this));

		function onSuccess(this : TemplateConfigComponent, response ) : void
		{
			this.renderComponents   = { null : [] };
			this.selectedComponent  = null;
			this.hasGrouping(response.customFields);
		}
	}

	private hasGrouping(response : CustomField[]) : void
	{
		this.hasGroups = !!~response.findIndex(property => property.groupName);
		if(this.hasGroups) {
			this.renderComponents = groupBy(response, 'groupName');
			this.groupList = Object.keys(this.renderComponents);
		}
		else this.renderComponents['null'] = response;
		this.backupComponents              = cloneDeep(this.renderComponents);
	}

	private onComponentDropped() : void
	{
		this.dragulaService.dropModel('COMPONENTS').subscribe(onValueChanged.bind(this));
		function onValueChanged(this: TemplateConfigComponent, value) : void
		{
			if(this.hasGroups) {
				if(value.source.id != 'components') this.renderComponents[value.source.id].splice(value.sourceIndex, 1);
				this.renderComponents[value.target.id] = value.targetModel;
				this.selectComponent(this.renderComponents[value.target.id][value.targetIndex]);
			}
		}
	}

	selectComponent(component : CustomField) : void
	{
		setTimeout(() => {},0);
		Object.keys(this.renderComponents).forEach(value => {
			this.renderComponents[value].forEach(item => item.isActive = false);
		});
		this.selectedComponent          = component;
		this.selectedComponent.isActive = true;
	}

	removeComponent(array : CustomField[], index : number) : void
	{
		array.splice(index, 1);
		this.selectedComponent = null;
	}

	addSection(form : FormControl) : void
	{
		if (form.invalid || form.value == null) return;

		this.renderComponents[form.value] = [];
		this.hasGroups                    = true;
		this.sectionName.reset();
	}

	removeSection(sectionName : string) : void
	{
		Swal.fire({
			title              : `Are you sure you want to remove the ${sectionName} section ?`,
			icon               : 'warning',
			showCancelButton   : true,
			cancelButtonText   : 'No',
			confirmButtonText  : 'Yes',
			confirmButtonColor : '#ED5565'
		}).then((input) => {
			if (input.value) {
				let properties = this.renderComponents[sectionName].filter(item => !item.newProperty);
				properties.forEach(prop => this.renderComponents[prop.groupName].push(prop));
				delete this.renderComponents[sectionName];
				if (Object.keys(this.renderComponents).length == 1) this.hasGroups = false;
			}
		});
	}

	clearFormSection() : void
	{
		Swal.fire({
			title              : 'Are you sure you want to clear the unsaved changes ?',
			icon               : 'warning',
			showCancelButton   : true,
			cancelButtonText   : 'No',
			confirmButtonText  : 'Yes',
			confirmButtonColor : '#ED5565'
		}).then((input) => {
			if (input.value) {
				this.renderComponents  = this.backupComponents;
				this.selectedComponent = null;
			}
		});
	}

	checkLength() : boolean
	{
		return Object.values(this.renderComponents).every(array => array.length);
	}

	openPropertiesTrial() : void
	{
		var initialState = {
			renderComponents : cloneDeep(this.postArray())
		}
		let modalRef = this.modalService.show(CustomTrialComponent, {initialState, class: 'modal-lg'});
	}

	saveTemplateProperties() : void
	{
		let customFields = this.postArray();
		if (customFields.length) this.templateService.addUpdateProperties(this.template.templateId, customFields).subscribe(() => this.ngOnChanges());
	}

	private postArray() : CustomField[]
	{
		let temp = [];
		for(let value of Object.keys(this.renderComponents)) {
			this.renderComponents[value].forEach(item => {
				item.index              = temp.length + 1
				item.templatePropertyId = !!item.templatePropertyId ? item.templatePropertyId : item.index;
				item.propertyName       = !!item.propertyName ? item.propertyName : `Prop_${item.index}`;
				item.groupName          = value == 'null' ? null : value;
				item.sortOrder          = item.index * 10;
				item.category           = !this.formTabIndex ? 'TemplateForm' : 'QualityForm' ;
				item.childs             = item.hasChildEntity ? childConfig.call(this, item) : [];
				temp.push(item);
			});
		}
		return temp;

		function childConfig(this : TemplateConfigComponent, property : CustomField) : CustomField[]
		{
			property.childs.forEach((child, index) => {
				child.propertyName       = !!child.propertyName ? child.propertyName : `Prop_${property.index}${index+1}`,
				child.sortOrder          = Number(`${property.index}${index+1}`);
				child.templatePropertyId = child.templatePropertyId ? child.templatePropertyId : Number(`${property.index}${index+1}`);
				child.category           = !this.formTabIndex ? 'TemplateForm' : 'QualityForm' ;
			});
			return property.childs;
		}
	}
}
