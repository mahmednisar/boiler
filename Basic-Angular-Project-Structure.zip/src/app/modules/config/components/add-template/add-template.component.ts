import { Component, EventEmitter, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { TemplateService } from 'src/app/services/template.service';

import { IconDefinition, faTimes } from '@fortawesome/pro-solid-svg-icons';
import { AccountDetails, SubAccountDetails } from 'src/app/models/acount-details.model';
import { TimezoneModel } from 'src/app/models/MasterTemplate.model';

@Component({
	selector    : 'add-template',
	templateUrl : './add-template.component.html',
	styleUrls   : ['./add-template.component.scss']
})
export class AddTemplateComponent implements OnInit 
{
	public event = new EventEmitter();

	@Input() account    : AccountDetails;
	@Input() subaccount : SubAccountDetails;
	@Input() timezones  : TimezoneModel[];

	fa              : Record<string, IconDefinition>;
	addTemplateForm : FormGroup;

	constructor(
		private formBuilder     : FormBuilder,
		public  activeModal     : BsModalRef,
		private templateService : TemplateService
	) 
	{
		this.fa = { faTimes };
	}

	ngOnInit() : void
	{
		if(this.account && this.subaccount) 
		{
			this.addTemplateForm = this.formBuilder.group({
				primaryEntity       : this.account.accountId,
				primaryEntityName   : this.account.accountName,
				secondaryEntity     : this.subaccount.subAccountId,
				secondaryEntityName : this.subaccount.subAccountName,
				templateName        : [null, Validators.required],
				templateKey         : [null, Validators.required],
				timez               : this.account.timeZone.timeZoneId,
				timeZones           : this.formBuilder.array([]),
				noComputation       : true,
				description         : null
			});
		}
	}

	addTemplate() : void
	{
		if(this.addTemplateForm.invalid) return;

		let data = {...this.addTemplateForm.value};
		data.noComputation = !data.noComputation;
		data.timeZones.push(this.account.timeZone);

		this.templateService.addTemplate(data).subscribe(onSuccess.bind(this));
		function onSuccess(this : AddTemplateComponent, response) : void
		{
			this.event.emit(true);
			this.activeModal.hide();
		}
	}

}
