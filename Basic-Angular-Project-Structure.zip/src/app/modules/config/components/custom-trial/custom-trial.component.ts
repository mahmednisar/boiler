import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { IconDefinition, faTimes } from '@fortawesome/pro-solid-svg-icons';
import { BsModalRef } from 'ngx-bootstrap/modal';

import { CustomField } from 'src/app/models/MasterTemplateProperties.model';
import { Task } from 'src/app/models/Task.model';
import { CommonTaskService } from 'src/app/modules/task/components/common-task.service';
import { FormGeneratorService } from 'src/app/services/form-generator.service';

@Component({
	selector    : 'custom-trial',
	templateUrl : './custom-trial.component.html',
	providers   : [CommonTaskService]
})
export class CustomTrialComponent implements OnInit
{
	fa               : Record<string, IconDefinition>;
	renderComponents : CustomField[];
	customFieldsForm : FormGroup;

	constructor(
		public  activeModal          : BsModalRef,
		private formGeneratorService : FormGeneratorService,
		private commonTaskService    : CommonTaskService
	)
	{
		this.fa               = { faTimes };
		this.customFieldsForm = new FormGroup({});
	}

	ngOnInit() : void
	{
		this.renderComponents.forEach(field => {
			field.isMandatory = field.validations.some(validation => validation.validationType == 'mandatory');
			field.isReadonly  = field.validations.some(validation => validation.validationType == 'readonly');

			field.validations.forEach(validation => {
				if(validation.validationType == 'cascadingDropdown' && field.newProperty)
				{
					let parent = this.renderComponents.find(item => (item.newProperty ? item.displayName : item.propertyName) == validation.dependentPropertyName);
					validation.dependentPropertyName = parent.propertyName;

					field.childs.forEach(child => {
						if(child.newProperty) {
							let parentChild = parent.childs.find(item => (item.newProperty ? item.displayName : item.propertyName) == child.filterPropertyName);
							child.filterPropertyName = parentChild.propertyName;
						}
					});
				}
			});
		});

		this.customFieldsForm = this.formGeneratorService.generateForm(this.renderComponents, true);
		this.commonTaskService.patchData({assignedTo : null} as Task, null, this.customFieldsForm, this.renderComponents, true);
	}
}
