import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';

import { ActivatedRoute, Router } from '@angular/router';
import { ActiveUserService } from 'src/app/services/active-user.service';
import { AccountService } from 'src/app/services/account.service';
import { TemplateService } from 'src/app/services/template.service';
import { BsModalService } from 'ngx-bootstrap/modal';

import { IconDefinition, faPlus, faSearch, faCog } from '@fortawesome/pro-solid-svg-icons';

import { AccountDetails, SubAccountDetails } from 'src/app/models/acount-details.model';
import { MasterTemplate, TimezoneModel } from 'src/app/models/MasterTemplate.model';
import { ActiveUser } from 'src/app/models/active-user.model';
import { AddTemplateComponent } from '../add-template/add-template.component';
import { forkJoin, Observable } from 'rxjs';
import { debounceTime, filter, map, switchMap } from 'rxjs/operators';
import { isEqual } from 'lodash';

@Component({
	selector    : 'template-list',
	templateUrl : './template-list.component.html',
	styleUrls   : ['./template-list.component.scss']
})
export class TemplateListComponent implements OnInit 
{
	fa                 : Record<string, IconDefinition>;
	user               : ActiveUser;
	timezones          : TimezoneModel[];
	templateList       : MasterTemplate[];
	accounts           : AccountDetails[];
	selectedAccount    : AccountDetails;
	subaccounts        : SubAccountDetails[];
	selectedSubaccount : SubAccountDetails;
	accountSelect      : FormControl;
	subAccountSelect   : FormControl;
	searchControl      : FormControl;
	templateFilterForm : FormGroup;
	pageSize           : number;
	totalTemplates     : number;
	reloadSame         : boolean;
	currentFilters     : Record<string, any>;

	constructor(
		private formBuilder       : FormBuilder,
		private router            : Router,
		private route             : ActivatedRoute,
		private activeUserService : ActiveUserService,
		private accountService    : AccountService,
		private templateService   : TemplateService,
		private modalService      : BsModalService,
	) 
	{
		this.currentFilters     = {};
		this.pageSize           = 20;
		this.fa                 = { faPlus, faSearch, faCog };
		this.user               = this.activeUserService.getUser();
		this.accountSelect      = new FormControl();
		this.subAccountSelect   = new FormControl();
		this.searchControl      = new FormControl();
		this.templateFilterForm = this.formBuilder.group({
			templateName    : null,
			primaryEntity   : null,
			secondaryEntity : null,
			timezoneId      : null,
			isActive        : true,
			pageNumber      : 1,
			numberOfRecords : this.pageSize,
		});
	}

	ngOnInit(): void 
	{
		forkJoin({
			timezones : this.accountService.getTimeZoneMaster(),
			accounts  : this.accountService.getAccountDetails(this.user.userId)
		}).subscribe(onSuccess.bind(this));
		function onSuccess(this : TemplateListComponent, response) : void
		{
			Object.assign(this, response);
			if (!this.route.snapshot.queryParams.accountId) this.accountSelect.setValue(this.accounts[0]);
			else
			{
				let queryAccount = this.accounts.find(account => account.accountId == this.route.snapshot.queryParams.accountId);
				this.accountSelect.setValue(queryAccount);
			}
		}

		this.onAccountChange();
		this.onSubaccountChange();

		this.onTemplateFiltersChange();
		this.searchControl.valueChanges.pipe(debounceTime(500)).subscribe(value => this.templateFilterForm.controls.templateName.setValue(value));
	}

	private onAccountChange() : void
	{
		this.accountSelect.valueChanges.subscribe(onAccountChanged.bind(this));
		function onAccountChanged(this : TemplateListComponent, value : AccountDetails) : void
		{
			this.selectedAccount = value;
			this.subaccounts     = this.selectedAccount.subAccountDetails;
			if(!this.route.snapshot.queryParams.subaccountId) this.subAccountSelect.setValue(this.subaccounts[0]);
			else
			{
				let queryTemplate = this.subaccounts.find(subaccount => subaccount.subAccountId == this.route.snapshot.queryParams.subaccountId);
				this.subAccountSelect.setValue(queryTemplate);
			}

			this.templateFilterForm.controls.primaryEntity.setValue(this.selectedAccount.accountId);
		}
	}

	private onSubaccountChange() : void
	{
		this.subAccountSelect.valueChanges.subscribe(onSubAccountChanged.bind(this));
		function onSubAccountChanged(this : TemplateListComponent, value :SubAccountDetails) : void
		{
			this.selectedSubaccount = value;
			this.templateFilterForm.controls.secondaryEntity.setValue(this.selectedSubaccount.subAccountId);
		}
	}

	private onTemplateFiltersChange() : void
	{
		this.templateFilterForm.valueChanges
		.pipe(map(resetPaging.bind(this)), filter(checkIfChanged.bind(this)), filter(checkIfMandatory.bind(this)), switchMap(getTasks.bind(this)))
		.subscribe(response => {
			this.templateList   = response.template;
			this.totalTemplates = response.count;
			this.reloadSame     = false;
		});

		function resetPaging(this : TemplateListComponent, filters) : any
		{
			if(filters.pageNumber == this.currentFilters.pageNumber && !this.reloadSame)
			{
				filters.pageNumber = 1;
				this.templateFilterForm.controls.pageNumber.setValue(1, {emitEvent : false});
			}
			return filters;
		}

		function checkIfChanged(this : TemplateListComponent, filters) : boolean
		{
			return this.reloadSame || !isEqual(filters, this.currentFilters);
		}

		function checkIfMandatory(this : TemplateListComponent, filter) : boolean
		{
			if(filter.primaryEntity && filter.secondaryEntity) return true;
			else false;
		}

		function getTasks(this : TemplateListComponent, filters) : Observable<MasterTemplate[]>
		{
			this.currentFilters = filters;
			return this.templateService.getMasterTemplatesList(this.currentFilters)
		}
	}

	addNewTemplate() : void
	{
		var initialState = {
			account    : {...this.selectedAccount},
			subaccount : {...this.selectedSubaccount},
			timezones  : this.timezones
		}
		let modalRef = this.modalService.show(AddTemplateComponent, { initialState, class: 'modal-lg' });
		modalRef.content.event.subscribe(res => {
			if(res) 
			{
				this.reloadSame    = true;
				this.templateFilterForm.updateValueAndValidity();
			}
		});
	}

	navigateToConfig(template : MasterTemplate) : void
	{
		this.router.navigate(['template-config'], {queryParams : { accountId : this.selectedAccount.accountId, templateId : template.templateId }});
	}
}
