import { Component, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { IconDefinition, faTimes } from '@fortawesome/pro-light-svg-icons';
import { OrgStructureService } from 'src/app/services/org-structure.service';

import { BsModalRef } from 'ngx-bootstrap/modal';
import { AccessLevels, Bands } from 'src/app/models/org-structure.model';

@Component({
	selector    : 'edit-band',
	templateUrl : './edit-band.component.html',
	styleUrls   : ['./edit-band.component.scss']
})
export class EditBandComponent
{
	public event = new EventEmitter();

	fa           : Record<string, IconDefinition>;
	band         : Bands;
	accessLevels : AccessLevels[];
	editBandForm : FormGroup;
	color        : string;

	constructor(
		public  activeModal         : BsModalRef,
		private orgStructureService : OrgStructureService,
		private formBuilder         : FormBuilder
	) {
		this.fa           = { faTimes };
		this.editBandForm = this.formBuilder.group({
			id          : [null, Validators.required],
			name        : [null, Validators.required],
			color       : [null, Validators.required],
			accessLevel : [null, Validators.required],
		});
	}

	ngOnInit() : void
	{
		this.color = this.band.color;
		this.editBandForm.patchValue({...this.band});
	}

	onColorChanged(color : string) : void
	{
		this.editBandForm.controls.color.setValue(color, {emitEvent : false});
		this.color = color;
	}

	updateBand() : void
	{
		if(this.editBandForm.invalid) return;

		this.orgStructureService.updateBand(this.editBandForm.value).subscribe(onBandUpdated.bind(this))
		function onBandUpdated(this : EditBandComponent, response) : void
		{
			this.activeModal.hide();
			this.event.emit(true);
		}
	}

}
