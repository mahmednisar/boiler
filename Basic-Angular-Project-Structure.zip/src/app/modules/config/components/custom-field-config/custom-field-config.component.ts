import { Component, EventEmitter, HostBinding, Input, OnInit, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { IconDefinition, faInfoCircle, faTimes } from '@fortawesome/pro-regular-svg-icons';
import { CustomField } from 'src/app/models/MasterTemplateProperties.model';

@Component({
	selector    : 'custom-field-config',
	templateUrl : './custom-field-config.component.html',
	styleUrls   : ['./custom-field-config.component.scss']
})
export class CustomFieldConfigComponent 
{
	@Output() cancel   = new EventEmitter();
	@Input() component : CustomField;
	@Input() index     : number;
	fa                 : Record<string, IconDefinition>;

	constructor()
	{
		this.fa = { faInfoCircle, faTimes };
	}

	@HostBinding('class.active')
	public get isActive(): Boolean 
	{
		return this.component.isActive;
	}
}
