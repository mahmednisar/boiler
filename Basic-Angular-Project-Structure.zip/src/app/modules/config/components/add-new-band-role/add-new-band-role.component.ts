import { Component, OnInit } from '@angular/core';
import { IconDefinition, faPlus, faArrowLeft } from '@fortawesome/pro-regular-svg-icons';
import { last, sortBy } from 'lodash';
import { forkJoin } from 'rxjs';
import { ActiveUser } from 'src/app/models/active-user.model';

import { AccessLevels, Bands, Roles } from 'src/app/models/org-structure.model';

import { ActiveUserService } from 'src/app/services/active-user.service';
import { OrgStructureService } from 'src/app/services/org-structure.service';

@Component({
	selector    : 'add-new-band-role',
	templateUrl : './add-new-band-role.component.html',
	styleUrls   : ['./add-new-band-role.component.scss']
})
export class AddNewBandRoleComponent implements OnInit 
{
	fa           : Record<string, IconDefinition>;
	user         : ActiveUser;
	bands        : Bands[];
	selectedBand : Bands;
	roles        : Roles[];
	accessLevel  : AccessLevels[];
	showEntity   : boolean;
	showBand     : boolean;
	chartData    : any;

	constructor(
		private activeUserService   : ActiveUserService,
		private orgStructureService : OrgStructureService
	) {
		this.user = this.activeUserService.getUser();
		this.fa   = { faPlus, faArrowLeft };
	}

	ngOnInit(): void 
	{
		forkJoin({
			bands       : this.orgStructureService.getBands(),
			roles       : this.orgStructureService.getRoles(),
			accessLevel : this.orgStructureService.getAccessLevels()
		}).subscribe(onSuccess.bind(this));
		function onSuccess(this : AddNewBandRoleComponent, response : any) : void
		{
			response.bands = sortBy(response.bands, ['bandOrder']);
			Object.assign(this, response);
			this.chartData = this.manipulateObjects(this.roles);
		}
	}

	private manipulateObjects(temp) : void
	{
		return temp.map(item => {
			return {
				id       : item.id,
				name     : item.name,
				parentId : item.parentRoleId ? item.parentRoleId.toLowerCase() : '',
				color    : item.band.color,
				level    : item.band.name
			}
		});
	}

	showBandInfo() : void
	{
		this.showEntity = false;
		this.showBand   = true;
	}

	hideInfo() : void
	{
		this.showBand = this.showEntity = false;
	}

	showRoleInfo(band : Bands) : void
	{
		this.showEntity   = true;
		this.showBand     = false;
		this.selectedBand = band;
	}
}
