import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { debounceTime, filter, map, switchMap } from 'rxjs/operators';
import { cloneDeep, isEqual } from 'lodash';

import { IconDefinition, faSearch, faPencilAlt, faTrashAlt, faBan, faSave, faTimes } from '@fortawesome/pro-solid-svg-icons';
import { faEye } from '@fortawesome/pro-regular-svg-icons';

import { BsModalService } from 'ngx-bootstrap/modal';
import { ActiveUserService } from 'src/app/services/active-user.service';
import { ExternalAccessService } from 'src/app/services/external-access.service';
import { DateTimeFormatterService } from 'src/app/services/date-time-formatter.service';

import { AccessLogsComponent } from '../access-logs/access-logs.component';
import { GrantAccessComponent } from '../../../shared/components/grant-access/grant-access.component';

import { ActiveUser } from 'src/app/models/active-user.model';
import { AccessLogs, WhitelistIps } from 'src/app/models/external-access.model';
import Swal from 'sweetalert2';
import { DateTime } from 'luxon';


@Component({
	selector    : 'external-access',
	templateUrl : './external-access.component.html',
	styleUrls   : ['./external-access.component.scss']
})
export class ExternalAccessComponent implements OnInit
{
	fa                  : Record<string, IconDefinition>;
	user                : ActiveUser;
	accessLogs          : AccessLogs[];
	copyAccessLogs      : AccessLogs[];
	whitelistIps        : WhitelistIps[];
	temporaryAccessForm : FormGroup;
	editLogForm         : FormGroup;
	searchControl       : FormControl;
	pageSize            : number;
	totalLogs           : number;
	editInProgress      : boolean;
	reloadSame          : boolean;
	today               : Date;
	startDateValidation : Date;
	endDateValidation   : Date;
	currentFilters      : any;

	constructor(
		private modalService          : BsModalService,
		private externalAccessService : ExternalAccessService,
		private activeUserService     : ActiveUserService,
		private formBuilder           : FormBuilder,
		private dateTimeFormatter     : DateTimeFormatterService
	) {
		this.user                = this.activeUserService.getUser();
		this.fa                  = { faSearch, faPencilAlt, faTrashAlt, faBan, faEye, faSave, faTimes };
		this.searchControl       = new FormControl();
		this.pageSize            = 25;
		this.editInProgress      = false;

		this.temporaryAccessForm = this.formBuilder.group({
			userId             : this.user.userId,
			tempAccessId       : null,
			isEndNow           : false,
			pageNo             : 1,
			noOfRecordsPerPage : this.pageSize,
			orderBy            : 'CreatedDate',
			sortOrder          : 'DESC',
			searchText         : null,
			isExpired          : null
		});
		
		this.editLogForm        = this.formBuilder.group({
			userId            : null,
			orgEntityId       : null,
			givenAccessUserId : null,
			startDate         : null,
			endDate           : null,
			tempAccessId      : null,
			comment           : null
		});
	}

	ngOnInit() : void
	{
		this.today               = this.dateTimeFormatter.getTodayStartDate('-07:00:00');
		this.startDateValidation = this.today;

		this.externalAccessService.getWhitelistIps().subscribe(response => this.whitelistIps = response);

		this.onFormValueChanges();
		this.searchControl.valueChanges.pipe(debounceTime(500)).subscribe(value => this.temporaryAccessForm.controls.searchText.setValue(value));
		this.temporaryAccessForm.controls.isExpired.setValue(false);
	}

	selectTab(index : number) : void
	{
		this.temporaryAccessForm.controls.isExpired.setValue(index ? true : false);
	}

	private onFormValueChanges() : void
	{
		this.temporaryAccessForm.valueChanges
		.pipe(
			filter(checkIfChanged.bind(this)),
			switchMap(getLogs.bind(this))
		).subscribe(onSuccess.bind(this));

		function checkIfChanged(this : ExternalAccessComponent, response : any) : boolean
		{
			return this.reloadSame || !isEqual(response, this.currentFilters);
		}

		function getLogs(this : ExternalAccessComponent, response) : any
		{
			this.currentFilters = response;
			return this.externalAccessService.getTemporaryAccessDetails(response);
		}

		function onSuccess(this : ExternalAccessComponent, response ) : void
		{
			this.accessLogs   = response.loglist;
			this.totalLogs    = response.count;

			this.accessLogs.forEach(item => {
				let startDate      = DateTime.fromISO(item.startDate).startOf('day');
				let today          = DateTime.fromJSDate(this.today).startOf('day');
				item.accessStarted = startDate <= today;

				if(!item.isPermanentAccess) {
					let endDate = DateTime.fromISO(item.endDate).startOf('day');
					item.accessEnded   = endDate < today;
				}
			});

			this.copyAccessLogs = cloneDeep(this.accessLogs);
			this.editInProgress = false;
		}
	}
	
	editParticularLog(log : AccessLogs) : void
	{
		if(!this.editInProgress)
		{
			log.isEdit          = true;
			this.editInProgress = true;
			this.setEndDateValidations(log.startDate);
			this.createLogForm(log);
		}
	}

	setEndDateValidations(startDate : Date) : void 
	{
		this.endDateValidation = new Date(startDate);
	}

	private createLogForm(log : AccessLogs) : void
	{
		this.editLogForm.patchValue({...log});
	}
	
	cancelEditing(log : AccessLogs, index : number) : void
	{
		log.isEdit = false;
		this.undoChanges(index);
	}

	private undoChanges(index : number) : void
	{
		this.accessLogs[index] = cloneDeep(this.copyAccessLogs[index]);
		this.accessLogs[index].isEdit = false;
		this.editInProgress = false;
		this.editLogForm.reset();
	}

	saveLogs(log : AccessLogs) : void
	{
		if (this.editLogForm.invalid) return;

		let data = { ...this.editLogForm.value };

		data.endDate   = data.endDate ? this.toISO(data.endDate.split('T')[0]) : null;
		data.startDate = data.startDate ? this.toISO(data.startDate.split('T')[0]) : null;

		this.externalAccessService.updateTemporaryAccess(data).subscribe(onSuccess.bind(this));
		function onSuccess(this : ExternalAccessComponent, response) : void
		{
			this.reloadSame     = true;
			log.isEdit          = false;
			this.editInProgress = false;
			this.editLogForm.reset();
			this.temporaryAccessForm.updateValueAndValidity();
		}
	}

	// Actions
	grantAccess() : void
	{
		let modalRef = this.modalService.show( GrantAccessComponent );
		modalRef.content.event.subscribe(onSuccess.bind(this));
		function onSuccess(this : ExternalAccessComponent, response) : void 
		{
			this.reloadSame    = true;
			this.temporaryAccessForm.updateValueAndValidity();
		}
	}

	viewLogs(log : AccessLogs) : void
	{
		var initialState = {
			userLog : cloneDeep(log)
		}
		this.modalService.show( AccessLogsComponent, { initialState } );
	}

	deleteOrEndNowAccess(log : AccessLogs, end : boolean) : void
	{
		var note = end ? 'revoke the access' : 'delete the log';
		Swal.fire({
			title              : 'This action will ' + note,
			text               : 'Are you sure ?',
			input              : 'textarea',
			inputPlaceholder   : 'Add comment',
			icon               : 'warning',
			showCancelButton   : true,
			confirmButtonText  : 'Yes',
			confirmButtonColor : '#ED5565',
			inputValidator     : value => !value && 'You need to add comments!'
		}).then((input) => {
			if (input.value)
			{
				log.isEndNow = end ? true : false;
				this.externalAccessService.deleteTemporaryAccess(log.tempAccessId, log.userId, log.isEndNow, input.value).subscribe(onDelete.bind(this));
				function onDelete(this : ExternalAccessComponent, response) : void 
				{
					this.reloadSame    = true;
					this.temporaryAccessForm.updateValueAndValidity();
				}
			}
		});
	}

	private toISO(date : string) : string
	{
		const config    = {zone : 'utc'};
		const format    = DateTimeFormatterService.LongDateTimeFormat;
		let luxonDate   = DateTime.fromISO(date).toFormat(format);
		return DateTime.fromFormat(luxonDate, format, config).toISO();
	}
}
