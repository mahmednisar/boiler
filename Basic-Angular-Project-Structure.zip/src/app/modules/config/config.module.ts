import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { components } from '../config/components';

import { ConfigRoutingModule } from './config-routing.module';
import { SharedModule } from '../shared/shared.module';

import { NgSelectModule } from '@ng-select/ng-select';
import { ReactiveFormsModule } from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { ModalModule } from 'ngx-bootstrap/modal';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from '@danielmoncada/angular-datetime-picker';
import { DragulaModule } from 'ng2-dragula';
import { CustomFieldsModule } from '../custom-fields/custom-fields.module';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { ColorPickerModule } from 'ngx-color-picker';


@NgModule({
	declarations : [...components],
	imports      : [
		ConfigRoutingModule,
		CommonModule,
		ReactiveFormsModule,
		NgSelectModule,
		FontAwesomeModule,
		SharedModule,
		CustomFieldsModule,

		PaginationModule.forRoot(),
		AccordionModule.forRoot(),
		TabsModule.forRoot(),
		TooltipModule.forRoot(),
		DragulaModule.forRoot(),
		ModalModule.forRoot(),
		PopoverModule.forRoot(),
		OwlDateTimeModule,
		OwlNativeDateTimeModule,
		ColorPickerModule
	]
})
export class ConfigModule { }
