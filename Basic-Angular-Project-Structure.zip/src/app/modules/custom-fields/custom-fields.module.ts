import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { SharedModule } from '../shared/shared.module';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from '@danielmoncada/angular-datetime-picker';

import { CustomFieldComponent } from './components/custom-field/custom-field.component';
import { TaskFieldsComponent } from './components/task-fields/task-fields.component';


let components = [
	CustomFieldComponent,
	TaskFieldsComponent
]

@NgModule({
	declarations : [...components],
	exports      : [...components],
	imports      : [
		CommonModule,
		ReactiveFormsModule,
		NgSelectModule,
		FontAwesomeModule,
		SharedModule,
		
		AccordionModule.forRoot(),
		TooltipModule.forRoot(),
		OwlDateTimeModule,
		OwlNativeDateTimeModule,
	]
})
export class CustomFieldsModule { }
