import { Component, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { IconDefinition, faInfoCircle } from '@fortawesome/pro-regular-svg-icons';

import { CustomField } from 'src/app/models/MasterTemplateProperties.model';

@Component({
	selector    : 'custom-field',
	templateUrl : './custom-field.component.html'
})
export class CustomFieldComponent
{
	@Input() config : CustomField;
	@Input() form   : FormGroup

	fa : Record<string, IconDefinition>;

	constructor()
	{
		this.fa = { faInfoCircle };
	}
}