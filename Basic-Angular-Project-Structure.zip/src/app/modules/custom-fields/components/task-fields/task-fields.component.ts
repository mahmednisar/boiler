import { Component, Input, HostBinding, OnChanges, ChangeDetectionStrategy } from '@angular/core';
import { FormGroup } from '@angular/forms';

import groupBy from 'lodash/groupBy';

import { CustomField } from 'src/app/models/MasterTemplateProperties.model';
import { TemplatePropertyValidation } from 'src/app/models/TemplatePropertyValidation.model';

import { faCaretDown, faCaretRight, IconDefinition } from '@fortawesome/pro-solid-svg-icons';

@Component({
	selector        : 'task-fields',
	templateUrl     : './task-fields.component.html',
	styleUrls       : ['./task-fields.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush
})
export class TaskFieldsComponent implements OnChanges {
	@HostBinding('class') class = 'd-contents';

	@Input() properties : CustomField[];
	@Input() form       : FormGroup;

	groupedFields : Record<string, CustomField[]>;
	renderOrder   : any;
	fa            : Record<string, IconDefinition>;
	hasGroups     : boolean;

	constructor() {
		this.fa = { faCaretDown, faCaretRight };
	}

	ngOnChanges() : void 
	{
		var vm             = this;
		vm.hasGroups       = !!~vm.properties.findIndex(property => property.groupName);
		vm.groupedFields   = groupBy(vm.properties, 'groupName');
		vm.renderOrder     = Object.keys(vm.groupedFields).sort(a => /null|Prop\sDeleted/.test(a) ? 1 : -1);

		let temp = { conditionalMandatory, cascadingDropdown };

		vm.properties.forEach(property => {
			for( let value of Object.keys(temp) )
			{
				let validation = property.validations.find(validation => validation.validationType == value);
				if(validation)
				{
					let childs = property.childs;
					vm.form.get(validation.dependentPropertyName).valueChanges.subscribe(fieldValue => {
						temp[value](property, fieldValue, childs);
					});
				}
			}
		});

		function conditionalMandatory(property : CustomField, fieldValue : any) : void
		{
			property.isMandatory = property.validations.some(generateValue);
			function generateValue(validation: TemplatePropertyValidation) : boolean 
			{
				switch (validation.validationCondition) {
					case 'equalto'            :
						if (typeof fieldValue === 'boolean') return String(fieldValue) == validation.validationValue;
						else return fieldValue == validation.validationValue;
					case 'notequalto'         : return fieldValue != validation.validationValue;
					case 'lessthan'           : return fieldValue < validation.validationValue;
					case 'greaterthan'        : return fieldValue > validation.validationValue;
					case 'lessthanorequalto'  : return fieldValue <= validation.validationValue;
					case 'greaterthanequalto' : return fieldValue >= validation.validationValue;
				}
			}
		}

		function cascadingDropdown(property : CustomField, fieldValue : any, childs : CustomField[]) : void
		{
			property.childs = null;
			if(fieldValue)
			{
				property.childs = childs.filter(item => item.filterPropertyName == fieldValue);
				vm.form.controls[property.propertyName].reset();
			}
		}
	}
}