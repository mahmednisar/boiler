import { Component, HostBinding } from '@angular/core';

@Component({
	selector: 'unauthorized',
	templateUrl: './unauthorized.component.html',
	styleUrls: ['./unauthorized.component.scss']
})
export class UnauthorizedComponent {
	@HostBinding('class') class = 'wrapper d-flex align-items-center justify-content-center bg-light';
}
