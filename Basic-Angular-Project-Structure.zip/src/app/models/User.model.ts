export interface User
{
	userId    : string;
	firstName : string;
	lastName  : string;
	fullName  : string;
	email     : string;
	disabled  ?: boolean;
}