import { MasterTemplateProperties } from './MasterTemplateProperties.model';

export interface TemplatePropertyValidation
{
	templatePropertyValidationId : number;
	templatePropertyId           : number;
	validationType              ?: string;
	validationValue             ?: string;
	createdBy                   ?: string;
	createdOn                    : Date;
	absoluteCreatedOn            : Date;
	updatedBy                   ?: string;
	updatedOn                   ?: Date;
	masterTemplateProperties    ?: MasterTemplateProperties;
}