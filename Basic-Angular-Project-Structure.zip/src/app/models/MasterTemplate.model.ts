export interface MasterTemplate
{
	configurations      : Configurations[];
	metricDeadlines     : metricDeadlines[];
	templateId          : number;
	templateName        ?: string;
	title               ?: string;
	autoStart           : boolean;
	parentTemplateId    ?: number;
	primaryEntity       ?: string;
	primaryEntityName   ?: string;
	secondaryEntity     ?: string;
	secondaryEntityName ?: string;
	ternaryEntity       ?: string;
	sla                 : boolean;
	status              ?: string;
	description         ?: string;
	createdBy           ?: string;
	createdOn           : Date;
	absoluteCreatedOn   : Date;
	updatedBy           ?: string;
	updatedOn           ?: Date;
	absoluteUpdatedOn   ?: Date;
	instance            ?: number;
	subtaskTemplates    ?: MasterTemplate[];
	timeZones            : TimezoneModel[];
	noComputation       ?: boolean;
	templateKey         ?: string;
}

export interface TimezoneModel
{
	id                 ?: number;
	templateId         ?: number;
	timeZoneId         ?: number;
	timeZone           ?: string;
	absoluteDateColumn ?: string;
	isDefault          ?: boolean;
	utcOffset          ?: string;
	timeZoneName       ?: string;
}

export interface Configurations
{
	choices: any;
	configCode            : string;
	configurationMasterId : number;
	id                    : number;
	isDeleted             : boolean;
	templateId            : number;
}

export interface metricDeadlines
{
	metricName     : string;
	metricDeadline : number; //Seconds
}