export interface EmployeeFilter
{
	pageNumber        ?: number;
	numberOfRecords   ?: number;
	onlyActive        ?: boolean;
	isDescending      ?: boolean;
	totalRecordsCount ?: number;
	orderBy           ?: string;
	filterBy          ?: string;
	searchText        ?: string;
	accountId         ?: number;
	roleId            ?: string;
}

export interface EmployeeList
{
	count  : number;
	result : Employee[];
}

export interface Employee
{
	email         ?: string;
	firstName     ?: string;
	middleName    ?: string;
	lastName      ?: string;
	fullName      ?: string;
	phoneNumber   ?: string;
	psgEmployeeId ?: string;
	isActive      ?: boolean;
	isDeleted     ?: boolean;
	DOB           ?: string;
	dob           ?: string;
	hireDate      ?: string;
	imageUrl      ?: string;
	userId        ?: string;
	userAccounts  ?: AccountRoleMapping[];
	isAdmin       ?: boolean;
	accessStatus  ?: boolean;
}

export interface AccountRoleMapping
{
	accountId    ?: number;
	accountName  ?: string;
	roleId       ?: string;
	roleName     ?: string;
	subaccounts  ?: any;
}

export interface Subaccounts
{
	subaccountId   ?: number;
	subaccountName ?: string;
}

