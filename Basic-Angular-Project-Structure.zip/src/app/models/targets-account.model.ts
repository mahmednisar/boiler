export interface TargetsAccount
{
	id              : number;
    userId          : string;
    accountId       : number;
    workHours       : number;
    productiveHours : number;
    maxTarget       : number;
    scheduleDate    : string;
    addedBy         : string;
    addedOn         : string;
    updatedBy      ?: string;
    updatedOn      ?: string;
    isDeactivated   : boolean;
    deactivatedOn  ?: string;
    targetValue     : string;
    userName        : string;
    addedByName     : string;
    editing         : boolean
}