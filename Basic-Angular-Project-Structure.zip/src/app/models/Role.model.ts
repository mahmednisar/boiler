export interface Role
{
	accessLevel   : string
	band          : string
	bandId        : string
	id            : string
	name          : string
	normalizeName : string
	parentRoleId  : string
}