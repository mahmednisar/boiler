export interface DashboardTimelines
{
	id              ?: number,
	name            ?: string,
	code            ?: string,
	description     ?: string,
	hasStatusCharts ?: boolean;
}