import { TimezoneModel } from "./MasterTemplate.model";

export interface AccountDetails
{
	accountId         : number;
	accountName       : string;
	timeZone          : TimezoneModel;
	utcOffset         : string;
	subAccountDetails : SubAccountDetails[];
	hasUsers          : boolean;
	isDeleted         : boolean;
	isActive          : boolean;
	expanded          : boolean;
}

export interface SubAccountDetails
{
	subAccountId           ?: number;
	subAccountName         ?: number;
	accountMaster          ?: string;
	accountMasterAccountId ?: number;
	isActive               ?: boolean;
}

export interface RoleDetails
{
	id            ?: string;
	name          ?: string;
	normalizeName ?: string;
	parentRoleId  ?: string;
	accessLevel   ?: string;
	bandId        ?: string;
	band          ?: OrgBand;
}
export interface OrgBand
{
	name         ?: string;
	color        ?: string;
	accessLevel  ?: string;
	parentBandId ?: string;
}