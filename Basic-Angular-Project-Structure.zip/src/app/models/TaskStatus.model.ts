export interface TaskStatus
{
	state      : string;
	name       : string;
	statusId   : number;
	templateId : number;
	sortOrder  : number;
}

export interface ConfigModel
{
	configurationMasterId ?: number,
	configCode            ?: string,
	configName            ?: string,
	description           ?: string;
	groupName             ?: string;
	choices               ?: any;
	hasChoices            ?: boolean;
}