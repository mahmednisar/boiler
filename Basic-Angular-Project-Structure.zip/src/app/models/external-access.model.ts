export interface TemporaryAccessParams
{
	tempAccessId         ?: number;
	userId               ?: string;
	isEndNow             ?: boolean;
	searchText           ?: string;
	pageNo               ?: number;
	noOfRecordsPerPage   ?: number;
	orderBy              ?: string;
	sortOrder            ?: string;
	totalRecordsCount    ?: number;
	comment              ?: string;
	isExpired            ?: boolean;
}

export interface AccessLogs
{
	accountId           ?: number;
	comment             ?: string;
	createdDate         ?: string;
	date                ?: string;
	endNowDate          ?: string;
	fullName            ?: string;
	givenAccessFullName ?: string;
	givenAccessUserId   ?: string;
	isActive            ?: boolean;
	isDeleted           ?: boolean;
	isEndNow            ?: boolean;
	isPermanentAccess   ?: boolean;
	orgEntityId         ?: string;
	role                ?: string;
	startDate           ?: string | any;
	endDate             ?: string | any;
	tempAccessId        ?: number;
	updatedBy           ?: string;
	updatedByName       ?: string;
	updatedDate         ?: string;
	userId              ?: string;
	isEdit              ?: boolean;
	accessStarted       ?: any;
	accessEnded         ?: any;
}

export interface AddAccessParams
{
	tempAccessId        ?: number;
	userId              ?: string;
	date                ?: string;
	givenAccessUserId   ?: string;
	startDate           ?: string;
	endDate             ?: string;
	isActive            ?: boolean;
	createdDate         ?: string;
	accountId           ?: number;
	isDeleted           ?: boolean;
	isEndNow            ?: boolean;
	endNowDate          ?: boolean;
	fullName            ?: string;
	givenAccessFullName ?: string;
	comment             ?: string;
	role                ?: string;
	isPermanentAccess   ?: boolean;
	updatedDate         ?: string;
	updatedBy           ?: string;
	updatedByName       ?: string;
}

export interface WhitelistIps
{
	networkName    ?: string;
	ipAddress      ?: string;
	isDeleted      ?: boolean;
	ipAddressStart ?: string;
	ipAddressEnd   ?: string;
}

export interface AccessUsers
{
	userId            ?: string;
	fullName          ?: string;
	isPermanentAccess ?: boolean;
	hasAccess         ?: boolean;
}
