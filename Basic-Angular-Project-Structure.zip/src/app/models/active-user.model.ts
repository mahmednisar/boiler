export interface ActiveUser
{
	firstName        : string;
	lastName         : string;
	fullName         : string;
	role             : string;
	roleId           : string;
	userId           : string;
	accountId        : string;
	email            : string;
	exp              : number;
	iat              : number;
	nbf              : number;
	isTM             : boolean;
	hasMultipleRoles : boolean;
	accessLevel      : string;
	OrgEntityColumn  : string;
}

export interface ActiveUserExternal{
	email                          : string;
	passwordResetConfirmationToken : string;
	newPassword                    : string;
	confirmPassword                : string;
}