export interface getWorkingDays
{
	count       ?: number;
	workingDays ?: WorkingDays[];
}

export interface WorkingDays
{
	start  ?: Date;
	date   ?: string;
	code   ?: string;
	userId ?: string;
}