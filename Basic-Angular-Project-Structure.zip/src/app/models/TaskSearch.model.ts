export interface TaskSearchParams
{
	createdBy        ?: string;
	assignedTo       ?: string;
	primaryEntity    ?: string;
	secondaryEntity  ?: string;
	ternaryEntity    ?: string;
	status           ?: string;
	masterTemplateId ?: number;
	startDate        ?: Date;
	endDate          ?: Date;
}