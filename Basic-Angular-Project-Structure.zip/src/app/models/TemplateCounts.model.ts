export interface TemplateCounts
{
	PartitionKey        : string;
	RowKey              : string;
	Timestamp           : string;
	closed              : number;
	completion          : number;
	completion_total    : number;
	externalaudit       : number;
	externalaudit_total : number;
	inprogress          : number;
	internalaudit       : number;
	internalaudit_total : number;
	new                 : number;
	hold                : number;
	sla                 : number;
	sla_total           : number;
	unassigned          : number;
	TemplateName        : string;
	TemplateId          : number;
	UserId              : string | null;
	UserName            : string | null;
	PrimaryEntity       : any    | null
}