import { Task } from './Task.model';

export interface TasksList
{
	count  : number;
	result : Task[];
}