import { TimezoneModel } from "./MasterTemplate.model";

export interface AccountSearchParams
{
	accountId         ?: number;
	accountName       ?: string;
	onlyActive        ?: boolean;
	isActive          ?: boolean;
	numberOfRecords   ?: number;
	pageNumber        ?: number;
	timezoneId        ?: number;
	userId            ?: number;
	timeZone          ?: TimezoneModel;
}

export interface SubaccountSearchParams
{
	accountId       ?: number;
	subAccountId    ?: number;
	timeZoneId      ?: number;
	timeZone        ?: string;
	userId          ?: string;
	currentUser     ?: boolean;
	isActive        ?: boolean;
	pageNumber      ?: number;
	numberOfRecords ?: number;
}