export interface Lookups
{
	id             ?: number;
	category       ?: string;
	key            ?: string;
	value          ?: string;
	description    ?: string;
	sortOrder      ?: number;
	weightageValue ?: string;
	isDeleted      ?: boolean;
}
