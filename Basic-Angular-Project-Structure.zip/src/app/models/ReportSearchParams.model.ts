export interface ReportSearchParams
{
	templateId          ?: number;
	templateName        ?: string;
	reportCode          ?: string;
	endPoint            ?: string;
	reportDate          ?: string;
	reportDateFrom      ?: string;
	reportDateTo        ?: string;
	pageNumber          ?: number;
	numberOfRecords     ?: number;
	userId              ?: string;
	primaryEntity       ?: string;
	secondaryEntity     ?: string;
	ternaryEntity       ?: string;
	status              ?: string;

	createdOn           ?: Array<Date>;
	createdOnFrom       ?: string;
	createdOnTo         ?: string;
	actualStartDate     ?: Array<string>;
	actualStartDateFrom ?: string;
	actualStartDateTo   ?: string;
	assignedOn          ?: Array<string>;
	assignedOnFrom      ?: string;
	assignedOnTo        ?: string;
	actualEndDate       ?: Array<string>;
	actualEndDateFrom   ?: string;
	actualEndDateTo     ?: string;
	dateRange           ?: string;
}