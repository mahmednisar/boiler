import { CustomField } from './MasterTemplateProperties.model';

export interface TemplatePropertyValidation
{
	templatePropertyValidationId : number;
	templatePropertyId           : number;
	validationType              ?: string;
	validationValue             ?: string;
	validationCondition         ?: string;
	createdBy                   ?: string;
	createdOn                    : Date;
	absoluteCreatedOn            : Date;
	updatedBy                   ?: string;
	updatedOn                   ?: Date;
	masterTemplateProperties    ?: CustomField;
	dependentPropertyId         ?: number;
	dependentPropertyName       ?: string;
	displayName                 ?: string;
}