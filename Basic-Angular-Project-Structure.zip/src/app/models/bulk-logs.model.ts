export interface BulkLogs
{
	id              : number;
	primaryEntity   : string;
	secondaryEntity : string;
	ternaryEntity   : string;
	successCount    : number;
	failedCount     : number;
	uploadedFile    : string;
	failedLogFile   : string;
	descr           : string;
	templateId      : number;
	uploadedBy      : string;
	uploadedOn      : string;
	uploadedByName  : string;
	templateName    : string;
}