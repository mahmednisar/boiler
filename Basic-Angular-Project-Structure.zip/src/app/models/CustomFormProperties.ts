import { TemplatePropertyValidation } from './TemplatePropertyValidation.model';

export interface CustomFormProperties
{
	id                        : string;
	propertyId                : number;
	templateId                : number;
	propertyName             ?: string;
	displayName              ?: string;
	type                     ?: string;
	value                    ?: any;
	childs                    : CustomFormProperties[];
	isDeleted                 : boolean;
	parentId                 ?: number;
	category                  : string;
	propertyType             ?: string;
	validations              ?: Array<TemplatePropertyValidation>;
}