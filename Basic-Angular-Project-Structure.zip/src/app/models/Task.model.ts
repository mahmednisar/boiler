export interface Task
{
	taskId              : number;
	title              ?: string;
	subTitle           ?: string;
	subTitle2          ?: string;
	assignedTo         ?: string;
	primaryEntity      ?: string;
	secondaryEntity    ?: string;
	ternaryEntity      ?: string;
	startDate          ?: Date;
	estimatedEndDate   ?: Date;
	actualEndDate      ?: string;
	receivedOn         ?: string;
	priority           ?: string;
	priorityValue      ?: string;
	priorityEdit       ?: boolean;
	sla                ?: boolean;
	status             ?: string;
	statusId           ?: number;
	state              ?: string;
	templateId          : number;
	description        ?: string;
	createdBy          ?: string;
	createdOn           : string;
	updatedBy          ?: string;
	autoStart           : boolean;
	actualStartDate    ?: string;
	completionTime     ?: string;
	assignedBy         ?: string;
	assignedByName     ?: string;
	assignedOn         ?: string;
	internalAudit      ?: boolean;
	internalAuditDate  ?: Date;
	externalAudit      ?: boolean;
	externalAuditDate  ?: Date;
	absoluteAssignedOn ?: Date;
	updatedOn          ?: string;
	absoluteCreatedOn   : Date;
	parentTaskId       ?: number;
	createdByName      ?: string;
	assignedToName     ?: string;
	subTaskList        ?: Task[];
	titleValue         ?: string;
	subTitleValue      ?: string;
	subTitle2Value     ?: string;
	subTitleEdit       ?: boolean;
	titleEdit          ?: boolean;
	assignedEdit       ?: boolean;
	taskDisplayId      ?: string;
	receivedOnEdit     ?: boolean;
	taskDeadlines      ?: {metricName : string; metricDeadline : string; isAchived : boolean; achievedDate ?: string}[];
	isEditable         ?: boolean;
	quality            ?: CustomFormModel;
	escalation         ?: CustomFormModel;
}


export interface CustomFormModel
{
	auditedBy     ?: string;
	auditedByName ?: string;
	auditedOn     ?: any;
	id            ?: number;
	metricId      ?: number;
	metricName    ?: string;
	isPassed      ?: boolean;
	reason        ?: string;
	remark        ?: string;
	note          ?: string;
	isEditable    ?: boolean;
}