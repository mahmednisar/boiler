export interface HoldLogs
{
	id           ?: number;
	holdOn       ?: string;
	resumedOn    ?: string;
	holdDuration ?: number;
}