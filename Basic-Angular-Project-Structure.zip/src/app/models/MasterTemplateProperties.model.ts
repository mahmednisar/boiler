import { MasterTemplate } from './MasterTemplate.model';
import { TemplatePropertyValidation } from './TemplatePropertyValidation.model';

export interface MasterTemplateProperties
{
	basicFields  : CustomField[];
	customFields : CustomField[];
}

export interface CustomField
{
	templatePropertyId        : any;
	templateId                : number;
	propertyName             ?: string;
	groupName                ?: string;
	displayName              ?: string;
	controlType              ?: string;
	propertyType             ?: string;
	type                     ?: string;
	tag                      ?: string;
	isMultiple                : boolean;
	value                    ?: any;
	parentTemplatePropertyId ?: number;
	createdBy                ?: string;
	createdOn                 : Date;
	absoluteCreatedOn         : Date;
	updatedBy                ?: string;
	updatedOn                ?: Date;
	filterPropertyName       ?: string;
	masterTemplate           ?: MasterTemplate;
	validations              ?: Array<TemplatePropertyValidation>;
	childs                    : CustomField[];
	helpText                  : string;
	isMandatory               : boolean;
	isReadonly                : boolean;
	placeHolder               : string;
	isActive                 ?: boolean;
	sortOrder                ?: number;
	index                    ?: number;
	newProperty              ?: boolean;
	validationsList          ?: Array<TemplatePropertyValidation>;
	hasChildEntity           ?: boolean;
	hasPlaceholder           ?: boolean;
	hasDefaultValue          ?: boolean;
	hasCascading             ?: boolean;
	isBulkUpload             ?: boolean;
	useForTaskPropertyRefId  ?: boolean;
	isEdit                   ?: boolean;
	category                 ?: string;
}