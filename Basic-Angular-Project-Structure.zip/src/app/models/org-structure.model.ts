export interface Bands
{
	id           ?: string;
	name         ?: string;
	color        ?: string;
	accessLevel  ?: string;
	parentBandId ?: string;
	sortOrder    ?: number;
	createdOn    ?: string;
	updatedOn    ?: string;
	roles        ?: Roles[];
}

export interface Roles
{
	accessLevel   ?: string;
	band          ?: Bands
	bandId        ?: string;
	createdOn     ?: string;
	id            ?: string;
	name          ?: string;
	normalizeName ?: string;
	parentRoleId  ?: string;
	viewFilter    ?: boolean;
}

export interface AccessLevels
{
	id             ?: number;
	category       ?: string;
	key            ?: string;
	value          ?: string;
	description    ?: string;
	sortOrder      ?: number;
	weightageValue ?: string;
	isDeleted      ?: boolean;
}