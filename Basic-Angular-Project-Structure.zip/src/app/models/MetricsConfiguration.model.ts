export interface MetricsConfiguration
{
	actualColumn         : number;
	createdBy            : string;
	createdOn            : Date;
	deadlineColumn       : number;
	deadlineEndCol       : number;
	deadlineStartCol     : number;
	deadlineValue        : number;
	deadlinekey          : string;
	formula              : string;
	frequency            : string;
	isPercentage         : boolean;
	metricId             : number;
	metricName           : string;
	targetColumn         : number;
	templateId           : number;
	updatedBy            : string;
	updatedOn            : Date;
	targetValue          : number;
	type                 : string;
	format               : string;
	auditRestrictionDate : any;
	configurations       : Record<any, any>;
	dashboardDisplay     : boolean;
}