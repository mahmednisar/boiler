export interface ReportMaster
{
	accountId        ?: number;
	endPoint         ?: string;
	excludeTimeline  ?: string;
	reportCode       ?: string;
	isView           ?: boolean;
	reportFilters    ?: FiltersList[]
	reportId         ?: number;
	reportName       ?: string;
	reportType       ?: string;
	templateId       ?: number;
}

export interface FiltersList
{
	controlType   ?: string;
	filterType    ?: string;
	propertyName  ?: string;
	displayName   ?: string;
}


