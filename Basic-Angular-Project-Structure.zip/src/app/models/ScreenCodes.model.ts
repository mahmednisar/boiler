export interface ScreenCodes
{
	sortOrder  : number;
	screenCode : string;
}