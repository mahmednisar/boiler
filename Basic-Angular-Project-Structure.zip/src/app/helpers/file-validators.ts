import { AbstractControl, FormControl } from "@angular/forms";

export class FileValidators
{
	static fileSizeValidator(files: FileList) 
	{
		return (control: AbstractControl): any => {
			const file = control.value;
			if (file) 
			{
				const fileSize     = files.item(0).size;
				const fileSizeInKB = Math.round(fileSize / 1024);
				
				if (fileSizeInKB >= 1024) {
					return { fileSizeValidator: true };
				} else return null;
			}
			return null;
		};
	}
}