import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';
import { ActiveUser } from 'src/app/models/active-user.model';
import { ActiveUserService } from 'src/app/services/active-user.service';

export class CValidators 
{
	static matchPasswords(control: AbstractControl)
	{
		let newPassword     = control.get('newPassword');
		let password     = control.get('password');
		let confirmPassword = control.get('confirmPassword');
		let comaprePassword = newPassword ? newPassword : password
		if (comaprePassword.value !== confirmPassword.value) 
		{
			return { PasswordDontMatch : true };
		}
		return null;
	}

	static shouldNotBeName(user : any) {
		return (control: AbstractControl) : any => { 
			if(control.value)
			{
				let temp = control.value.toLowerCase().includes(user.firstName.replace(/\s/g, "").toLowerCase()) || control.value.toLowerCase().includes(user.lastName.replace(/\s/g, "").toLowerCase());
				return temp ? { shouldNotBeName : true } : null
			}
		};
	}
}