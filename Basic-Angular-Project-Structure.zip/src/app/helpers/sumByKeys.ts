export default function sumByKeys<T>(array : T[], keys : string[]) : Record<string, number> {
	let sumObject = array.reduce(accumulateCounts, {});
	return sumObject;

	function accumulateCounts(accumulator, current) : Record<string, number>
	{
		for (let key of keys)
		{
			if (accumulator[key] == null) accumulator[key] = 0;
			accumulator[key] += current[key] || 0;
		}

		return accumulator;
	}
}