export function parseJWT<T>(token : string) : T {
	if (!token) return null;

	let base64  = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
	let payload = decodeURIComponent(atob(base64).split('').map(processChars).join(''));

	return JSON.parse(payload);

	function processChars(char : string) : string {
		return '%' + ('00' + char.charCodeAt(0).toString(16)).slice(-2);
	}
}