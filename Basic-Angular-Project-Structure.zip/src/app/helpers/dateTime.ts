import { DateTime } from 'luxon';

// const zone = 'America/Los_Angeles';
const zone = 'utc';

export function manipulateDateRangeFilters(key : string, [from, to] : Date[]) : Record<string, string> {
	return {
		[`${key}From`] : toTimezoneISO(from, zone),
		[`${key}To`]   : toTimezoneISO(to, zone)
	};
}

function toTimezoneISO(date : Date, zone : string) : string {
	const config    = { zone };
	const format    = 'DD MM YYYY';

	let luxonDate = DateTime.fromJSDate(date).toFormat(format);
	return DateTime.fromFormat(luxonDate, format, config).startOf('day').toISO();
}
// No Conversion in date format Conversion happening here