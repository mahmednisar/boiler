import { Component, HostBinding } from '@angular/core';

@Component({
	selector    : 'app-not-found',
	templateUrl : './not-found.component.html',
	styleUrls   : ['./not-found.component.scss']
})
export class NotFoundComponent {
	@HostBinding('class') class = 'wrapper d-flex align-items-center justify-content-center bg-light';
}