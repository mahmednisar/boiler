import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { NavigationEnd, Router, ActivatedRoute, Data, RouterEvent } from '@angular/router';
import { Title } from '@angular/platform-browser';

import { Observable, combineLatest } from 'rxjs';
import { filter, mapTo, map, switchMap } from 'rxjs/operators';
import { ActiveUserService } from './services/active-user.service';

@Component({
	selector    : 'app-root',
	templateUrl : './app.component.html',
	styleUrls   : ['./app.component.scss']
})
export class AppComponent implements OnInit
{
	constructor(
		private router         : Router,
		private activatedRoute : ActivatedRoute,
		private title          : Title,
		private userService    : ActiveUserService,
		private location       : Location
	) {}

	ngOnInit() : void
	{
		this.location.isCurrentPathEqualTo('') && this.userService.redirectUser();

		this.router.events
			.pipe(
				filter(filterNavigationEndEvents),
				mapTo(this.activatedRoute),
				switchMap(getChildData),
				map(generateTitle)
			)
			.subscribe(title => this.title.setTitle(title));

		function filterNavigationEndEvents(event : RouterEvent) : boolean
		{
			return event instanceof NavigationEnd;
		}

		function getChildData(activatedRoute : ActivatedRoute) : Observable<Data>
		{
			let routes : Observable<Data>[] = [];
			for(let route = activatedRoute.firstChild; route; route = route.firstChild) routes.push(route.data)
			return combineLatest(routes);
		}

		function generateTitle(routeData : Record<'title', string>[]) : string
		{
			return routeData.reduce((acc, val) => val.title ? `${acc} :: ${val.title}` : acc, 'Admin Accounts')
		}
	}
}