import { Injectable } from "@angular/core";
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from "@angular/common/http";
import { Observable } from "rxjs";
import { finalize, tap } from "rxjs/operators";
import { LoaderService } from './loader.service';


@Injectable()
export class LoaderInterceptor implements HttpInterceptor
{
	private count = 0;
	constructor(private loaderService: LoaderService) {}

	intercept(request : HttpRequest<any>, next : HttpHandler) : Observable<HttpEvent<any>>
	{
		if (request.headers.has('X-Hide-Spinner')) return next.handle(request);

		this.count++;
		return next.handle(request).pipe(
			tap(() => {
				if(this.count) this.loaderService.show();
			}),
			finalize(() => {
				this.count--;
				if(!this.count) this.loaderService.hide();
			})
		);
	}
}