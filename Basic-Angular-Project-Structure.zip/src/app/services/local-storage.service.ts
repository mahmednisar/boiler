 import { Injectable } from '@angular/core';

@Injectable()
export class LocalStorageService
{
	getItem(key) : any
	{
		try
		{
			return JSON.parse(localStorage.getItem(key));
		}

		catch(error)
		{
			console.error(error);
			return null;
		}
	}

	setItem(key, value) : void
	{
		try
		{
			localStorage.setItem(key, JSON.stringify(value));
		}

		catch(error)
		{
			console.error(error);
		}
	}

	removeItem(key) : void
	{
		localStorage.removeItem(key)
	}

	clear() : void
	{
		localStorage.clear();
	}
}