import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DateTimeFormatterService } from './date-time-formatter.service';

import { Observable, of } from 'rxjs';

import { Targets } from '../models/targets.model';
import { cloneDeep } from 'lodash';
import { TargetsAccount } from '../models/targets-account.model';

@Injectable()
export class TargetService
{
	constructor(
		private http           : HttpClient,
		private dateTimeFormat : DateTimeFormatterService
	) {}

	addTargets(data : Record<string, unknown>) : Observable<any>
	{
		return this.http.post('AddTargets', data);
	}

	addUpdateWorkSchedule(data : Record<string, unknown>) : Observable<any>
	{
		return this.http.post('AddUpdateWorkSchedule', data);
	}

	getTargets(templateId : number, targetDate ?: string, userId ?: string) : Observable<Targets[]>
	{
		return this.http.post<Targets[]>('GetTargets', {templateId, targetDate, userId});
		// By Default it will take todays Date from Backend if targetDate is Not Provided
		// If UserId not Provided data for all users would be available
	}

	getAccountTargets(accountId : number, scheduledate ?: string) : Observable<TargetsAccount[]>
	{
		return this.http.post<TargetsAccount[]>('GetWorkSchedule', {accountId, scheduledate});
	}

	deactivateTarget(filters : Record<string, any>) : Observable<any>
	{
		let params = cloneDeep(filters);
		for (let key of ['deactivateDate', 'reactivateDate'])
		{
			params[key] = this.dateTimeFormat.toTimezoneISO(params[key])
		}
		return this.http.post<any>('DeactivateTarget', params );
	}

}