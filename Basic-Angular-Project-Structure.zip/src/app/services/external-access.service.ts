import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AccessUsers, AddAccessParams, TemporaryAccessParams, WhitelistIps } from '../models/external-access.model';

@Injectable()
export class ExternalAccessService
{
	constructor(
		private http : HttpClient,
	) {}

	getTemporaryAccessDetails(data : TemporaryAccessParams) : Observable<any[]>
	{
		return this.http.post<any[]>('GetTemporaryAccessDetails', {...data});
	}

	getWhitelistIps() : Observable<WhitelistIps[]>
	{
		return this.http.get<WhitelistIps[]>('GetWhitelistIps');
	}

	getAccessUser() : Observable<AccessUsers>
	{
		return this.http.get<AccessUsers>('GetFunctionSpecificUsersTempAccess');
	}

	addTemporaryAccess(data : AddAccessParams) : Observable<any>
	{
		return this.http.post<any[]>('AddTemporaryAccess', {...data});
	}

	updateTemporaryAccess(data : AddAccessParams) : Observable<any>
	{
		return this.http.post<any[]>('UpdateTemporaryAccess', {...data});
	}

	getExternalAccessLogByUser(data : any) : Observable<any>
	{
		return this.http.post<any[]>('GetExternalAccessLogByUser', {...data});
	}

	deleteTemporaryAccess(TempAccessId, UserId, IsEndNow, Comment) : Observable<any>
	{
		return this.http.post<any>('DeleteOREndNowTemporaryAccess', {'TempAccessId' : TempAccessId, 'UserId' : UserId, 'IsEndNow' : IsEndNow, 'Comment' : Comment });
	}
}
