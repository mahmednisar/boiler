import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../models/User.model';
import { UserSearchParams } from '../models/UserSearch.model';

@Injectable()
export class UserService
{
	constructor(private http : HttpClient) {}

	getUsers(params : any = {}) : Observable<User[]>
	{
		return this.http.post<User[]>('GetUsers', params);
	}

	getAssignUsers(params : any = {}) : Observable<User[]>
	{
		return this.http.post<User[]>('GetAssignUsers', params);
	}

	getUserRoleLogs(userId) : Observable<any>
	{
		return this.http.get('GetUserRoleLogs', {params: {userId}});
	}
}