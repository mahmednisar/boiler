import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { AccessLevels, Bands, Roles } from '../models/org-structure.model';

@Injectable()
export class OrgStructureService {
	constructor(
		private http : HttpClient,
	) { }

	getBands(): Observable<Bands[]>
	{
		return this.http.get<Bands[]>('GetBands');
	}

	getRoles() : Observable<Roles[]>
	{
		return this.http.get<Roles[]>('GetRoles');
	}

	getAccessLevels() : Observable<AccessLevels[]>
	{
		return this.http.get<AccessLevels[]>('GetAccessLevels');
	}

	addBand(data : Record<string, string>) : Observable<any>
	{
		return this.http.post<any>('AddBand', {...data});
	}

	updateBand(data : Record<string, string>) : Observable<any>
	{
		return this.http.post<any>('UpdateBand', {...data});
	}

	addRole(data : Record<string, string>) : Observable<any>
	{
		return this.http.post<any>('AddNewRole', {...data});
	}

	updateRole(data : Record<string, string>) : Observable<any>
	{
		return this.http.post<any>('UpdateRole', {...data});
	}

	traverseDown(userId : string, accountId ?: any) : Observable<any>
	{
		return this.http.get<any>('TraverseDownForPeople', {params : {userId, accountId}});
	}

	getReportingHistory(userId : string) : Observable<any>
	{
		return this.http.get<any>('GetReportingHistory', {params : {userId}});
	}

	getReportingRoles(userId : string) : Observable<Roles[]>
	{
		return this.http.get<Roles[]>('GetReportingRoles', {params : {userId}});
	}
}