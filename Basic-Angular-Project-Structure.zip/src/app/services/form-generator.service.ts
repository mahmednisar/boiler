import { Injectable } from '@angular/core';
import { FormGroup, FormBuilder, Validators, ValidatorFn } from '@angular/forms';

import { TemplatePropertyValidation } from 'src/app/models/TemplatePropertyValidation.model';
import { CustomField } from 'src/app/models/MasterTemplateProperties.model';
import { MetricsConfiguration } from '../models/MetricsConfiguration.model';
import { find } from 'lodash';

@Injectable()
export class FormGeneratorService
{
	constructor(private formBuilder : FormBuilder) {}

	generateForm(properties : any[], needsRequired ?: boolean) : FormGroup {
		let form;
		let formBuilder = this.formBuilder;
		return form = formBuilder.group(Object.fromEntries(properties.map(generateFormControls)));

		function generateFormControls(field : CustomField) : [string, any] 
		{
			if (field.type == 'checkbox') return [field.propertyName, formBuilder.array(Array.from({ length: field.childs.length}))];
			return [field.propertyName, [field.value, field.validations.map(generateValidators).filter(Boolean)]];
		}

		function generateValidators(validation : TemplatePropertyValidation) : Validators 
		{
			switch (validation.validationType) {
				case 'mandatory'          : return needsRequired ? Validators.required : null;
				case 'emailval'           : return Validators.email;
				case 'minval'             : return Validators.min(+validation.validationValue);
				case 'maxval'             : return Validators.max(+validation.validationValue);
				case 'patternVal'         : return Validators.pattern(validation.validationValue);
				case 'conditionalMandatory' : {
					if(needsRequired) return dependentValidator(() => form.get(properties.find(property => property.templatePropertyId == validation.dependentPropertyId).propertyName ).value, Validators.required);
					else return null;
				}
			}
		}

		function dependentValidator(predicate : any, validator?: ValidatorFn ): ValidatorFn
		{
			return (formControl => {
				if (!formControl.parent || !predicate()) {
					return null;
				}
				return validator(formControl);
			});
		}
	}

	generateMetricForm(properties : MetricsConfiguration[]) : FormGroup {
		let formBuilder = this.formBuilder;
		return formBuilder.group(Object.fromEntries(properties.map(generateMetricsFormControls)));

		function generateMetricsFormControls(metric : MetricsConfiguration) : [string, any]
		{
			return [metric.metricName, [ metric.targetValue, Validators.required ]];
		}
	}
}