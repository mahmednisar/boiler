import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { MetricsConfiguration } from '../models/MetricsConfiguration.model';

@Injectable()
export class MetricService
{
	constructor(private http : HttpClient) {}

	getMetricsConfiguration(templateId : number) : Observable<MetricsConfiguration[]>
	{
		return this.http.get<MetricsConfiguration[]>('GetMetricsConfiguration', {params : {templateId : templateId as unknown as string}});
	}
}