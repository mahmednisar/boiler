import { Injectable } from '@angular/core';
import { manipulateDateRangeFilters } from '../helpers/dateTime';
import { DateTime, DurationUnit } from 'luxon';

import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { cloneDeep } from 'lodash';

import { TableStorageService } from './table-storage.service';
import { DateTimeFormatterService } from './date-time-formatter.service';

import { ReportSearchParams } from '../models/ReportSearchParams.model';
import { ReportMaster } from '../models/ReportMaster.model';

@Injectable()
export class ReportService
{
	constructor(
		private azureTables    : TableStorageService,
		private http           : HttpClient,
		private dateTimeFormat : DateTimeFormatterService
	) {}

	getReportsData(filters : ReportSearchParams = {}) : Observable<any>
	{
		let params = cloneDeep(filters);
		for (let key of ['createdOn', 'assignedOn', 'actualStartDate', 'actualEndDate'])
		{
			if(params[key]) Object.assign(params, manipulateDateRangeFilters(key, params[key]));
			delete params[key];
		}
		return this.http.post<any>(filters.endPoint || 'DataDumpReport' , params);
	}

	getReportsToExcel(filters : ReportSearchParams = {}) : Observable<any>
	{
		let params = cloneDeep(filters);
		for (let key of ['createdOn', 'assignedOn', 'actualStartDate', 'actualEndDate'])
		{
			if(params[key]) Object.assign(params, manipulateDateRangeFilters(key, params[key]));
			delete params[key];
		}
		return this.http.post(`${filters.endPoint}Excel` || 'DataDumpReport', params, { responseType: 'blob' });
	}

	getReportList(accountId : string ) : Observable<ReportMaster[]>
	{
		return this.http.post<ReportMaster[]>('GetAvailableReports' , {accountId});
	}

	getReportTimelines(offset ?: any) : any
	{
		return [
			{ name : 'Today',       value : [this.dateTimeFormat.getTodaysDate(offset), this.dateTimeFormat.getTodaysDate(offset)] },
			{ name : 'Yesterday',   value : [this.dateTimeFormat.getYesterdaysDate(offset), this.dateTimeFormat.getYesterdaysDate(offset)] },
			{ name : 'This Week',   value : this.dateTimeFormat.getThisWeeksDate(offset) },
			{ name : 'This Month',  value : this.dateTimeFormat.getThisMonthsDate(offset) },
		]
	}

	getStartObject(freq : DurationUnit) : Date
	{
		return DateTime.local().startOf(freq).toJSDate();
	}

	getEndObject(freq : DurationUnit) : Date
	{
		return DateTime.local().endOf(freq).toJSDate();
	}

}