import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AccountDetails, RoleDetails, SubAccountDetails } from '../models/acount-details.model';
import { AccountSearchParams, SubaccountSearchParams } from '../models/acount-filter-params.model';

@Injectable()
export class AccountService
{
	constructor(
		private http : HttpClient,
	) {}

	getAccountDetails(userId : string) : Observable<AccountDetails[]>
	{
		return this.http.post<AccountDetails[]>('GetAccountDetails', {userId});
	}

	getUserAccounts(userId : string) : Observable<AccountDetails[]>
	{
		return this.http.post<AccountDetails[]>('GetUserAccounts', {userId});
	}

	getAccountList(params : AccountSearchParams = {}) : Observable<AccountDetails[]>
	{
		return this.http.post<AccountDetails[]>('GetAccountList', params);
	}

	addAccount(data : Record<string, unknown>) : Observable<any>
	{
		return this.http.post('AddAccount', data);
	}

	getSubaccountList(params: SubaccountSearchParams) : Observable<SubAccountDetails[]>
	{
		return this.http.post<SubAccountDetails[]>('GetSubAccountList', params);
	}

	addSubaccount(data : Record<string, unknown>) : Observable<any>
	{
		return this.http.post('AddSubAccount', data);
	}

	getRoleDetails() : Observable<RoleDetails>
	{
		return this.http.get<RoleDetails>('GetRoles');
	}

	getTimeZoneMaster() : Observable<any>
	{
		return this.http.get('GetTimeZoneMaster');
	}
}