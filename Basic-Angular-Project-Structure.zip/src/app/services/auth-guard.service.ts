import { Injectable } from '@angular/core';
import { Location } from '@angular/common';
import { Router, ActivatedRouteSnapshot, CanActivate, CanActivateChild } from '@angular/router';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { ActiveUserService } from '../services/active-user.service';
import { AuthorizationService } from './authorization.service';

import { ActiveUser } from '../models/active-user.model';
import { ScreenCodes } from '../models/ScreenCodes.model';

@Injectable()
export class AuthGuardService implements CanActivate, CanActivateChild
{
	private activeUser : ActiveUser;

	constructor(
		private activeUserService : ActiveUserService,
		private router            : Router,
		private location          : Location,
		private authorization     : AuthorizationService
	) {
		this.activeUser = this.activeUserService.getUser();
	}

	canActivate(route : ActivatedRouteSnapshot) : boolean
	{
		return this.checkLogin(route)
	}

	canActivateChild(route : ActivatedRouteSnapshot) : Observable<boolean> | boolean
	{
		if (route.data.pageId)
		{
			this.authorization.getNavigations(this.activeUserService.getUser().roleId).subscribe(onConfigGet.bind(this));
			function onConfigGet(this :AuthGuardService, response) : void
			{
				var temp : boolean = response.screens.some(screen => screen.code == route.data.pageId);
				if(!temp) this.router.navigateByUrl('un-authorized');
			}
		} else this.router.navigateByUrl('**');

		return this.checkLogin(route);
	}

	checkLogin(route : ActivatedRouteSnapshot) : boolean
	{
		let user = this.activeUserService.getUser();

		if (user)
		{
			if (route.data.isGuestOnly)
			{
				this.activeUserService.goToLanding();
				return false;
			}

			return true;
		}

		else
		{
			if (!route.data.isGuestOnly)
			{
				this.activeUserService.goToLogin(this.location.path());
				return false;
			}

			return true;
		}
	}
}