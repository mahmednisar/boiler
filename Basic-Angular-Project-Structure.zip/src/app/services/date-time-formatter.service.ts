import { Injectable } from '@angular/core';

import { DateTime } from 'luxon';

@Injectable()
export class DateTimeFormatterService {
	static DateTime           = 'MM/dd/yyyy, hh:mm a';
	static DateTimeFormat     = 'MM/DD/YYYY, hh:mm a';
	static DateFormat         = "MM DD YY";
	static LongDateTimeFormat = 'MM/DD/YYYY, hh:mm:ss a';

	toTimezoneISO(date : Date) : string
	{
		const config    = {zone : 'utc'};
		const format    = 'DD MM YYYY';
		let luxonDate   = DateTime.fromJSDate(date).toFormat(format);
		return DateTime.fromFormat(luxonDate, format, config).startOf('day').toISO();
	}

	toISO(date : string) : string
	{
		const config    = {zone : 'utc'};
		const format    = DateTimeFormatterService.LongDateTimeFormat;
		let luxonDate   = DateTime.fromJSDate(new Date(date)).toFormat(format);
		return DateTime.fromFormat(luxonDate, format, config).toISO();
	}

	getTodayStartDate(offset : string) : Date
	{
		const format    = DateTimeFormatterService.LongDateTimeFormat;
		let luxonDate   = DateTime.local().setZone(offset ? `UTC${offset.replace(/:00$/, '')}` : 'utc').toFormat(format);
		return DateTime.fromFormat(luxonDate, format).startOf('day').toJSDate();
	}

	getTodaysDate(offset : string) : Date
	{
		const format    = DateTimeFormatterService.LongDateTimeFormat;
		let luxonDate   = DateTime.local().setZone(offset ? `UTC${offset.replace(/:00$/, '')}` : 'utc').toFormat(format);
		return DateTime.fromFormat(luxonDate, format).toJSDate();
	}

	getYesterdaysDate(offset : string) : Date
	{
		const format    = DateTimeFormatterService.LongDateTimeFormat;
		let luxonDate   = DateTime.local().setZone(`UTC${offset.replace(/:00$/, '')}`).toFormat(format);
		return DateTime.fromFormat(luxonDate, format).plus({days : -1}).toJSDate();
	}

	getThisWeeksDate(offset : string) : Date[]
	{
		const format    = DateTimeFormatterService.LongDateTimeFormat;
		let luxonDate   = DateTime.local().setZone(`UTC${offset.replace(/:00$/, '')}`).toFormat(format);
		let startDate   = DateTime.fromFormat(luxonDate, format).startOf('week').toJSDate();
		let endDate     = DateTime.fromFormat(luxonDate, format).endOf('week').toJSDate();
		return [ startDate, endDate ];
	}

	getThisMonthsDate( offset : string ) : Date[]
	{
		const format    = DateTimeFormatterService.LongDateTimeFormat;
		let luxonDate   = DateTime.local().setZone(`UTC${offset.replace(/:00$/, '')}`).toFormat(format);
		let startDate   = DateTime.fromFormat(luxonDate, format).startOf('month').toJSDate();
		let endDate     = DateTime.fromFormat(luxonDate, format).endOf('month').toJSDate();
		return [ startDate, endDate ];
	}

	getSelectedMonth(date) : any
	{
		const config    = {zone : 'utc'};
		const format    = 'DD MM YYYY';
		let luxonDate   = DateTime.fromJSDate(new Date(date)).toFormat(format);
		let startDate   = DateTime.fromFormat(luxonDate, format, config).startOf('month').toISO();
		let endDate     = DateTime.fromFormat(luxonDate, format, config).endOf('month').toISO();

		return { start : startDate, end : endDate };
	}

	getDuration(deadline : string) : number
	{
		return DateTime.fromISO(deadline).diffNow('seconds').toObject().seconds;
	}

	parseDate(date : string) : Date
	{
		const format  = DateTimeFormatterService.LongDateTimeFormat;
		var luxonDate = DateTime.fromISO(date).toFormat(format);
		return DateTime.fromFormat(luxonDate, format).toJSDate();
	}
}
