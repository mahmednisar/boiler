import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { LocalStorageService } from './local-storage.service';
import { parseJWT } from '../helpers/parseJWT';
import { ActiveUser } from '../models/active-user.model';
import { globalCacheBusterNotifier } from 'ngx-cacheable';

@Injectable()
export class ActiveUserService {
	private USER_KEY = 'user';

	private user  : ActiveUser;
	private token : string;

	constructor(
		private localStorage : LocalStorageService,
		private router       : Router
	)
	{
		this.token = this.localStorage.getItem(this.USER_KEY);
		this.processToken();
	}

	getToken() : string {
		return this.token;
	}

	getUser() : ActiveUser {
		return this.user;
	}

	setUser(token : string) : void {
		this.localStorage.setItem(this.USER_KEY, token);

		this.token = token;
		this.processToken();
	}

	removeUser() : void {
		this.localStorage.removeItem(this.USER_KEY);
		this.user = this.token = null;
		globalCacheBusterNotifier.next();
		this.goToLogin();
	}

	redirectUser() : void {
		this.user ? this.goToLanding() : this.goToLogin();
	}

	goToLanding(): void {
		if (this.user.hasMultipleRoles) this.gotoSelection();
		else this.goToHomeScreen();
	}

	gotoSelection(): void {
		this.router.navigateByUrl('role-selection');
	}

	goToHomeScreen(): void {
		this.router.navigateByUrl('tasks');
	}

	goToLogin(returnURL : string = null) : void {
		this.router.navigate(['login'], {replaceUrl : true, queryParams : {returnURL}});
	}

	private processToken() : void {
		if (!this.token) return;

		this.user = parseJWT<ActiveUser>(this.token);

		this.user.isTM     = this.user.role == 'Team Manager';
		this.user.fullName = `${this.user.firstName} ${this.user.lastName}`;
	}
}