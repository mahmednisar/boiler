import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { cloneDeep } from 'lodash';

import { manipulateDateRangeFilters } from '../helpers/dateTime';

import { TableStorageService } from 'src/app/services/table-storage.service';
import { DateTimeFormatterService } from './date-time-formatter.service';

import { TaskSearchParams } from '../models/TaskSearchParams.model';
import { Task } from '../models/Task.model';
import { CustomField } from '../models/MasterTemplateProperties.model';
import { TasksList } from '../models/TasksList.model';
import { BulkLogs } from '../models/bulk-logs.model';
import { Lookups } from '../models/lookup.model';
import { HoldLogs } from '../models/task-administration.model';

@Injectable()
export class TaskService
{
	constructor(
		private http           : HttpClient,
		private azureTables    : TableStorageService,
		private dateTimeFormat : DateTimeFormatterService,
	) {}

	getTasks(filters : TaskSearchParams = {}) : Observable<TasksList>
	{
		let params = cloneDeep(filters);

		for (let key of ['createdOn', 'assignedOn', 'actualStartDate', 'actualEndDate'])
		{
			if(params[key]) Object.assign(params, manipulateDateRangeFilters(key, params[key]));
			delete params[key];
		}

		return this.http.post<TasksList>('GetTaskList', params);
	}

	getParticularTask(templateId, taskId) : Observable<any>
	{
		return this.http.get('GetTask', {params : {templateId, taskId}});
	}

	addTask(data : Record<string, unknown>) : Observable<any>
	{
		return this.http.post('AddTask', data);
	}

	createMultipleTask(data : Record<string, unknown>) : Observable<any>
	{
		return this.http.post('CreateMultipleTask', data);
	}

	updateTask(templateId : number, taskDetails : Task, taskPropList : CustomField[]) : Observable<any>
	{
		return this.http.post('UpdateTask', {templateId, taskDetails, taskPropList});
	}

	startTask(templateId, taskId) : Observable<any>
	{
		return this.http.get('StartTask', {params : {templateId, taskId}});
	}

	closeTask(templateId, taskId) : Observable<any>
	{
		return this.http.get('CloseTask', {params : {templateId, taskId}});
	}

	holdTask(templateId, taskId) : Observable<any>
	{
		return this.http.get('HoldTask', {params : {templateId, taskId}});
	}
	
	resumeTask(templateId, taskId) : Observable<any>
	{
		return this.http.get('ResumeTask', {params : {templateId, taskId}});
	}

	getHoldLogs(templateId, taskId) : Observable<HoldLogs>
	{
		return this.http.get<HoldLogs>('GetHoldLogs', {params: {templateId, taskId}});
	}

	changeTaskStatus(templateId, taskId, statusId) : Observable<any>
	{
		return this.http.get('ChangeTaskStatus', {params: {templateId, taskId, statusId}});
	}

	changeTaskAuditStatus(templateId, taskId, status) : Observable<any>
	{
		return this.http.get('ChangeTaskAuditStatus', {params: {templateId, taskId, status}});
	}

	assignTask(data) : Observable<any>
	{
		return this.http.patch('AssignTask', data);
	}

	changeTaskAssignee(data) : Observable<any>
	{
		return this.http.patch('ChangeTaskAssignee', data);
	}

	getTaskCustomFieldValues(task, templateId, isAudit) : Observable<any>
	{
		if(isAudit) {
			return this.azureTables.queryEntities(`auditdata${templateId}`, {PartitionKey : task.taskId, RowKey : task.quality.id}).pipe(catchError(() => of({})));
		}
		else {
			return this.azureTables.queryEntities(`taskdata${templateId}`, {PartitionKey : task.assignedTo || 'unassigned', RowKey : task.taskId}).pipe(catchError(() => of({})));
		}
	}

	setPropertyValue(property : CustomField, values : Record<string, any>) : void
	{
		if (property.type == 'checkbox' && values[property.propertyName] instanceof Array) {
			property.value = values[property.propertyName].map((flag, i) => flag && property.childs[i].propertyName).filter(Boolean).join();
		}

		else if ((property.type == 'multiselect' || property.type == 'multiselectcheck') && values[property.propertyName] instanceof Array) {
			property.value = values[property.propertyName].toString();
		}

		else if (property.type == 'date' && values[property.propertyName]) {
			property.value = this.dateTimeFormat.toTimezoneISO(new Date(values[property.propertyName]));
		}

		else if (property.type == 'datetime' && values[property.propertyName]) { 
			property.value = this.dateTimeFormat.toISO(values[property.propertyName]);
		}

		else {
			property.value = values[property.propertyName];
		}
	}

	uploadExcel(templateId, file) : Observable<any>
	{
		let data = new FormData();
		data.append('file', file);
		return this.http.post('UploadExcel', data, {params : {templateId}});
	}

	downloadBulkUploadExcel(templateId : number) : Observable<any>
	{
		return this.http.post('DownLoadBulkUploadExcel', { templateId }, { responseType: 'blob' });
	}

	assignRandomTask(data) : Observable<any>
	{
		return this.http.patch('AssignRandomTask', data);
	}

	GetTaskBulkUploadLogs(params) : Observable<BulkLogs>
	{
		return this.http.post<BulkLogs>('GetTaskBulkUploadLogs', params);
	}

	assignMultipleTask(templateId, assignedTo, taskIds : number[]) : Observable<any>
	{
		return this.http.post('AssignMultipleTask', {templateId, assignedTo, taskIds });
	}

	discardMultipleTask(templateId, taskIds : number[]) : Observable<any>
	{
		return this.http.post('DiscardMultipleTask', {templateId, taskIds });
	}

	copyTask(data) : Observable<any>
	{
		return this.http.post('CopyTask', data);
	}

	getTaskPriorities() : Observable<Lookups>
	{
		return this.http.get('GetTaskPriorities');
	}

	updateRecievedOn(params : Record<string, any>) : Observable<any>
	{
		return this.http.post('UpdateRecievedOn', params);
	}

	auditTask(data : Record<string, any>) : Observable<any>
	{
		return this.http.post('SubmitTaskAudit', data);
	}

	getEscalationProperties(templateId) : Observable<any>
	{
		return this.http.get('GetCustomFormProperties', {params: {templateId, category : 'EscalationForm'}});
	}

	escalateTask(data : Record<string, any>) : Observable<any>
	{
		return this.http.post('SubmitTaskEscalation', data);
	}
}