import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { Employee, EmployeeFilter, EmployeeList } from 'src/app/models/employee.model';

@Injectable()
export class EmployeeService
{
	constructor(private http : HttpClient) { }

	getAllEmployees(data : EmployeeFilter) : Observable<EmployeeList>
	{
		return this.http.post<EmployeeList>('GetAllEmployees', data);
	}

	getEmployee(userId : string) : Observable<Employee>
	{
		return this.http.get<Employee>('GetEmployeeDetails', {params: {userId}})
	}

	addEmployee(data : Record<string, any>) : Observable<any>
	{
		return this.http.post('AddEmployee', data);
	}

	updateEmployee(data : Record<string, any>) : Observable<any>
	{
		return this.http.post('UpdateEmployee', data);
	}

	updateProfile(data : Record<string, any>) : Observable<any>
	{
		var formData = new FormData();
		if (data.uploadFile) formData.append('uploadFile', data.uploadFile);

		Object.entries(data).forEach(function ([key, val]) {
			if(key !== 'uploadFile' && val) {
				formData.append(key, val);
			}
		});
		
		return this.http.post('UpdateProfile', formData);
	}

	deactivateEmployee(userId: string) : Observable<any>
	{
		return this.http.get('DeactivateEmployee', {params: {userId}})
	}

	exportEmployeesToExcel(data : EmployeeFilter) : Observable<any>
	{
		return this.http.post('ExportEmployeeList', data, { responseType: 'blob' });
	}

	getReportingTo(data : Record<string, any>) : Observable<any>
	{
		return this.http.post('GetReportingTo', data);
	}

	resendInvite(emailId: string) : Observable<any>
	{
		return this.http.get('ResendInvite', {params: {emailId}})
	}
}
