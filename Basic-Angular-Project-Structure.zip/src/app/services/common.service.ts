import { Injectable } from '@angular/core';

import { DateTime } from 'luxon';

@Injectable()
export class CommonService {

	downloadBlob(blob, filename) : void
	{
		const url = URL.createObjectURL(blob);

		function removeExtraMethod() : void
		{
			URL.revokeObjectURL(url);
			document.getElementById('hack').remove();
		}

		function addExtraMethod() : void
		{
			document.body.insertAdjacentHTML('beforeend', `<a download="${filename}" id="hack" href="${url}" style="display:none;">`);
			document.getElementById('hack').click();
			setTimeout(removeExtraMethod, 100);
		}

		function download() : void
		{
			if (navigator.msSaveBlob) navigator.msSaveBlob(blob, filename);
			else if (navigator.msSaveOrOpenBlob) navigator.msSaveOrOpenBlob(blob, filename);
			else addExtraMethod();
		}
		download();
	}
}
