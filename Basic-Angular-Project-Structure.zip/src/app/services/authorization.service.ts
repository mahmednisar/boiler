import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { Cacheable } from 'ngx-cacheable';
import { catchError } from 'rxjs/operators';
@Injectable()
export class AuthorizationService {

	constructor(private http : HttpClient) { }

	@Cacheable()
	getNavigations(roleId : string) : Observable<any>
	{
		return this.http.get('GetNavigations', {params : {roleId}}).pipe(catchError(() => of({})));
	}
}
