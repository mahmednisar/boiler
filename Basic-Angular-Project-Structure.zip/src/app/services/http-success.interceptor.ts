import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpEvent, HttpHandler, HttpRequest, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { SwalService } from './swal.service';

@Injectable()
export class HttpSuccessInterceptor implements HttpInterceptor
{
	constructor(private swal : SwalService) {}

	intercept(request : HttpRequest<any>, next : HttpHandler) : Observable<HttpEvent<any>>
	{
		return next.handle(request).pipe(
			tap(this.handleSuccess.bind(this))
		);
	}

	handleSuccess(response) : void
	{	
		if (response instanceof HttpResponse) {
			if(response.body && response.body.status === 'success')
				this.swal.toast(response.body.message, 'success');
		}
	
	}
}