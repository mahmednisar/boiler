import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpEvent, HttpHandler, HttpRequest, HttpErrorResponse, HttpClient, HttpBackend } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { ActiveUserService } from './active-user.service';
import { SwalService } from './swal.service';
import { LoaderService } from './loader.service';

@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor
{
	private mockHttpInstance: HttpClient;

	constructor(
		private handler           : HttpBackend,
		private activeUserService : ActiveUserService,
		private swal              : SwalService,
		private loaderService     : LoaderService
	)
	{
		this.mockHttpInstance = new HttpClient(handler);
	}

	intercept(request : HttpRequest<any>, next : HttpHandler) : Observable<HttpEvent<any>>
	{
		return next.handle(request).pipe(
			catchError(this.handleUnauthorized.bind(this))
		);
	}

	handleUnauthorized(response : HttpErrorResponse) : Observable<HttpErrorResponse>
	{
		this.loaderService.hide();

		if (response.status <= 0) this.handle0();
		if (response.status == 400) this.handleCommon(response);
		if (response.status == 500) this.handleCommon(response);
		else if (response.status == 404) return throwError(response);
		else if (response.status == 401) this.handle401();
		else if (response.status >= 410 && response.status <= 420) this.handleWarning(response);
		else this.handleCommon(response);
		return throwError(response);
	}

	private handleCommon (response : HttpErrorResponse)
	{
		let message;

		if (!response.error.message) message = 'Some error has occurred.'
		else message = response.error.message;

		return this.swal.toast(message, 'error');
	}

	private handle401()
	{
		this.activeUserService.removeUser();
		return this.swal.toast('Session Expired. Please Login again.', 'error');
	}

	private handleWarning(response : HttpErrorResponse)
	{
		return this.swal.toast(response.error.message, 'warning');
	}

	private handle0() {
		if (!window.navigator.onLine) {
			this.handleOffline;
			return;
		}
		this.mockHttpInstance.get('favicon.ico').subscribe(
			error => this.swal.toast('Some error has occurred.', 'error'),
			() => this.handleOffline
		);
	}

	private handleOffline() {
		this.swal.toast('You might be offline. Please check your network connection.', 'error');
	}
}
