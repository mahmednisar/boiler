import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

import { TableStorageService } from 'src/app/services/table-storage.service';

import { MasterTemplate } from '../models/MasterTemplate.model';
import { CustomField, MasterTemplateProperties } from '../models/MasterTemplateProperties.model';
import { ConfigModel, TaskStatus } from '../models/TaskStatus.model';

@Injectable()
export class TemplateService
{
	constructor(
		private http        : HttpClient,
		private azureTables : TableStorageService
	) {}

	getMasterTemplates(data) : Observable<MasterTemplate[]>
	{
		return this.http.post<MasterTemplate[]>('GetMasterTemplates', data);
	}

	getMasterTemplatesList(data) : Observable<MasterTemplate[]>
	{
		return this.http.post<MasterTemplate[]>('GetMasterTemplateList', data);
	}

	getAccountTemplates(PrimaryEntity : number, SecondaryEntity ?: number) : Observable<MasterTemplate[]>
	{
		return this.http.post<MasterTemplate[]>('GetMasterTemplates', {PrimaryEntity, SecondaryEntity });
	}

	getTemplateDetails(templateId : number, isForConfig ?: boolean, createdOn ?: string) : Observable<MasterTemplateProperties>
	{
		isForConfig = isForConfig ? isForConfig : false;
		let params : any = {
			templateId  : templateId as unknown as string,
			isForConfig : isForConfig as unknown as string,
		}
		if(createdOn) params.createdOn = createdOn;
		return this.http.post<MasterTemplateProperties>('GetTemplateDetails', {...params});
	}

	getCustomFormProperties(templateId, isForConfig ?: boolean, createdOn ?: string) : Observable<any>
	{
		let params : any = {
			templateId  : templateId as unknown as string,
			isForConfig : isForConfig as unknown as string,
			category    : 'QualityForm' as unknown as string,
		}
		if(createdOn) params.createdOn = createdOn;
		return this.http.post('GetCustomFormProperties', {...params});
	}

	getTemplateConfig(PartitionKey : number|string) : Observable<any>
	{
		return this.azureTables.queryEntities('templateconfig', {PartitionKey}).pipe(map(data => data[0]), catchError(() => of({})));
	}

	getTemplateStatus(templateId : number) : Observable<TaskStatus[]>
	{
		return this.http.get<TaskStatus[]>('GetTemplateStatus', {params : {templateId : templateId as unknown as string}})
	}

	getMasterConfigurations(isBasicFields ?: boolean) : Observable<ConfigModel[]>
	{
		return this.http.post<ConfigModel[]>('GetMasterConfigurations', { isBasicFields });
	}

	addUpdateProperties(templateId : number, customFields : CustomField[]) : Observable<any>
	{
		return this.http.post('AddUpdateTemplateProperties', { templateId, customFields });
	}

	getComponents() : Observable<CustomField[]>
	{
		return this.http.get<CustomField[]>('GetComponents');
	}

	updateTemplate(data : any) : Observable<any>
	{
		return this.http.post('UpdateMasterTemplate', data);
	}

	addTemplate(data : any) : Observable<any>
	{
		return this.http.post('AddMasterTemplate', data);
	}
}