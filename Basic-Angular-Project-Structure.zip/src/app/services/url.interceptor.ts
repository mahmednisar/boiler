import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpEvent, HttpHandler, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';

@Injectable()
export class URLInterceptor implements HttpInterceptor
{
	apiURL = environment.apiURL;

	intercept(request : HttpRequest<any>, next : HttpHandler) : Observable<HttpEvent<any>>
	{
		try
		{
			new URL(request.url);
		}

		catch
		{
			request = this.modifyRequestURL(request);
		}

		return next.handle(request);
	}

	modifyRequestURL(request : HttpRequest<any>) : HttpRequest<any>
	{
		return request.clone({
			url : new URL(request.url, this.apiURL).href
		});
	}
}