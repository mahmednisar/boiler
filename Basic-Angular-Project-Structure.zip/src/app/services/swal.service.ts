import { Injectable } from '@angular/core';
import Swal, { SweetAlertIcon } from 'sweetalert2';

@Injectable()
export class SwalService
{
	toast(title : string, icon : SweetAlertIcon) : void
	{
		Swal.fire({
			title,
			icon,
			toast             : true,
			position          : 'top-right',
			timer             : 5000,
			showConfirmButton : false
		});
	}
}