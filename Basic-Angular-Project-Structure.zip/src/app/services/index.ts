import { HTTP_INTERCEPTORS } from '@angular/common/http';

import { LocalStorageService } from './local-storage.service';
import { ActiveUserService } from './active-user.service';
import { TableStorageService } from './table-storage.service';
import { LoaderService } from './loader.service';
import { TaskService } from './task.service';
import { TemplateService } from './template.service';
import { UserService } from './user.service';
import { MetricService } from './metric.service';
import { TargetService } from './target.service';
import { AuthGuardService } from './auth-guard.service';
import { FormGeneratorService } from './form-generator.service';
import { CommonService } from './common.service';
import { ReportService } from './report.service';
import { AccountService } from './account.service';
import { EmployeeService } from './employee.service';
import { AuthorizationService } from './authorization.service';
import { ExternalAccessService } from './external-access.service';

import { AuthInterceptor } from './auth.interceptor';
import { URLInterceptor } from './url.interceptor';
import { HttpErrorInterceptor } from './http-error.interceptor';
import { HttpSuccessInterceptor } from './http-success.interceptor';
import { LoaderInterceptor } from './loader.interceptor';

import { SwalService } from './swal.service';
import { DateTimeFormatterService } from './date-time-formatter.service';
import { OrgStructureService } from './org-structure.service';

export let providers = [
	LocalStorageService,
	ActiveUserService,
	TableStorageService,
	FormGeneratorService,
	SwalService,
	TaskService,
	TemplateService,
	UserService,
	MetricService,
	TargetService,
	ReportService,
	AccountService,
	EmployeeService,
	ExternalAccessService,
	OrgStructureService,

	CommonService,
	DateTimeFormatterService,

	AuthorizationService,
	AuthGuardService,
	LoaderService,

	{
		provide  : HTTP_INTERCEPTORS,
		useClass : AuthInterceptor,
		multi    : true
	},
	{
		provide  : HTTP_INTERCEPTORS,
		useClass : URLInterceptor,
		multi    : true
	},
	{
		provide  : HTTP_INTERCEPTORS,
		useClass : HttpErrorInterceptor,
		multi    : true
	},
	{
		provide  : HTTP_INTERCEPTORS,
		useClass : HttpSuccessInterceptor,
		multi    : true
	},
	{
		provide  : HTTP_INTERCEPTORS,
		useClass : LoaderInterceptor,
		multi    : true
	}
];