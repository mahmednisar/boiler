import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpEvent, HttpHandler, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';

import { ActiveUserService } from '../services/active-user.service';

@Injectable()
export class AuthInterceptor implements HttpInterceptor
{
	constructor(private activeUserService : ActiveUserService) {}

	intercept(request : HttpRequest<any>, next : HttpHandler) : Observable<HttpEvent<any>>
	{
		if (!request.headers.has('Authorization')) request = this.addAuthHeaderToRequest(request);
		return next.handle(request);
	}

	addAuthHeaderToRequest(request : HttpRequest<any>) : HttpRequest<any>
	{
		return request.clone({
			setHeaders :
			{
				Authorization: `Bearer ${this.activeUserService.getToken()}`
			}
		});
	}
}