import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { HmacSHA256, enc } from 'crypto-js';
import { map, catchError } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

@Injectable()
export class TableStorageService
{
	private accountName        = environment.accountName;
	private accountKey         = environment.accountKey;
	private version            = '2019-07-07';
	private dataServiceVersion = '3.0;NetFx';

	constructor(private http : HttpClient) {}

	queryEntities(tableName : string, filters ?: any) : any
	{
		let special            = filters && filters.PartitionKey && filters.RowKey;
		let resourceIdentifier = special ? `${tableName}${this.generatePrimaryKey(filters.PartitionKey, filters.RowKey)}` : tableName;
		let url                = this.generateURL(resourceIdentifier) + (special ? '' : this.generateFilters(filters));
		let headers            = this.generateHeaders(resourceIdentifier);

		return this.http.get(url, { headers }).pipe(map((data:any) => special ? data : data.value));
	}

	queryMultipleEntities<T>(tableName : string, filters : string[]) : Observable<T>
	{
		let resourceIdentifier = tableName;
		let url                = this.generateURL(resourceIdentifier) + '?$filter=' + filters.map(key => `PartitionKey eq '${key}'`).join(' or ');
		let headers            = this.generateHeaders(resourceIdentifier);

		return this.http.get(url, { headers }).pipe(map((data:any) => data.value));
	}

	queryCustomEntities<T>(tableName : string, filter : string) : Observable<T>
	{
		let resourceIdentifier = tableName;
		let url                = this.generateURL(resourceIdentifier) + `?$filter=${filter}`;
		let headers            = this.generateHeaders(resourceIdentifier);

		return this.http.get(url, { headers }).pipe(map((data:any) => data.value), catchError(() => of({})));
	}

	private generateURL(resourceIdentifier : string) : string
	{
		return `https://${this.accountName}.table.core.windows.net/${resourceIdentifier}`;
	}

	private generateFilters(filters : any) : string
	{
		return Object.entries(filters).reduce((filterString, filterMap: Array<any>, index, array) => {
			if (typeof (filterMap[1]) == 'string' || filterMap[0] == 'PartitionKey' || filterMap[0] == 'RowKey')
				filterMap[1] = `'${encodeURIComponent(filterMap[1])}'`;

			return filterString += `${filterMap[0]} eq ${filterMap[1]} ${index == array.length - 1 ? '' : ' and '}`;
		}, '?$filter=');
	}

	private generatePrimaryKey(partitionKey : string, rowKey : string) : string
	{
		return `(PartitionKey='${partitionKey}',RowKey='${rowKey}')`;
	}

	private generateSignature(canonicalString : string) : string
	{
		return enc.Base64.stringify(HmacSHA256(enc.Utf8.parse(canonicalString), enc.Base64.parse(this.accountKey)));
	}

	private generateHeaders(resourceIdentifier : string) : Record<string, string>
	{
		let UTCDate = new Date().toUTCString();
		let signature = this.generateSignature(`${UTCDate}\n/${this.accountName}/${resourceIdentifier}`);

		return {
			Authorization      : `SharedKeyLite ${this.accountName}:${signature}`,
			'x-ms-date'        : UTCDate,
			'x-ms-version'     : this.version,
			DataServiceVersion : this.dataServiceVersion,
			'Content-Type'     : 'application/json;odata=nometadata',
			'X-Hide-Spinner'   : '0'
		};
	}
}