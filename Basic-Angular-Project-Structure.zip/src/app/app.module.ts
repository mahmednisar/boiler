import { NgModule } from '@angular/core';

import { BrowserModule, Title } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AkitaNgRouterStoreModule } from '@datorama/akita-ng-router-store';

import { AppComponent } from './app.component';

import {providers} from './services';
import {modules} from './modules';

@NgModule({
	bootstrap    : [AppComponent],
	declarations : [AppComponent],

	providers :
	[
		Title,
		...providers
	],

	imports :
	[
		BrowserModule,
		BrowserAnimationsModule,
		HttpClientModule,
		AppRoutingModule,
		AkitaNgRouterStoreModule,
		...modules
	]
})
export class AppModule {}