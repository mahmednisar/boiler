export const environment =
{
	production  : true,
	apiURL      : 'https://adminaccountssprintapiservice.azurewebsites.net',
	accountName : 'psgaasprintstorage',
	accountKey  : 'ugbbWmuR5gG0/NWNS/cvloesBh5zM/KZXjU4qUTsv1c7UMSKaaSezwrCiU4SsOPLd7iUl3WHzrurYwsMVtU4YA=='
};