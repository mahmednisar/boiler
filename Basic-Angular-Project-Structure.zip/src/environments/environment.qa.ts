export const environment =
{
	production  : true,
	apiURL      : 'https://adminaccountsqaapiservice.azurewebsites.net/',
	accountName : 'psgadminaccndevstorage',
	accountKey  : 'wlk1m2+uY0IxVIwnA+dIYbodhKRmxf7pZ/xOqs5Kpr58Fhg2OLaa02AcELB5+mhIowEcTQoFHeCcsjd5KxFFCQ=='
};