export const environment =
{
	production  : true,
	apiURL      : 'https://adminaccountsdashboardapiservice.azurewebsites.net/',
	accountName : 'psgaaprodstorage',
	accountKey  : 'jf1+35H8gUvICsb+WwZxWLKmlbvHPjEtSFLIXam3TliMukqNPMwTF5Fa/fJ2HWzzOBcAuaOtEBEBKi1G13ZP5w=='
};