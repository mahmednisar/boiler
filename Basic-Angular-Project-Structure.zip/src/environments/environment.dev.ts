export const environment =
{
	production  : true,
	apiURL      : 'https://adminaccountsdevapiservice.azurewebsites.net/',
	accountName : 'adminaccinternalstorage',
	accountKey  : 'LSACTbnz5p57zc4NXkQEE+UKxa2C5WrdgwMhWlt2ir+NeayrS8hyDfXKmWiZIZ/6X1yJwVzH28LOGbs6BoGQwA=='
};