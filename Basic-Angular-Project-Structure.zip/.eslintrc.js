module.exports =
{
	parser : '@typescript-eslint/parser',

	parserOptions :
	{
		ecmaVersion : 2020,
		project     : './tsconfig.json'
	},

	plugins : ['@typescript-eslint'],

	extends :
	[
		'eslint:recommended',
		'plugin:@typescript-eslint/eslint-recommended',
		'plugin:@typescript-eslint/recommended',
		'plugin:@typescript-eslint/recommended-requiring-type-checking'
	],

	rules :
	{
		'@typescript-eslint/indent'                        : ['error', 'tab'],
		'no-var'                                           : 0,
		'@typescript-eslint/unbound-method'                : 0,
		'@typescript-eslint/type-annotation-spacing'       : 0,
		'@typescript-eslint/no-this-alias'                 : 0,
		'@typescript-eslint/no-use-before-define'          : 0,
		'@typescript-eslint/no-unsafe-member-access'       : 0,
		'@typescript-eslint/no-floating-promises'          : 0,
		'@typescript-eslint/no-unsafe-assignment'          : 0,
		'prefer-const'                                     : 0,
		'@typescript-eslint/no-unsafe-call'                : 0,
		'@typescript-eslint/restrict-template-expressions' : 0,
		'@typescript-eslint/no-unsafe-return'              : 0,
	}
};
