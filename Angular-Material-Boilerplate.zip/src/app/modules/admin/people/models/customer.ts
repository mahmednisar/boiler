export interface Customer {
    id: string;
    name: string;
    phone: string;
    email: string;
    imageUrl: string;
    type: string;
}
