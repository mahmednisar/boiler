export class ConfirmEmailParams {
    userId: string;
    code: string;
}

export class ConfirmPhoneNumberParams {
    userId: string;
    code: string;
}