export interface Category {
  id: string;
  name: string;
  detail: string;
}
