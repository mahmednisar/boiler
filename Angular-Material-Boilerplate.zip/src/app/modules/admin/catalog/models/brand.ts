export interface Brand {
  id: string;
  name: string;
  description: string;
}
