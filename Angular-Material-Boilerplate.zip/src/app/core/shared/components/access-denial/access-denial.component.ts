import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-access-denial',
  templateUrl: './access-denial.component.html',
  styleUrls: ['./access-denial.component.scss']
})
export class AccessDenialComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
