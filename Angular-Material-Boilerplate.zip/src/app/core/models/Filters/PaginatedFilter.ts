export interface PaginatedFilter {
    pageNumber: number;
    pageSize: number;
}
