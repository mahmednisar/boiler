export class CartApiModel {
    id: string;
    customerId: string;
    timestamp: Date;
}