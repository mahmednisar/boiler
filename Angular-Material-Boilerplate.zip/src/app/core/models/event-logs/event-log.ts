export class EventLog {
  id: string;
  data: string;
  oldValues: string;
  newValues: string;
  email: string;
  userId: string;
  messageType: string;
  timestamp: string;
  eventDescription: string;
}
