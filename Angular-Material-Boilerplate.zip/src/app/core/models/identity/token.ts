export class Token {
    token: string;
    refreshToken: string;
    refreshTokenExpiryTime: Date;
}