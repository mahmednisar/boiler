export class Permission {
  permission: string;
  description: string;
}
