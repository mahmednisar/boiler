export enum UploadType {
  Product,
  Brand,
  Category,
  Customer,
}
